import type { AdminRouteDef } from "@cms/config";
import { Spinner } from "@cms/ui";
import { type ComponentType, lazy, Suspense } from "react";

// One lazy component per page, so reopening a page doesn't suspend again.
const lazyPages = new WeakMap<AdminRouteDef, ComponentType>();

const getLazyPage = (page: AdminRouteDef): ComponentType => {
  const existing = lazyPages.get(page);
  if (existing) return existing;
  const Page = lazy(page.component);
  lazyPages.set(page, Page);
  return Page;
};

/** A project or plugin page from `admin.routes`, loaded the first time it's opened. */
const AdminPage = ({ page }: { page: AdminRouteDef }) => {
  const Page = getLazyPage(page);

  return (
    <Suspense
      fallback={
        <div className="flex h-full items-center justify-center">
          <Spinner size="lg" />
        </div>
      }
    >
      <Page />
    </Suspense>
  );
};

export { AdminPage };
