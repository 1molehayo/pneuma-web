import CMS_CONFIG from "virtual:cms-config";
import {
  defaultSidebar,
  type SidebarElement as SidebarElementType,
  type SidebarGroup as SidebarGroupType,
  type SidebarItem as SidebarItemType,
  type SidebarPage as SidebarPageType,
} from "@cms/config";
import { cn, Disclosure, Divider, Slot } from "@cms/ui";
import { HouseSimpleIcon, ImageIcon } from "@phosphor-icons/react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { type ComponentPropsWithRef, useMemo } from "react";
import { getMeQueryOptions } from "@/lib/queries/me";
import { resolveEntityTitle } from "@/lib/utils/config";
import { adminPagePath, filterSidebar, findAdminPage } from "@/lib/utils/sidebar";

const GLOBAL_NAMES = new Set(CMS_CONFIG.entities.filter((e) => e.global).map((e) => e.name));
const SIDEBAR_ELEMENTS = CMS_CONFIG.admin?.sidebar ?? defaultSidebar(CMS_CONFIG);

const resolveItemPath = (name: string): string => {
  if (name === "_dashboard") return "/";
  if (name === "_assets") return "/assets";
  if (GLOBAL_NAMES.has(name)) return `/global/${name}`;
  return `/entity/${name}`;
};

const resolveItemIcon = (item: SidebarItemType): React.ComponentType | undefined => {
  if (item.icon) return item.icon;
  if (item.name === "_dashboard") return HouseSimpleIcon;
  if (item.name === "_assets") return ImageIcon;
  return undefined;
};

const resolveItemLabel = (item: SidebarItemType): string => {
  if (item.label) return item.label;
  if (item.name === "_dashboard") return "Dashboard";
  if (item.name === "_assets") return "Assets";
  return resolveEntityTitle(item.name, { plural: true });
};

const elementKey = (element: SidebarElementType, index: number): string => {
  if (element.type === "item") return `item:${index}:${element.name}`;
  if (element.type === "page") return `page:${index}:${element.plugin ?? ""}/${element.path}`;
  if (element.type === "group") return `group:${index}:${element.label}`;
  return `divider:${index}`;
};

const Sidebar = () => {
  const { data: user } = useQuery(getMeQueryOptions());

  const elements = useMemo(() => {
    if (!user) return SIDEBAR_ELEMENTS;
    const role = CMS_CONFIG.roles.find((r) => r.name === user.role);
    if (!role || role.isAdmin) return SIDEBAR_ELEMENTS;
    return filterSidebar(SIDEBAR_ELEMENTS, role, CMS_CONFIG);
  }, [user]);

  return (
    <nav className={cn("h-full bg-background p-2")}>
      {elements.map((element, index) => (
        <SidebarElement key={elementKey(element, index)} element={element} depth={0} />
      ))}
    </nav>
  );
};

const SidebarElement = ({ element, depth }: { element: SidebarElementType; depth: number }) => {
  if (element.type === "divider")
    return <Divider className="my-3 -mx-2 w-[calc(100%+2*(--spacing(2)))]" />;
  if (element.type === "item") return <SidebarItem item={element} />;
  if (element.type === "page") return <SidebarPage page={element} />;
  return <SidebarGroup group={element} depth={depth} />;
};

const SidebarGroup = ({ group, depth }: { group: SidebarGroupType; depth: number }) => {
  const indent = group.indent ?? true;
  const defaultOpen = group.defaultOpen ?? depth === 0;

  if (group.collapsible) {
    return (
      <Disclosure defaultOpen={defaultOpen} className="mt-2">
        <Disclosure.Trigger asChild className="flex justify-between items-center w-full">
          <SidebarButton variant="secondary">
            {group.icon && <group.icon />}
            {group.label}
            <Disclosure.Chevron className="ml-auto" />
          </SidebarButton>
        </Disclosure.Trigger>
        <Disclosure.Content>
          <SidebarList elements={group.children} indent={indent} depth={depth + 1} />
        </Disclosure.Content>
      </Disclosure>
    );
  }

  return (
    <div className="mt-2">
      <SidebarButton asChild variant="secondary" interactive={false}>
        <div>
          {group.icon && <group.icon />}
          {group.label}
        </div>
      </SidebarButton>
      <SidebarList elements={group.children} indent={indent} depth={depth + 1} />
    </div>
  );
};

const SidebarList = ({
  elements,
  indent,
  depth,
}: {
  elements: readonly SidebarElementType[];
  indent?: boolean;
  depth: number;
}) => {
  return (
    <ul className={cn(indent && "ml-4 border-l border-border border-dashed pl-2")}>
      {elements.map((element, index) => (
        <li key={elementKey(element, index)} className="my-1">
          <SidebarElement element={element} depth={depth} />
        </li>
      ))}
    </ul>
  );
};

const SidebarItem = ({ item }: { item: SidebarItemType }) => {
  const path = resolveItemPath(item.name);
  const IconComponent = resolveItemIcon(item);
  const label = resolveItemLabel(item);

  return (
    <SidebarButton asChild>
      <Link to={path}>
        {IconComponent && <IconComponent />}
        {label}
      </Link>
    </SidebarButton>
  );
};

const SidebarPage = ({ page }: { page: SidebarPageType }) => {
  const def = findAdminPage(CMS_CONFIG, page);
  const IconComponent = page.icon ?? def?.icon;

  return (
    <SidebarButton asChild>
      <Link to={adminPagePath(page)}>
        {IconComponent && <IconComponent />}
        {page.label ?? def?.label ?? page.path}
      </Link>
    </SidebarButton>
  );
};

type SidebarButtonProps = ComponentPropsWithRef<"button"> & {
  asChild?: boolean;
  variant?: "default" | "secondary";
  interactive?: boolean;
};

const SidebarButton = ({
  variant,
  interactive = true,
  asChild,
  className,
  children,
  ...props
}: SidebarButtonProps) => {
  const Component = asChild ? Slot : "button";

  return (
    <Component
      className={cn(
        "text-sm flex items-center gap-1.5 px-3 h-10 whitespace-nowrap truncate rounded-md capitalize",
        interactive && [
          "hover:bg-foreground/2 active:bg-foreground/6",
          "ring-ring focus-visible:outline-none focus-visible:ring-4",
        ],
        variant === "secondary" ? "text-foreground-secondary" : "text-foreground",
        'aria-[current="page"]:bg-foreground/3',
        className,
      )}
      {...props}
    >
      {children}
    </Component>
  );
};

export { Sidebar };
