import CMS_CONFIG from "virtual:cms-config";
import { Button, Dropdown } from "@cms/ui";
import { CaretDownIcon, CheckIcon, PlusIcon, TranslateIcon } from "@phosphor-icons/react";
import { Link, type LinkProps } from "@tanstack/react-router";
import type { TranslatableDocument } from "@/lib/schemas";
import { getLocaleLabel } from "@/lib/utils/i18n";

const locales = CMS_CONFIG.i18n.locales || [];

type DocumentLocaleSwitcherProps = {
  document: TranslatableDocument;
  getTranslationLinkProps: (translationId: string) => LinkProps;
  getNewTranslationLinkProps: (locale: string) => LinkProps;
};

const DocumentLocaleSwitcher = ({
  document,
  getTranslationLinkProps,
  getNewTranslationLinkProps,
}: DocumentLocaleSwitcherProps) => {
  return (
    <Dropdown>
      <Dropdown.Trigger asChild>
        <Button variant="outline" size="xs">
          <TranslateIcon />
          {getLocaleLabel(document.locale)}
          <CaretDownIcon className="ml-2" />
        </Button>
      </Dropdown.Trigger>
      <Dropdown.Items>
        {locales.map((locale) => {
          const isCurrent = locale.value === document.locale;
          const translationId = document._translations[locale.value];

          if (translationId || isCurrent) {
            return (
              <Dropdown.Item key={locale.value} asChild disabled={isCurrent}>
                <Link {...getTranslationLinkProps(translationId?.id ?? document.id)}>
                  {locale.label}
                  {isCurrent && <CheckIcon className="ml-auto" />}
                </Link>
              </Dropdown.Item>
            );
          }

          return (
            <Dropdown.Item key={locale.value} asChild>
              <Link {...getNewTranslationLinkProps(locale.value)} preload={false}>
                <PlusIcon />
                {locale.label}
              </Link>
            </Dropdown.Item>
          );
        })}
      </Dropdown.Items>
    </Dropdown>
  );
};

export { DocumentLocaleSwitcher };
