import { createContext, use } from "react";

export type DocumentFormContextValue = {
  fields: ReadonlyArray<import("@cms/config").AnyField | import("@cms/config").LayoutDirective>;
  formData: Record<string, unknown>;
  setFormData: (data: Record<string, unknown>) => void;
  handleSubmit: (e: React.SubmitEvent<HTMLFormElement>) => void;
  fieldErrors: Record<string, string>;
  isPending: boolean;
  isSubmitted: boolean;
  isDirty: boolean;
  /**
   * Per-slug-field linked state. When `true`, the form provider re-derives
   * the slug from its configured `source` on every formData update. Flipped
   * to `false` when the editor types in the slug input; flipped back to
   * `true` when they click the regenerate affordance.
   */
  linkedSlugs: Record<string, boolean>;
  setSlugLinked: (name: string, linked: boolean) => void;
};

// Kept in its own module so HMR reloads of document-form.tsx do not recreate
// the context object — a new identity would break any consumer that already
// subscribed to the old provider.
export const DocumentFormContext = createContext<DocumentFormContextValue | null>(null);

export const useDocumentForm = () => {
  const context = use(DocumentFormContext);

  if (!context) {
    throw new Error("useDocumentFormContext must be used within DocumentForm");
  }

  return context;
};
