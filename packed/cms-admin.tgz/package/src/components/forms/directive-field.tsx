import type { LayoutDirective } from "@cms/config";
import { Collapsible } from "./directives/collapsible";
import { Row } from "./directives/row";
import { Tabs } from "./directives/tabs";

type DirectiveFieldProps = {
  directive: LayoutDirective;
  value: Record<string, unknown>;
  onChange: (value: Record<string, unknown>) => void;
  errors?: Record<string, string>;
  disabled?: boolean;
  excludedFields?: Set<string>;
  readOnlyFields?: Set<string>;
};

const DirectiveField = ({ directive, ...props }: DirectiveFieldProps) => {
  if (directive._directive === "tabs") {
    return <Tabs directive={directive} {...props} />;
  }
  if (directive._directive === "collapsible") {
    return <Collapsible directive={directive} {...props} />;
  }
  if (directive._directive === "row") {
    return <Row directive={directive} {...props} />;
  }

  return null;
};

export { DirectiveField };
