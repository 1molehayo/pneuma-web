import CMS_CONFIG from "virtual:cms-config";
import { ClientError } from "@cms/client";
import { Button, cn, Dialog, Radio, Skeleton, toast } from "@cms/ui";
import { PlusIcon } from "@phosphor-icons/react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { lazy, type ReactNode, Suspense, useId, useMemo, useRef, useState } from "react";
import { type DeleteScope, DeleteScopeChoice } from "@/components/delete-scope-choice";
import { RelationAddTrigger, useResolvedOptions } from "@/components/forms/inputs/relation-input";
import { ReferrerList } from "@/components/referrer-list";
import { client } from "@/lib/client";
import { getDocumentQueryOptions } from "@/lib/queries/documents";
import { invalidate } from "@/lib/queries/keys";
import { getReferrersQueryOptions } from "@/lib/queries/referrers";
import { resolveEntityTitle } from "@/lib/utils/config";
import { resolveDocumentMeta } from "@/lib/utils/documents";
import { formatLocaleList, getLocaleLabel } from "@/lib/utils/i18n";

const IS_MULTI_LOCALE = (CMS_CONFIG.i18n.locales ?? []).length > 1;

/** The project's delete actions, then each plugin's, loaded when a dialog first renders them. */
const DELETE_ACTIONS = [
  ...(CMS_CONFIG.admin?.deleteActions ?? []),
  ...CMS_CONFIG.plugins.flatMap((plugin) => plugin.admin?.deleteActions ?? []),
].map((action) => lazy(action.component));

type DeleteDocumentDialogProps = {
  document?: {
    id: string;
    entity: string;
    title: ReactNode;
    /** The row's locale; omit for entities that aren't translatable. */
    locale?: string;
    /** Locales other than `locale` that the document also exists in. */
    otherLocales?: readonly string[];
  };
  onClose: () => void;
  onSuccess: () => void;
};

const DeleteDocumentDialog = ({ document, onSuccess, onClose }: DeleteDocumentDialogProps) => {
  return (
    <Dialog open={!!document} onOpenChange={onClose}>
      <Dialog.Content>
        {document && <DeleteDocumentDialogContent document={document} onSuccess={onSuccess} />}
      </Dialog.Content>
    </Dialog>
  );
};

type DeleteDocumentDialogContentProps = {
  document: NonNullable<DeleteDocumentDialogProps["document"]>;
  onSuccess: DeleteDocumentDialogProps["onSuccess"];
};

/** What happens to the documents pointing at this one. */
type ReferrersChoice = "replace" | "keep";
/** The referrers a replace moved, as the DELETE response lists them. */
type Rewritten = Array<{ entity: string; id: string }>;

const DeleteDocumentDialogContent = ({ document, onSuccess }: DeleteDocumentDialogContentProps) => {
  const queryClient = useQueryClient();
  const [scope, setScope] = useState<DeleteScope>("locale");
  const [referrersChoice, setReferrersChoice] = useState<ReferrersChoice>("replace");
  const [replacementId, setReplacementId] = useState<string | null>(null);
  // Work the delete actions hand over, by action index. A ref: changing it never re-renders.
  const afterDelete = useRef(new Map<number, () => Promise<void>>());

  const label = resolveEntityTitle(document.entity);
  const name = typeof document.title === "string" ? `“${document.title}”` : `this ${label}`;
  const locale = IS_MULTI_LOCALE ? document.locale : undefined;
  const otherLocales = document.otherLocales ?? [];
  const hasChoice = locale !== undefined && otherLocales.length > 0;

  const referrers = useQuery(getReferrersQueryOptions(document.entity, document.id));
  const referrerCount = referrers.data?.meta.total ?? 0;
  // Replace moves this locale's referrers; a translation has its own, so it's one at a time.
  // Replace rewrites every referrer, so it's offered only when the editor can see them all.
  const replaceable =
    CMS_CONFIG.entities.find((entity) => entity.name === document.entity)?.replacement !== false;
  const canReplace =
    replaceable &&
    referrerCount > 0 &&
    referrers.data?.meta.hidden === 0 &&
    (!hasChoice || scope === "locale");
  const replacing = canReplace && referrersChoice === "replace";

  // The delete actions read both documents, and capture their work from them: confirming before
  // they load would run an action without them (a redirect with no destination). Shared with
  // `DeleteActions` through the query cache.
  const hasActions = DELETE_ACTIONS.length > 0;
  const actionDocument = useQuery({
    ...getDocumentQueryOptions(document.entity, document.id),
    enabled: hasActions,
  });
  const actionReplacement = useQuery({
    ...getDocumentQueryOptions(document.entity, replacementId ?? ""),
    enabled: hasActions && replacing && replacementId !== null,
  });
  const actionsLoading = actionDocument.isLoading || actionReplacement.isLoading;
  const actionsFailed = actionDocument.isError || (replacing && actionReplacement.isError);

  const deleteMutation = useMutation({
    mutationFn: async (scope: DeleteScope) => {
      // Taken now: closing the dialog mid-request unmounts the actions and withdraws their work.
      const runs = [...afterDelete.current.values()];
      let result: {
        deleted: number;
        skipped: number;
        documentDeleted: boolean;
        rewritten: Rewritten;
      } = { deleted: 1, skipped: 0, documentDeleted: true, rewritten: [] };
      if (scope === "locale") {
        const res = await client.request<{ data: { id: string; rewritten: Rewritten } }>(
          `/${document.entity}/${document.id}`,
          {
            method: "DELETE",
            params: replacing && replacementId ? { replaceWith: replacementId } : undefined,
          },
        );
        // The referrers the delete moved, which can differ from the preview loaded earlier.
        result = { ...result, rewritten: res.data.rewritten };
      } else {
        const res = await client.request<{
          data: { deleted: number; ids: string[]; skipped: string[] };
        }>(`/${document.entity}/_bulk-delete`, {
          method: "POST",
          body: { ids: [document.id], allLocales: true },
        });
        result = {
          deleted: res.data.deleted,
          skipped: res.data.skipped.length,
          documentDeleted: res.data.ids.includes(document.id),
          rewritten: [],
        };
      }

      // After the commit: a failure here leaves the document deleted, so it's reported, not thrown.
      // The actions follow up on this document, so they run only if it was the one deleted.
      const failures: string[] = [];
      for (const run of result.documentDeleted ? runs : []) {
        try {
          await run();
        } catch (error) {
          failures.push(error instanceof Error ? error.message : String(error));
        }
      }
      return { ...result, failures };
    },
    onError: (err) => {
      toast({
        title: `Failed to delete ${name}`,
        description: err instanceof ClientError ? err.message : undefined,
        variant: "negative",
      });
    },
    onSuccess: ({ deleted, skipped, failures, rewritten }, scope) => {
      invalidate.afterDelete(
        queryClient,
        replacing && replacementId
          ? { entity: document.entity, replacementId, referrers: rewritten }
          : { entity: document.entity },
      );

      if (!hasChoice) {
        toast({ title: `Deleted ${name}`, variant: "positive" });
      } else if (scope === "locale") {
        toast({
          title: `Deleted ${getLocaleLabel(locale)} version of ${name}`,
          description: `Still in ${formatLocaleList(otherLocales)}.`,
          variant: "positive",
        });
      } else if (skipped === 0) {
        toast({ title: `Deleted ${name} from all locales`, variant: "positive" });
      } else {
        toast({
          title: `Deleted ${deleted} of ${deleted + skipped} locales of ${name}`,
          description: `${skipped} you can't delete ${skipped === 1 ? "was" : "were"} kept.`,
          variant: "negative",
        });
      }
      for (const failure of failures) {
        toast({
          title: `Deleted ${name}, but not everything after it`,
          description: failure,
          variant: "negative",
        });
      }
      onSuccess();
    },
  });

  return (
    <>
      <Dialog.Title>Delete {label}</Dialog.Title>
      {locale === undefined ? (
        <Dialog.Description>
          Are you sure you want to delete this {label}? <br />
          This action cannot be undone.
        </Dialog.Description>
      ) : !hasChoice ? (
        <Dialog.Description>
          Delete {name}? This removes it from all locales and cannot be undone.
        </Dialog.Description>
      ) : (
        <>
          <Dialog.Description>
            This {label} exists in more than one locale. This action cannot be undone.
          </Dialog.Description>
          <DeleteScopeChoice
            value={scope}
            onValueChange={setScope}
            locale={locale}
            locales={[locale, ...otherLocales]}
            disabled={deleteMutation.isPending}
          />
        </>
      )}

      {referrers.isPending ? (
        <Skeleton className="h-10" />
      ) : referrers.isError ? (
        <p className="text-sm text-negative">Couldn't check where this {label} is used.</p>
      ) : (
        referrerCount > 0 && (
          <div className="flex flex-col gap-2 pt-2">
            <p className="text-sm font-medium">
              Used in {referrerCount} {referrerCount === 1 ? "document" : "documents"}
            </p>
            <div className="max-h-48 overflow-y-auto rounded-lg border border-border p-1">
              <ReferrerList referrers={referrers.data.data} hidden={referrers.data.meta.hidden} />
            </div>
            {!canReplace && <p className="text-sm text-foreground-secondary">{LEFT_REFERRERS}</p>}
            {canReplace && (
              <ReferrersChoiceField
                value={referrersChoice}
                onValueChange={setReferrersChoice}
                entity={document.entity}
                documentId={document.id}
                locale={document.locale}
                replacementId={replacementId}
                onReplacementChange={setReplacementId}
                disabled={deleteMutation.isPending}
              />
            )}
          </div>
        )
      )}

      {actionsFailed && (
        <p className="text-sm text-negative">
          Couldn't load what the delete options need. Close and try again.
        </p>
      )}
      {hasActions && (
        <DeleteActions
          entity={document.entity}
          documentId={document.id}
          replacementId={replacing ? replacementId : null}
          afterDelete={afterDelete.current}
        />
      )}

      <Dialog.Actions>
        <Dialog.Close asChild>
          <Button variant="outline">Cancel</Button>
        </Dialog.Close>
        <Button
          autoFocus
          variant="destructive"
          onClick={() => deleteMutation.mutate(hasChoice ? scope : "locale")}
          isLoading={deleteMutation.isPending}
          disabled={
            referrers.isPending || (replacing && !replacementId) || actionsLoading || actionsFailed
          }
        >
          {replacing ? "Replace and delete" : "Delete"}
        </Button>
      </Dialog.Actions>
    </>
  );
};

type ReferrersChoiceFieldProps = {
  value: ReferrersChoice;
  onValueChange: (value: ReferrersChoice) => void;
  entity: string;
  documentId: string;
  locale?: string;
  replacementId: string | null;
  onReplacementChange: (id: string | null) => void;
  disabled?: boolean;
};

/** What a delete without a replacement does to its referrers. */
const LEFT_REFERRERS =
  "Optional relations are cleared and relations inside blocks and rich text are left pointing at nothing. A required relation refuses the delete.";

/** Point every referrer at another document of the entity, or delete and leave them. */
const ReferrersChoiceField = ({
  value,
  onValueChange,
  entity,
  documentId,
  locale,
  replacementId,
  onReplacementChange,
  disabled,
}: ReferrersChoiceFieldProps) => {
  const name = useId();
  const label = resolveEntityTitle(entity);
  const { data: picked, isPending } = useResolvedOptions(
    [entity],
    replacementId ? [replacementId] : [],
  );
  const replacement = picked?.find((option) => option.id === replacementId);

  const options = [
    {
      value: "replace",
      title: `Replace with another ${label}`,
      description: "The documents above point at it instead, saved together with the delete.",
    },
    {
      value: "keep",
      title: "Delete anyway",
      description: LEFT_REFERRERS,
    },
  ] satisfies Array<{ value: ReferrersChoice; title: string; description: string }>;

  return (
    <fieldset className="flex flex-col gap-2" disabled={disabled}>
      <legend className="sr-only">Documents using it</legend>
      {options.map((option) => (
        <label
          key={option.value}
          htmlFor={`${name}-${option.value}`}
          className={cn(
            "flex cursor-pointer items-start gap-3 rounded-lg border border-border p-3 transition",
            "not-has-checked:hover:bg-foreground/2 has-checked:border-accent has-checked:bg-accent/5",
            "has-disabled:cursor-not-allowed",
          )}
        >
          <Radio
            id={`${name}-${option.value}`}
            name={name}
            value={option.value}
            checked={value === option.value}
            onChange={() => onValueChange(option.value)}
          />
          <span className="flex min-w-0 flex-1 flex-col gap-0.5 text-sm">
            <span className="font-medium text-foreground">{option.title}</span>
            <span className="text-foreground-secondary">{option.description}</span>
          </span>
        </label>
      ))}
      {value === "replace" && (
        <RelationAddTrigger
          asChild
          to={[entity]}
          locale={locale}
          excludeIds={[documentId]}
          onAdd={(id) => onReplacementChange(id)}
          disabled={disabled}
        >
          <Button variant="outline" className="w-full justify-start">
            {replacementId === null ? (
              <>
                <PlusIcon />
                Choose a {label}
              </>
            ) : isPending ? (
              <Skeleton className="h-4 w-32" />
            ) : (
              <span className="truncate">
                {replacement ? resolveDocumentMeta(entity, replacement).title : "Unknown document"}
              </span>
            )}
          </Button>
        </RelationAddTrigger>
      )}
    </fieldset>
  );
};

type DeleteActionsProps = {
  entity: string;
  documentId: string;
  replacementId: string | null;
  /** Where each action's after-delete work goes, by action index. */
  afterDelete: Map<number, () => Promise<void>>;
};

/** The configured delete actions, once the documents they're told about have loaded. */
const DeleteActions = ({ entity, documentId, replacementId, afterDelete }: DeleteActionsProps) => {
  const entityDef = CMS_CONFIG.entities.find((candidate) => candidate.name === entity);
  const { data: document } = useQuery(getDocumentQueryOptions(entity, documentId));
  const { data: replacement } = useQuery({
    ...getDocumentQueryOptions(entity, replacementId ?? ""),
    enabled: replacementId !== null,
  });
  // Stable per action, so an action can hand work over from an effect without re-running it.
  const handOver = useMemo(
    () =>
      DELETE_ACTIONS.map((_, index) => (run: (() => Promise<void>) | null) => {
        if (run) afterDelete.set(index, run);
        else afterDelete.delete(index);
      }),
    [afterDelete],
  );
  if (!entityDef || !document) return null;

  return (
    <Suspense>
      {DELETE_ACTIONS.map((DeleteAction, index) => (
        <DeleteAction
          key={index}
          entity={entityDef}
          document={document}
          replacement={replacementId !== null ? (replacement ?? null) : null}
          onAfterDelete={handOver[index] ?? (() => {})}
        />
      ))}
    </Suspense>
  );
};

export { DeleteDocumentDialog };
