import type { SlugField } from "@cms/config";
import { cn, IconButton, Input } from "@cms/ui";
import { ArrowClockwiseIcon, LinkIcon } from "@phosphor-icons/react";
import { useDocumentForm } from "../document-form-context";
import type { TypedFieldInputProps } from "./types";

const SlugInput = ({
  id,
  field,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<SlugField>) => {
  const { linkedSlugs, setSlugLinked } = useDocumentForm();
  const hasSource = !!field.source;
  const linked = hasSource && (linkedSlugs[field.name] ?? false);

  const handleManualChange = (next: string) => {
    if (linked) setSlugLinked(field.name, false);
    onChange(next);
  };

  return (
    <div className="flex items-stretch gap-1">
      <Input
        id={id}
        type="text"
        value={value ?? ""}
        onChange={(e) => handleManualChange(e.target.value)}
        invalid={!!invalid}
        disabled={disabled}
        placeholder={field.name}
        aria-describedby={ariaDescribedBy}
        className="flex-1"
      />
      {hasSource && (
        <IconButton
          type="button"
          variant="ghost"
          size="sm"
          aria-label={
            linked
              ? `Linked to ${String(field.source)} — click to unlink`
              : `Regenerate from ${String(field.source)}`
          }
          onClick={() => setSlugLinked(field.name, !linked)}
          disabled={disabled}
          className={cn(linked && "text-positive")}
        >
          {linked ? <LinkIcon /> : <ArrowClockwiseIcon />}
        </IconButton>
      )}
    </div>
  );
};

export { SlugInput };
