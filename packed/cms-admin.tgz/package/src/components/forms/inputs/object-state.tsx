import type { ObjectField } from "@cms/config";
import { Button } from "@cms/ui";
import { XIcon } from "@phosphor-icons/react";
import { createContext, use, useCallback, useMemo } from "react";

type ObjectStateContextValue = {
  canClear: boolean;
  clear: () => void;
  disabled?: boolean;
};

// Provided once per object field around both its label and its input, so the
// label-adjacent "Clear" control can unset the value while the fields render
// lower down — mirrors `ArrayStateProvider`'s label/input coordination.
const ObjectStateContext = createContext<ObjectStateContextValue | null>(null);

const useObjectState = () => {
  const context = use(ObjectStateContext);
  if (!context) throw new Error("useObjectState must be used within an ObjectStateProvider");
  return context;
};

type ObjectStateProviderProps = {
  field: ObjectField;
  value: unknown;
  onChange: (value: unknown) => void;
  disabled?: boolean;
  children: React.ReactNode;
};

const ObjectStateProvider = ({
  field,
  value,
  onChange,
  disabled,
  children,
}: ObjectStateProviderProps) => {
  const clear = useCallback(() => onChange(undefined), [onChange]);
  // Required objects can't be cleared. Array-item objects never reach this provider at
  // all (their `FieldInput` is rendered directly by the array item, bypassing `InputField`
  // and this wrap), so no `parent` check is needed here.
  const canClear = Boolean(value) && !field.required;

  const contextValue = useMemo(() => ({ canClear, clear, disabled }), [canClear, clear, disabled]);

  return <ObjectStateContext value={contextValue}>{children}</ObjectStateContext>;
};

const ObjectClearToggle = () => {
  const { canClear, clear, disabled } = useObjectState();

  if (!canClear) return null;

  return (
    <Button type="button" variant="ghost" size="xs" onClick={clear} disabled={disabled}>
      <XIcon />
      Clear
    </Button>
  );
};

export { ObjectClearToggle, ObjectStateProvider };
