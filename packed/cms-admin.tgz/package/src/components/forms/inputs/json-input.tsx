import type { JsonField } from "@cms/config";
import { cn, IconButton, inputStyle, Tooltip, useTheme } from "@cms/ui";
import { defaultKeymap, history, historyKeymap, indentWithTab } from "@codemirror/commands";
import { json } from "@codemirror/lang-json";
import { Compartment, EditorState } from "@codemirror/state";
import { drawSelection, EditorView, keymap } from "@codemirror/view";
import { githubDark } from "@fsegurai/codemirror-theme-github-dark";
import { githubLight } from "@fsegurai/codemirror-theme-github-light";
import { BracketsCurlyIcon, CheckIcon, ClipboardIcon } from "@phosphor-icons/react";
import { useEffect, useRef, useState } from "react";
import type { TypedFieldInputProps } from "./types";

function normalizeJsonDoc(raw: unknown): string {
  if (raw == null) return "";
  try {
    const obj = typeof raw === "string" ? JSON.parse(raw) : raw;
    return JSON.stringify(obj, null, 2);
  } catch {
    return typeof raw === "string" ? raw : "";
  }
}

const cmsTheme = EditorView.theme({
  "&": {
    outline: "none",
    width: "100%",
    maxHeight: "416px",
    overflow: "hidden",
    background: "transparent !important",
  },
  "&.cm-editor.cm-focused": { outline: "none", boxShadow: "none !important" },
  ".cm-gutters": { background: "transparent !important" },
  ".cm-scroller": {
    fontFamily: "var(--font-mono, ui-monospace, monospace)",
    fontSize: "13px",
    lineHeight: "1.6",
    overflow: "auto",
    maxHeight: "inherit",
    background: "transparent !important",
    scrollbarWidth: "thin",
    scrollbarColor: "var(--color-border) transparent",
  },
  ".cm-scroller::-webkit-scrollbar": { width: "6px", height: "6px" },
  ".cm-scroller::-webkit-scrollbar-track": { background: "transparent" },
  ".cm-scroller::-webkit-scrollbar-thumb": {
    backgroundColor: "var(--color-border)",
    borderRadius: "99px",
  },
  ".cm-content": { padding: "8px", outline: "none" },
  "&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": {
    background: "var(--color-foreground) !important",
    color: "var(--color-background) !important",
  },
});

const JsonInput = ({
  id,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<JsonField>) => {
  const { theme } = useTheme();
  const containerRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const editableCompartmentRef = useRef<Compartment | null>(null);
  const themeCompartmentRef = useRef<Compartment | null>(null);
  const onChangeRef = useRef(onChange);
  const copyTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSetValueRef = useRef<string>("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    onChangeRef.current = onChange;
  });

  // biome-ignore lint/correctness/useExhaustiveDependencies: editor mounts once; disabled and theme are synced via Compartments in effects below; value is synced via the effect below
  useEffect(() => {
    if (!containerRef.current) return;

    const editableCompartment = new Compartment();
    const themeCompartment = new Compartment();
    editableCompartmentRef.current = editableCompartment;
    themeCompartmentRef.current = themeCompartment;

    // Engine deserialises JSONB → JS object on read, but the field schema is z.string()
    // on write. Cast to unknown so we can handle both the object (initial load) and
    // string (value after a save without reload) cases.
    const doc = normalizeJsonDoc(value as unknown);
    lastSetValueRef.current = doc;

    // If the initial value is a non-string (JSONB object from the engine), emit
    // the normalized string immediately so formData holds a string even if the
    // user saves without touching this field.
    if (doc && typeof value !== "string") {
      onChangeRef.current(doc);
    }

    const view = new EditorView({
      state: EditorState.create({
        doc,
        extensions: [
          history(),
          json(),
          drawSelection(),
          keymap.of([indentWithTab, ...defaultKeymap, ...historyKeymap]),
          editableCompartment.of(EditorView.editable.of(!disabled)),
          themeCompartment.of(theme === "dark" ? githubDark : githubLight),
          cmsTheme,
          EditorView.updateListener.of((update) => {
            if (!update.docChanged) return;
            const text = update.state.doc.toString();
            lastSetValueRef.current = text;
            onChangeRef.current(text.trim() ? text : undefined);
          }),
        ],
      }),
      parent: containerRef.current,
    });

    viewRef.current = view;
    return () => view.destroy();
  }, []);

  // Sync the editor when value changes externally (e.g. after a save + refetch).
  // Skips updates that originated from the editor itself by comparing against
  // the last value we set or emitted — avoids cursor resets on every keystroke.
  useEffect(() => {
    const view = viewRef.current;
    if (!view) return;

    const incoming = normalizeJsonDoc(value as unknown);
    const lastSet = normalizeJsonDoc(lastSetValueRef.current);

    if (incoming !== lastSet) {
      view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: incoming } });
      lastSetValueRef.current = incoming;
    }
  }, [value]);

  useEffect(() => {
    const view = viewRef.current;
    const compartment = editableCompartmentRef.current;
    if (!view || !compartment) return;
    view.dispatch({ effects: compartment.reconfigure(EditorView.editable.of(!disabled)) });
  }, [disabled]);

  useEffect(() => {
    const view = viewRef.current;
    const compartment = themeCompartmentRef.current;
    if (!view || !compartment) return;
    view.dispatch({
      effects: compartment.reconfigure(theme === "dark" ? githubDark : githubLight),
    });
  }, [theme]);

  const handleCopy = () => {
    const view = viewRef.current;
    if (!view) return;
    navigator.clipboard.writeText(view.state.doc.toString());
    setCopied(true);
    if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    copyTimeoutRef.current = setTimeout(() => setCopied(false), 3000);
  };

  useEffect(
    () => () => {
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    },
    [],
  );

  const handleFormat = () => {
    const view = viewRef.current;
    if (!view) return;
    const text = view.state.doc.toString();
    try {
      const formatted = JSON.stringify(JSON.parse(text), null, 2);
      view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: formatted } });
    } catch {}
  };

  return (
    <div
      data-invalid={invalid || undefined}
      className={cn(
        inputStyle({ size: "md" }),
        "h-auto flex-col gap-0 items-stretch overflow-hidden p-0! focus-within:ring-4 focus-within:border-accent",
        disabled && "opacity-50 cursor-not-allowed pointer-events-none",
      )}
    >
      <div className="relative">
        <div ref={containerRef} id={id} aria-describedby={ariaDescribedBy} />
        <Tooltip.Group>
          <div className="absolute top-2 right-2 flex gap-1">
            <Tooltip>
              <Tooltip.Trigger asChild>
                <IconButton
                  variant="ghost"
                  size="xs"
                  aria-label="Format"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handleFormat}
                >
                  <BracketsCurlyIcon />
                </IconButton>
              </Tooltip.Trigger>
              <Tooltip.Content>Format</Tooltip.Content>
            </Tooltip>
            <Tooltip>
              <Tooltip.Trigger asChild>
                <IconButton
                  variant="ghost"
                  size="xs"
                  aria-label="Copy"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={handleCopy}
                >
                  {copied ? <CheckIcon /> : <ClipboardIcon />}
                </IconButton>
              </Tooltip.Trigger>
              <Tooltip.Content>{copied ? "Copied!" : "Copy"}</Tooltip.Content>
            </Tooltip>
          </div>
        </Tooltip.Group>
      </div>
    </div>
  );
};

export { JsonInput };
