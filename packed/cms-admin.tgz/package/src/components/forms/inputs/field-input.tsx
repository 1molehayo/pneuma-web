import type { AnyField } from "@cms/config";
import { Skeleton } from "@cms/ui";
import { lazy, Suspense } from "react";
import { ArrayInput } from "./array-input";
import { BooleanInput } from "./boolean-input";
import { DateInput } from "./date-input";
import { JsonInput } from "./json-input";
import { NumberInput } from "./number-input";
import { ObjectInput } from "./object-input";
import { RichTextInput } from "./rich-text-input";
import { SelectInput } from "./select-input";
import { SlugInput } from "./slug-input";
import { TextInput } from "./text-input";
import type { FieldInputProps } from "./types";
import { UnionInput } from "./union-input";

// Lazy — both of these eventually reach the Vite-only `virtual:cms-config` module
// (`relation-input.tsx` imports it directly to look up entity display info for its
// picker; `asset-input.tsx` reaches it via `lib/queries/documents.ts`'s config-dependent
// query factories), which only resolves inside the admin's own Vite bundle. A static
// import of either here would make `FieldInput` unsafe to import from anywhere the
// *engine* also loads a config through (a consumer's `cms.config.tsx`, evaluated in
// plain Node to build routes/schema) — a custom field that stores
// `admin.components.input: FieldInput` only ever holds a *reference* to it there, never
// renders it, so a lazy import is never triggered outside the browser, where it
// resolves normally through Vite.
const LazyRelationInput = lazy(() =>
  import("./relation-input").then((m) => ({ default: m.RelationInput })),
);
const LazyAssetInput = lazy(() => import("./asset-input").then((m) => ({ default: m.AssetInput })));

// `value` is `unknown` at the dispatcher and the per-branch `value as ...`
// casts narrow it. TS can't propagate `field.type` narrowing into the
// sibling `value` parameter — that's a known limitation when iterating over
// a discriminated function-typed union. Alternatives considered:
//   - Runtime type guards: silently coerce bad values, mask bugs.
//   - Zod `safeParse` per render: real perf cost on every keystroke.
//   - Restructure to per-type entry points: replaces the cast with a wider
//     refactor that ends up using casts at component composition sites.
const FieldInput = ({ field, value, ...rest }: FieldInputProps<AnyField>) => {
  if (field.type === "text") {
    return <TextInput field={field} value={value as string} {...rest} />;
  }
  if (field.type === "slug") {
    return <SlugInput field={field} value={value as string} {...rest} />;
  }
  if (field.type === "number") {
    return <NumberInput field={field} value={value as number} {...rest} />;
  }
  if (field.type === "boolean") {
    return <BooleanInput field={field} value={value as boolean} {...rest} />;
  }
  if (field.type === "date") {
    return <DateInput field={field} value={value as string} {...rest} />;
  }
  if (field.type === "select") {
    return <SelectInput field={field} value={value as string} {...rest} />;
  }
  if (field.type === "json") {
    return <JsonInput field={field} value={value as string} {...rest} />;
  }
  if (field.type === "object") {
    return <ObjectInput field={field} value={value as Record<string, unknown>} {...rest} />;
  }
  if (field.type === "relation") {
    // Dispatch to typed asset inputs for the three built-in asset entities
    const targets = Array.isArray(field.to) ? field.to : [field.to];
    // Known synchronously, before the lazy chunk resolves — lets the fallback
    // match the eventual "empty add-trigger" vs. "populated card" shape instead
    // of guessing one and causing a layout jump when the real content lands.
    const hasValue = Array.isArray(value) ? value.length > 0 : value != null;
    const singleTarget = targets.length === 1 ? targets[0] : undefined;
    if (singleTarget === "_image" || singleTarget === "_video" || singleTarget === "_file") {
      return (
        <Suspense fallback={<Skeleton className={hasValue ? "h-26 w-full" : "h-9 w-32"} />}>
          <LazyAssetInput
            types={[singleTarget]}
            field={field}
            value={value as { id: string; _entity: string } | { id: string; _entity: string }[]}
            {...rest}
          />
        </Suspense>
      );
    }
    return (
      <Suspense fallback={<Skeleton className={hasValue ? "h-15 w-full" : "h-9 w-full"} />}>
        <LazyRelationInput
          field={field}
          value={value as { id: string; _entity: string } | { id: string; _entity: string }[]}
          {...rest}
        />
      </Suspense>
    );
  }
  if (field.type === "array") {
    return <ArrayInput field={field} value={value as unknown[]} {...rest} />;
  }
  if (field.type === "richText") {
    return <RichTextInput field={field} value={value as unknown[]} {...rest} />;
  }
  if (field.type === "union") {
    return (
      <UnionInput
        field={field}
        value={value as Record<string, unknown> & { _type: string }}
        {...rest}
      />
    );
  }

  return null;
};

// Re-exported (not used internally — see the array-state.tsx doc comment on why) so a
// consumer rendering `FieldInput` directly for an `array`-type field, outside the normal
// `FieldsRenderer` → `InputField` pipeline, can wrap it in the same provider `InputField`
// would have: `ArrayInput`'s `useArrayState()` reads `field`/`value`/`add`/`remove`/etc.
// entirely from this context, not from the props `FieldInput` passes it — so an unwrapped
// array field throws "useArrayState must be used within an ArrayStateProvider".
export { ArrayStateProvider } from "./array-state";
export type { FieldInputProps };
export { FieldInput };
