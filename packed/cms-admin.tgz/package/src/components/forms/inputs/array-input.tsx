import type { AnyField, ArrayField, RelationField, UnionField } from "@cms/config";
import {
  Button,
  Disclosure,
  Divider,
  Dropdown,
  IconButton,
  Skeleton,
  Slot,
  SortableList,
} from "@cms/ui";
import {
  CopySimpleIcon,
  DotsSixVerticalIcon,
  DotsThreeVerticalIcon,
  PlusIcon,
  TrashIcon,
} from "@phosphor-icons/react";
import { lazy, Suspense } from "react";
import { getNestedErrors } from "@/lib//utils/errors";
import {
  getBlockLabel,
  getPreviewRelation,
  getPreviewValue,
  renderSummarySlot,
} from "@/lib/utils/block-label";
import { useArrayState } from "./array-state";
import { FieldInput } from "./field-input";
import type { FieldInputProps } from "./types";
import { UnionAddTrigger } from "./union-input";

// Lazy for the same reason as `field-input.tsx`'s `LazyRelationInput` — see that file's
// comment. This branch is additionally a dead path today (`array(of: relation())` is
// rejected at config build), but the import still runs at module-evaluation time
// regardless of whether the branch ever executes, so it needs the same treatment.
const LazyRelationAddTrigger = lazy(() =>
  import("./relation-input").then((m) => ({ default: m.RelationAddTrigger })),
);
// Lazy for the same reason: its label reads the entity from `virtual:cms-config`.
const LazyRelationLabel = lazy(() =>
  import("./relation-label").then((m) => ({ default: m.RelationLabel })),
);

type ArrayInputProps = FieldInputProps<ArrayField>;

// Column-storage fields are scalars (text, slug, number, boolean, date, select)
// and render as single-line static rows. Anything else (object, union, array,
// richText, json) gets a collapsible card.
const ArrayInput = ({
  id,
  disabled,
  errors,
  "aria-describedby": ariaDescribedBy,
}: ArrayInputProps) => {
  const {
    field,
    rawItems,
    keys,
    openKeys,
    setOpen,
    add,
    remove,
    duplicate,
    update,
    reorder,
    isCollapsible,
  } = useArrayState();

  const ItemComponent = isCollapsible ? CollapsibleArrayItem : StaticArrayItem;

  // Bounds only constrain a non-empty array (see array()'s "bounds only apply
  // when filled" comment) — an optional field can always be cleared back to 0.
  const nextLength = rawItems.length - 1;
  const belowMin = field.min != null && nextLength < field.min;
  const canRemove = !belowMin || (!field.required && nextLength === 0);
  const canDuplicate = !(field.max != null && rawItems.length >= field.max);

  return (
    <div className="flex flex-col gap-3">
      <SortableList values={keys} onReorder={reorder} id={id} aria-describedby={ariaDescribedBy}>
        {rawItems.map((item, i) => {
          // biome-ignore lint/style/noNonNullAssertion: keysRef loop above guarantees parity with rawItems
          const key = keys[i]!;
          return (
            <SortableList.Item key={key} value={key}>
              <ItemComponent
                item={item}
                field={field}
                onRemove={() => remove(i)}
                onDuplicate={() => duplicate(i)}
                onUpdate={(v: unknown) => update(i, v)}
                errors={errors ? getNestedErrors(errors, String(i)) : undefined}
                disabled={disabled}
                canRemove={canRemove}
                canDuplicate={canDuplicate}
                open={openKeys[key] ?? false}
                onOpenChange={(open) => setOpen(key, open)}
              />
            </SortableList.Item>
          );
        })}
      </SortableList>

      <ArrayAddButton
        field={field}
        onAdd={add}
        disabled={disabled || (field.max != null && rawItems.length >= field.max)}
        asChild
      >
        <Button variant="outline" size="sm" disabled={disabled}>
          <PlusIcon />
          Add item
        </Button>
      </ArrayAddButton>
    </div>
  );
};

type ArrayAddButtonProps = {
  field: ArrayField;
  onAdd: (value?: unknown) => void;
  disabled?: boolean;
  children: React.ReactNode;
  asChild?: boolean;
};

// Renders the appropriate add trigger based on the array's inner field type.
// For unions and relations, the dropdown opens directly — no intermediate empty item.
const ArrayAddButton = ({ field, onAdd, disabled, children, asChild }: ArrayAddButtonProps) => {
  // A union with its own input (a `link()`) picks its variant there, so the item starts empty.
  if (field.of.type === "union" && !field.of.admin?.components?.input) {
    return (
      <UnionAddTrigger
        field={field.of as UnionField}
        onAdd={(v) => onAdd(v)}
        disabled={disabled}
        asChild={asChild}
      >
        {children}
      </UnionAddTrigger>
    );
  }

  if (field.of.type === "relation") {
    // Dead path: array(of: relation()) is rejected at config build. Kept for
    // type safety on the union; the new (id, type) onAdd signature for
    // RelationAddTrigger discards `type` since this branch can't run today.
    return (
      <Suspense fallback={<Skeleton className="h-9 w-32" />}>
        <LazyRelationAddTrigger
          to={[(field.of as RelationField).to].flat()}
          onAdd={(id) => onAdd(id)}
          disabled={disabled}
          asChild={asChild}
        >
          {children}
        </LazyRelationAddTrigger>
      </Suspense>
    );
  }

  const Component = asChild ? Slot : Button;
  return (
    <Component variant="outline" size="sm" onClick={() => onAdd()} disabled={disabled}>
      {children}
    </Component>
  );
};

type ItemInputProps = {
  field: AnyField;
  value: unknown;
  onChange: (value: unknown) => void;
  disabled?: boolean;
  errors?: Record<string, string>;
};

// An item renders its field's custom input when it has one (`array(link())`), as `InputField`
// does for a field of its own.
const ItemInput = ({ field, ...props }: ItemInputProps) => {
  const CustomInput = field.admin?.components?.input;
  if (CustomInput) return <CustomInput Default={FieldInput} field={field} id="" {...props} />;
  return <FieldInput field={field} id="" parent="array" {...props} />;
};

type ArrayItemProps = {
  item: unknown;
  field: ArrayInputProps["field"];
  errors?: ArrayInputProps["errors"];
  disabled?: boolean;
  canRemove?: boolean;
  canDuplicate?: boolean;
  onUpdate: (value: unknown) => void;
  onRemove: () => void;
  onDuplicate: () => void;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
};

const StaticArrayItem = ({
  item,
  field,
  disabled,
  onUpdate,
  onRemove,
  canRemove,
  errors,
}: ArrayItemProps) => (
  <div className="flex gap-2 items-center p-2 bg-background rounded-md border border-border shadow-xs select-none">
    <SortableList.Handle>
      <DotsSixVerticalIcon />
    </SortableList.Handle>
    <Divider orientation="vertical" className="h-8" />
    <div className="px-1 flex-1">
      {/* `field.of` is typed as AnyFieldBase to avoid circular generics in @cms/config
          (see field.ts). Structurally compatible with AnyField at runtime. */}
      <ItemInput
        field={field.of as AnyField}
        value={item}
        onChange={onUpdate}
        disabled={disabled}
        errors={errors}
      />
    </div>
    <Divider orientation="vertical" className="h-8" />
    <IconButton
      variant="ghost"
      aria-label="Remove item"
      onClick={() => onRemove()}
      disabled={!canRemove}
    >
      <TrashIcon />
    </IconButton>
  </div>
);

const CollapsibleArrayItem = ({
  item,
  field,
  disabled,
  onUpdate,
  onRemove,
  onDuplicate,
  canRemove,
  canDuplicate,
  errors,
  open,
  onOpenChange,
}: ArrayItemProps) => {
  const union = field.of.type === "union" ? (field.of as UnionField) : null;
  const currentType = (item as { _type?: string } | undefined)?._type;
  const variant = union?.of.find((candidate) => candidate.typeName === currentType);
  const block = (() => {
    if (!union) return field.of as AnyField;
    if (variant) return variant;
    // An item added through the item field's own input starts empty, with no `_type` yet: it's
    // labelled by the union. One whose `_type` matches no variant is labelled by the stored name.
    return currentType ? { name: currentType } : { name: union.name, title: union.title };
  })();
  const relation = getPreviewRelation(block, item);
  const plainLabel = getBlockLabel(block, item);
  // In a union, a row named by its own value says which variant it is first, muted.
  const variantPrefix = variant && (
    <span className="text-foreground-secondary">{variant.title ?? variant.name} · </span>
  );
  // The summary, the related document or the title path's value; only the type's title without one.
  const label = (() => {
    const summaryTitle = renderSummarySlot(block, "title", item);
    if (summaryTitle !== null)
      return (
        <>
          {variantPrefix}
          {summaryTitle}
        </>
      );
    if (relation) {
      return (
        <Suspense fallback={plainLabel}>
          <LazyRelationLabel relation={relation} prefix={variantPrefix} fallback={plainLabel} />
        </Suspense>
      );
    }
    const value = getPreviewValue(block, item);
    if (value === null) return plainLabel;
    return (
      <>
        {variantPrefix}
        {value}
      </>
    );
  })();
  const VariantIcon = variant && union?.admin?.icons?.[variant.typeName];
  const media =
    renderSummarySlot(block, "media", item) ??
    (VariantIcon ? <VariantIcon className="size-4" /> : null);

  return (
    <div className="flex flex-col bg-background rounded-md border border-border shadow-xs select-none">
      <Disclosure open={open} onOpenChange={onOpenChange}>
        <div className="relative flex gap-2 p-2 items-center">
          {/* Stretched hit target: the whole row toggles the disclosure, while
              the drag handle and menu below sit in normal flow (`relative`)
              so they paint above this and keep receiving their own clicks. */}
          <button
            type="button"
            aria-expanded={open}
            aria-label="Toggle collapse"
            onClick={() => onOpenChange?.(!open)}
            className="absolute inset-0 cursor-pointer rounded-t-md outline-none ring-ring transition-colors hover:bg-foreground/2 active:bg-foreground/4 focus-visible:ring-4"
          />
          <div className="relative">
            <SortableList.Handle>
              <DotsSixVerticalIcon />
            </SortableList.Handle>
          </div>
          <Divider orientation="vertical" className="h-[1em]" />
          <div className="px-2 flex min-w-0 items-center gap-2 text-sm text-foreground mr-auto">
            {media && (
              <span className="flex shrink-0 items-center text-foreground-secondary">{media}</span>
            )}
            <span className="truncate">{label}</span>
          </div>
          <div className="relative">
            <Dropdown>
              <Dropdown.Trigger asChild>
                <IconButton variant="ghost" aria-label="More options">
                  <DotsThreeVerticalIcon />
                </IconButton>
              </Dropdown.Trigger>
              <Dropdown.Items className="w-40">
                <Dropdown.Item onSelect={() => onDuplicate()} disabled={!canDuplicate}>
                  <CopySimpleIcon />
                  Duplicate
                </Dropdown.Item>
                <Dropdown.Divider />
                <Dropdown.Item
                  onSelect={() => onRemove()}
                  disabled={!canRemove}
                  className="text-negative"
                >
                  <TrashIcon />
                  Remove
                </Dropdown.Item>
              </Dropdown.Items>
            </Dropdown>
          </div>
          <Divider orientation="vertical" className="h-[1em]" />
          <Disclosure.Chevron className="pointer-events-none relative text-sm" />
        </div>
        <Disclosure.Content>
          <div className="p-4 border-t border-border">
            <ItemInput
              field={field.of as AnyField}
              value={item}
              onChange={onUpdate}
              disabled={disabled}
              errors={errors}
            />
          </div>
        </Disclosure.Content>
      </Disclosure>
    </div>
  );
};

export { ArrayInput };
