import CMS_CONFIG from "virtual:cms-config";
import type { RelationField } from "@cms/config";
import { isPolymorphicRelation } from "@cms/config";
import {
  Badge,
  Button,
  Dropdown,
  debounce,
  IconButton,
  Skeleton,
  SortableList,
  useDelayedLoading,
} from "@cms/ui";
import { DotsSixVerticalIcon, FileDashedIcon, PlusIcon, TrashIcon } from "@phosphor-icons/react";
import { keepPreviousData, queryOptions, useQuery } from "@tanstack/react-query";
import { type ReactNode, useRef, useState } from "react";
import { useDocumentForm } from "@/components/forms/document-form-context";
import { getMiniDocumentsQueryOptions } from "@/lib/queries/documents";
import { keys } from "@/lib/queries/keys";
import { resolveEntityTitle } from "@/lib/utils/config";
import { buildSearchFilter, resolveDocumentMeta } from "@/lib/utils/documents";
import type { TypedFieldInputProps } from "./types";

// ---------------------------------------------------------------------------
// Polymorphic helpers
// ---------------------------------------------------------------------------

/**
 * A relation value always carries the entity name alongside the id.
 * Previously single-target relations used a plain UUID string — now every
 * relation uses the unified `{id, _entity}` shape.
 */
type RelationValue = { id: string; _entity: string };

function getId(v: RelationValue): string {
  return v.id;
}

/** Normalize the form-prop value into an array regardless of single/multi. */
function asArray(propValue: unknown): RelationValue[] {
  if (propValue === undefined || propValue === null) return [];
  if (Array.isArray(propValue)) return propValue as RelationValue[];
  return [propValue as RelationValue];
}

const getOptionsQueryOptions = (entities: string[], search: string, locale?: string) =>
  queryOptions({
    queryKey: keys.relationOptions(entities, search, locale),
    queryFn: async ({ client }) => {
      const docs = await Promise.all(
        entities.map((entity) => {
          const entityDef = CMS_CONFIG.entities.find((e) => e.name === entity);
          const entityLocale = entityDef?.translatable ? locale : undefined;
          const filter = entityDef ? buildSearchFilter(entityDef, search) : undefined;

          return client.fetchQuery(
            getMiniDocumentsQueryOptions(entity, {
              limit: 10,
              locale: entityLocale,
              ...(filter ? { filter } : {}),
            }),
          );
        }),
      );

      return docs.flatMap((result) => result.data);
    },
  });

// ---------------------------------------------------------------------------
// Add trigger (picker dropdown)
// ---------------------------------------------------------------------------

type RelationAddTriggerProps = {
  /** The entities to pick from. */
  to: string[];
  /** Lists a translatable entity's documents in this locale. */
  locale?: string;
  /** Receives both the picked id and its `_entity` (the source entity name). */
  onAdd: (id: string, type: string) => void;
  disabled?: boolean;
  asChild?: boolean;
  /** IDs already selected — shown as disabled in the dropdown */
  excludeIds?: string[];
  children: ReactNode;
};

const RelationAddTrigger = ({
  to,
  locale,
  onAdd,
  disabled,
  excludeIds = [],
  children,
  asChild,
}: RelationAddTriggerProps) => {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const handleSearch = useRef(debounce((v: string) => setDebouncedSearch(v), 300)).current;

  const { data: options, isPending } = useQuery({
    ...getOptionsQueryOptions(to, debouncedSearch, locale),
    placeholderData: keepPreviousData,
  });
  const showPending = useDelayedLoading(isPending);

  // Show the type badge only when the user has more than one target to pick
  // from. For single-target relations it's noise.
  const showTypeBadge = to.length > 1;

  return (
    <Dropdown>
      <Dropdown.Trigger disabled={disabled} asChild={asChild}>
        {children}
      </Dropdown.Trigger>
      <Dropdown.Items className="w-(--width)">
        <Dropdown.SearchInput
          placeholder="Search…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            handleSearch(e.target.value);
          }}
        />
        {showPending ? (
          new Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-8 m-1" />)
        ) : (
          <>
            {options?.map((option) => {
              const meta = resolveDocumentMeta(option._entity, option);

              return (
                <Dropdown.Item
                  key={option.id}
                  onSelect={() => onAdd(option.id, option._entity)}
                  disabled={excludeIds.includes(option.id)}
                >
                  <figure className="size-9 flex items-center justify-center bg-foreground/4 rounded-md mr-1 -ml-1 [&_img]:size-full *:object-cover overflow-hidden">
                    {meta.media}
                  </figure>
                  <div className="text-left">
                    <div>{meta.title}</div>
                    <div className="text-2xs text-foreground-secondary">{meta.description}</div>
                  </div>
                  {showTypeBadge && (
                    <Badge className="ml-auto" size="xs">
                      {resolveEntityTitle(option._entity)}
                    </Badge>
                  )}
                </Dropdown.Item>
              );
            })}
            {options?.length === 0 && <Dropdown.Empty>No options</Dropdown.Empty>}
          </>
        )}
      </Dropdown.Items>
    </Dropdown>
  );
};

// ---------------------------------------------------------------------------
// Resolved-options fetch (unchanged shape — fetches resolved rows by id)
// ---------------------------------------------------------------------------

type ResolvedOption = {
  id: string;
  _entity: string;
} & Record<string, unknown>;

const useResolvedOptions = (to: string[], ids: string[]) =>
  useQuery({
    enabled: ids.length > 0,
    queryKey: keys.relationSelected(to, ids),
    queryFn: async ({ client }) => {
      const docs = await Promise.all(
        to.map(async (entity) => {
          const { data } = await client.fetchQuery(
            getMiniDocumentsQueryOptions(entity, { filter: { id: { $in: ids } } }),
          );
          return data;
        }),
      );
      return docs.flat() as ResolvedOption[];
    },
  });

// ---------------------------------------------------------------------------
// Item card
// ---------------------------------------------------------------------------

type RelationCardProps = {
  option: ResolvedOption | undefined;
  /** When true (polymorphic or visual consistency), show the `_entity` badge. */
  showTypeBadge?: boolean;
  /** When true, renders a drag handle on the left (for multi-relation lists). */
  draggable?: boolean;
  onRemove: () => void;
  canRemove?: boolean;
};

const RelationCard = ({
  option,
  showTypeBadge,
  draggable,
  onRemove,
  canRemove = true,
}: RelationCardProps) => {
  const meta = option
    ? resolveDocumentMeta(option._entity, option)
    : {
        title: "Unknown document",
        description: "This document is not available",
        media: <FileDashedIcon />,
      };

  const locale = typeof option?.locale === "string" ? option.locale : undefined;

  return (
    <div className="flex gap-4 h-15 items-center text-sm bg-background border border-border p-2 shadow-xs rounded-lg select-none">
      {draggable && (
        <SortableList.Handle>
          <DotsSixVerticalIcon />
        </SortableList.Handle>
      )}
      <figure className="size-10 bg-foreground/4 rounded-sm flex items-center justify-center [&_img]:size-full *:object-cover overflow-hidden">
        {meta.media}
      </figure>
      <div>
        <div>{meta.title}</div>
        <div className="text-2xs text-foreground-secondary">{meta.description}</div>
      </div>
      <div className="flex items-center gap-1.5 ml-auto">
        {locale && (
          <Badge size="xs" variant="info" className="uppercase">
            {locale}
          </Badge>
        )}
        {showTypeBadge && (
          <Badge size="xs">{resolveEntityTitle(option?._entity ?? "Unknown")}</Badge>
        )}
        <IconButton variant="ghost" aria-label="Remove" onClick={onRemove} disabled={!canRemove}>
          <TrashIcon />
        </IconButton>
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// Main input
// ---------------------------------------------------------------------------

const RelationInput = ({
  id,
  field,
  value: propValue,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<RelationField>) => {
  const value = asArray(propValue);
  const ids = value.map(getId);
  const to = Array.isArray(field.to) ? field.to : [field.to];
  const polymorphic = isPolymorphicRelation(field);
  const { formData } = useDocumentForm();
  const editingLocale = typeof formData.locale === "string" ? formData.locale : undefined;

  const { data: options, isPending } = useResolvedOptions(to, ids);
  const showPending = useDelayedLoading(isPending);

  /** Wrap the picked id+entity into the unified relation shape. */
  const buildEntry = (addedId: string, addedEntity: string): RelationValue => ({
    id: addedId,
    _entity: addedEntity,
  });

  const handleAdd = (addedId: string, addedType: string) => {
    const entry = buildEntry(addedId, addedType);
    if (!field.multiple) {
      onChange(entry);
      return;
    }
    // Defensive dedup — `excludeIds` filters the picker but doesn't guard
    // against duplicates entering by other means (programmatic, race, etc.).
    if (ids.includes(addedId)) return;
    onChange([...value, entry]);
  };

  if (field.multiple) {
    const canRemove = !(field.min != null && value.length <= field.min);
    return (
      <div className="flex flex-col gap-3">
        <SortableList
          values={ids}
          onReorder={(reorderedIds) => {
            const byId = new Map(value.map((v) => [getId(v), v]));
            const next = reorderedIds
              .map((rid) => byId.get(rid))
              .filter((v): v is RelationValue => v !== undefined);
            onChange(next);
          }}
          id={id}
          aria-describedby={ariaDescribedBy}
        >
          {value.map((entry, i) => {
            const entryId = getId(entry);
            return (
              <SortableList.Item key={entryId} value={entryId}>
                {showPending ? (
                  <Skeleton className="h-15 w-full" />
                ) : (
                  <RelationCard
                    option={options?.find((o) => o.id === entryId)}
                    draggable
                    showTypeBadge={polymorphic}
                    onRemove={() => onChange(value.filter((_, j) => j !== i))}
                    canRemove={canRemove}
                  />
                )}
              </SortableList.Item>
            );
          })}
        </SortableList>
        <RelationAddTrigger
          asChild
          to={to}
          locale={editingLocale}
          onAdd={handleAdd}
          disabled={disabled || (field.max != null && value.length >= field.max)}
          excludeIds={ids}
        >
          <Button
            id={id}
            aria-describedby={ariaDescribedBy}
            variant="outline"
            className="w-full"
            disabled={disabled}
            data-invalid={invalid}
          >
            <PlusIcon />
            Add
          </Button>
        </RelationAddTrigger>
      </div>
    );
  }

  // Single relation: card (when set) + add button (when empty).
  return (
    <div className="w-full flex flex-col gap-2">
      {value.map((entry) => {
        const entryId = getId(entry);
        return showPending ? (
          <Skeleton key={entryId} className="h-15 w-full" />
        ) : (
          <RelationCard
            key={entryId}
            option={options?.find((o) => o.id === entryId)}
            showTypeBadge={polymorphic}
            onRemove={() => onChange(undefined)}
          />
        );
      })}
      {value.length === 0 && (
        <RelationAddTrigger
          asChild
          to={to}
          locale={editingLocale}
          onAdd={handleAdd}
          disabled={disabled}
          excludeIds={ids}
        >
          <Button
            id={id}
            aria-describedby={ariaDescribedBy}
            variant="outline"
            className="w-full"
            disabled={disabled}
            data-invalid={invalid}
          >
            <PlusIcon />
            Add
          </Button>
        </RelationAddTrigger>
      )}
    </div>
  );
};

export { RelationAddTrigger, RelationInput, useResolvedOptions };
