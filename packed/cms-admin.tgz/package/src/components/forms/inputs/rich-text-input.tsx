import type { RichTextField } from "@cms/config";
import {
  type EditorConfig,
  EditorProvider,
  type PortableTextBlock,
  PortableTextEditable,
} from "@portabletext/editor";
import { EventListenerPlugin, NodePlugin } from "@portabletext/editor/plugins";
import "@portabletext/plugin-table/ui/styles.css";
import { useMemo } from "react";
import { RichTextContext } from "./rich-text/context";
import { buildNodes } from "./rich-text/nodes";
import { table } from "./rich-text/table";
import { Toolbar } from "./rich-text/toolbar";
import { buildSchemaDefinition } from "./rich-text/utils";
import type { TypedFieldInputProps } from "./types";

const RichTextInput = ({
  id,
  field,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<RichTextField>) => {
  // biome-ignore lint/correctness/useExhaustiveDependencies: intentional
  const initialConfig = useMemo<EditorConfig>(
    () => ({
      schemaDefinition: buildSchemaDefinition({
        styles: field.styles,
        decorators: field.decorators,
        lists: field.lists,
        annotations: field.annotations,
        blocks: field.blocks,
        inlineBlocks: field.inlineBlocks,
        table: field.table,
      }),

      initialValue: (value as PortableTextBlock[]) ?? undefined,
      readOnly: disabled,
    }),
    [],
  );
  const nodes = useMemo(() => buildNodes(field), [field]);

  return (
    <RichTextContext value={{ field }}>
      <EditorProvider initialConfig={initialConfig}>
        <NodePlugin nodes={nodes} />
        <EventListenerPlugin
          on={(event) => {
            if (event.type === "mutation") {
              onChange(event.value);
            }
          }}
        />
        <div className="rounded-md border border-border focus-within:ring-2 focus-within:ring-ring focus-within:border-accent">
          <Toolbar field={field} />
          <PortableTextEditable
            id={id}
            aria-describedby={ariaDescribedBy}
            aria-invalid={invalid}
            disabled={disabled}
            className="outline-none min-h-32 px-3 py-2 text-sm"
          />
        </div>
        {field.table ? <table.Plugin /> : null}
      </EditorProvider>
    </RichTextContext>
  );
};

export { RichTextInput };
