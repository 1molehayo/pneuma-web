import type { RelationField } from "@cms/config";
import { Badge, Button, cn, Skeleton } from "@cms/ui";
import { FileIcon, ImageIcon, PencilSimpleIcon, TrashIcon, VideoIcon } from "@phosphor-icons/react";
import { useQueries } from "@tanstack/react-query";
import { Fragment, useMemo } from "react";
import { AssetManager, type AssetType } from "@/components/asset-manager";
import { AssetMedia } from "@/components/asset-media";
import { getDocumentQueryOptions } from "@/lib/queries/documents";
import type { TypedFieldInputProps } from "./types";

type RelationRef = { id: string; _entity: string };

// AssetInput is only invoked for single-target asset relations
// (_image/_video/_file). The form stores `{id, _entity}` objects matching the
// unified relation shape; this input converts to/from plain string IDs
// internally since asset management only needs the UUID.
type AssetInputProps = Omit<TypedFieldInputProps<RelationField>, "value" | "onChange"> & {
  types: [AssetType, ...AssetType[]];
  value: RelationRef | RelationRef[] | null | undefined;
  onChange: (value: RelationRef | RelationRef[] | undefined) => void;
};

export const AssetInput = ({
  types,
  id,
  field,
  value,
  onChange,
  disabled,
  parent,
}: AssetInputProps) => {
  const entityType = types[0];
  // Convert {id, _entity} refs to plain string IDs for internal use.
  const arrayValue = value ? [value].flat().map((v) => v.id) : [];

  const toRef = (assetId: string): RelationRef => ({ id: assetId, _entity: entityType });

  const { label, Icon } = useMemo(() => {
    switch (types[0]) {
      case "_image":
        return {
          label: field.multiple ? "Images" : "Image",
          Icon: ImageIcon,
        };
      case "_video":
        return {
          label: field.multiple ? "Videos" : "Video",
          Icon: VideoIcon,
        };

      case "_file":
        return {
          label: field.multiple ? "Files" : "File",
          Icon: FileIcon,
        };

      default:
        return {
          label: field.multiple ? "Assets" : "Asset",
          Icon: FileIcon,
        };
    }
  }, [field.multiple, types]);

  return (
    <AssetManager
      types={types}
      value={arrayValue}
      onChange={(newValue) => {
        if (field.multiple) {
          onChange(newValue.map(toRef));
        } else {
          const first = newValue[0];
          onChange(first ? toRef(first) : undefined);
        }
      }}
      min={field.multiple || !field.required ? 0 : 1}
      max={field.multiple ? 20 : 1}
    >
      <div className="flex flex-col gap-2">
        {arrayValue.length === 0 ? (
          <AssetManager.Trigger asChild>
            <Button id={id} variant="outline" size="sm" disabled={disabled}>
              <Icon />
              Add {label}
            </Button>
          </AssetManager.Trigger>
        ) : (
          <AssetInputItem
            types={types}
            key={id}
            ids={arrayValue}
            onRemove={() => onChange(field.multiple ? ([] as RelationRef[]) : undefined)}
            parent={parent}
          />
        )}
      </div>
    </AssetManager>
  );
};

type AssetInputItemProps = {
  types: [AssetType, ...AssetType[]];
  ids: string[];
  onRemove: () => void;
  parent?: AssetInputProps["parent"];
};

const AssetInputItem = ({ types, ids, parent, onRemove }: AssetInputItemProps) => {
  const [visibleIds, hiddenIds] = useMemo(() => {
    const visibleIds = ids.slice(0, 3);
    const hiddenIds = ids.slice(3);
    return [visibleIds, hiddenIds];
  }, [ids]);

  const assets = useQueries({
    queries: visibleIds.map((id) => getDocumentQueryOptions(types[0], id)),
  });

  return (
    <div
      className={cn(
        "grid grid-cols-[auto_1fr] gap-4 text-sm ",
        parent !== "array" && "border border-border rounded-lg p-3 shadow-xs",
      )}
    >
      <div
        className="relative [--height:--spacing(20)] [--sub-height:--spacing(2)] w-(--height) h-[calc(var(--height)+var(--length)*var(--sub-height))] @container-[size]"
        style={{ "--length": assets.length - 1 }}
      >
        {assets.map(({ data }, index) => {
          if (!data) {
            return <Skeleton key={index} className="size-full" />;
          }

          return (
            <AssetMedia
              key={data.id}
              asset={data}
              style={{
                zIndex: assets.length - index,
                "--index": index,
              }}
              className={cn(
                "relative aspect-square *:object-cover w-full rounded-sm overflow-hidden",
                index > 0 && [
                  "absolute left-0 origin-bottom",
                  "top-[calc(var(--index)*var(--sub-height))]",
                  "scale-[calc(1-(0.05*var(--index)))]",
                  "after:inset-0 after:absolute after:bg-white after:opacity-[calc(0.2*var(--index))]",
                ],
              )}
            />
          );
        })}
        {hiddenIds.length > 0 && (
          <div className="absolute size-(--height) left-0 bottom-[calc(-1*var(--sub-height))] bg-black/10 rounded-md scale-80 origin-bottom" />
        )}
      </div>
      <div className="flex flex-col gap-3">
        <div>
          {assets.map(({ data }, index) => (
            <Fragment key={index}>
              <p>{data?.filename}</p>
              {assets.length === 1 && <p className="text-foreground-secondary">{data?.mimeType}</p>}
            </Fragment>
          ))}
          {hiddenIds.length > 0 ? (
            <Badge size="xs" className="mt-1">
              +{hiddenIds.length} more
            </Badge>
          ) : null}
        </div>
        <div className="mt-auto flex gap-2">
          <AssetManager.Trigger asChild>
            <Button variant="ghost" size="xs">
              <PencilSimpleIcon />
              Edit
            </Button>
          </AssetManager.Trigger>
          {parent !== "array" && (
            <Button variant="ghost" size="xs" onClick={onRemove}>
              <TrashIcon />
              Remove
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};
