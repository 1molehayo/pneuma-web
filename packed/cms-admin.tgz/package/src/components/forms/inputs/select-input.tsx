import type { SelectField } from "@cms/config";
import { Select } from "@cms/ui";
import type { TypedFieldInputProps } from "./types";

const SelectInput = ({
  id,
  field,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<SelectField>) => {
  return (
    <Select
      id={id}
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      invalid={invalid}
      disabled={disabled}
      aria-describedby={ariaDescribedBy}
    >
      <option value="">Select {field.name}...</option>
      {field.options.map((option) => {
        const val = typeof option === "string" ? option : option.value;
        const label = typeof option === "string" ? option : option.label;
        return (
          <option key={val} value={val}>
            {label}
          </option>
        );
      })}
    </Select>
  );
};

export { SelectInput };
