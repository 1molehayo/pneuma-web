import type { AnyField, InferFieldValue } from "@cms/config";

/**
 * Props passed by the generic dispatcher (`FieldInput`). `value`/`onChange`
 * are `unknown` because TS can't narrow them across an `AnyField` union — the
 * dispatcher branches on `field.type` and forwards to a typed per-type input.
 */
type FieldInputProps<T extends AnyField = AnyField> = {
  field: T;
  id: string;
  value: unknown;
  onChange: (value: unknown) => void;
  disabled?: boolean;
  invalid?: boolean;
  errors?: Record<string, string>;
  "aria-describedby"?: string;
  parent?: "array" | "unknown";
};

/** Per-type input props — value is narrowed via `InferFieldValue<T>`. */
type TypedFieldInputProps<T extends AnyField> = Omit<FieldInputProps<T>, "value" | "onChange"> & {
  value: InferFieldValue<T>;
  onChange: (value: InferFieldValue<T> | undefined) => void;
};

export type { FieldInputProps, TypedFieldInputProps };
