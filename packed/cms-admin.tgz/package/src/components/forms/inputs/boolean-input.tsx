import type { BooleanField } from "@cms/config";
import { Checkbox } from "@cms/ui";
import type { TypedFieldInputProps } from "./types";

const BooleanInput = ({
  id,
  value,
  onChange,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<BooleanField>) => {
  return (
    <Checkbox
      id={id}
      checked={value ?? false}
      onChange={(e) => onChange(e.target.checked)}
      disabled={disabled}
      aria-describedby={ariaDescribedBy}
    />
  );
};

export { BooleanInput };
