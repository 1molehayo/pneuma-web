import CMS_CONFIG from "virtual:cms-config";
import { useQuery } from "@tanstack/react-query";
import type { ReactNode } from "react";
import { getDocumentSummaryQueryOptions } from "@/lib/queries/document-summaries";
import { getDocumentMeta } from "@/lib/utils/document-meta";

type RelationLabelProps = {
  relation: { id: string; _entity: string };
  /** Shown before the title once the document loads, not before `fallback`. */
  prefix?: ReactNode;
  fallback: string;
};

/**
 * A row label for a summary title path that points at a relation: the related document's
 * `admin.summary.title`, or `fallback` until it loads or when the document is gone.
 */
const RelationLabel = ({ relation, prefix, fallback }: RelationLabelProps) => {
  const entity = CMS_CONFIG.entities.find((candidate) => candidate.name === relation._entity);
  if (!entity) throw new Error(`Entity ${relation._entity} not found in CMS config`);
  const { data: document } = useQuery(
    getDocumentSummaryQueryOptions(entity, relation.id, {
      locales: CMS_CONFIG.i18n.locales.map((locale) => locale.value),
    }),
  );
  if (!document) return fallback;
  return (
    <>
      {prefix}
      {getDocumentMeta(entity, document).title}
    </>
  );
};

export { RelationLabel };
