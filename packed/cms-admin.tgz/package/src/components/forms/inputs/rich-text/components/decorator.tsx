import type { DecoratorRender, DecoratorRenderProps } from "@portabletext/editor";
import { useMemo } from "react";
import { useRichText } from "../context";
import { getCustomRenderComponent } from "./utils";

const DEFAULTS: Record<string, DecoratorRender> = {
  strong: ({ children }) => <strong>{children}</strong>,
  em: (props) => <em>{props.children}</em>,
  underline: (props) => <u>{props.children}</u>,
  "strike-through": (props) => <s>{props.children}</s>,
  code: (props) => (
    <code className="rounded bg-foreground/12 px-1 py-0.5 font-mono text-xs">{props.children}</code>
  ),
};

const RichTextDecorator = (props: DecoratorRenderProps) => {
  const { decorator, children } = props;
  const { field } = useRichText();

  const CustomComponent = useMemo(
    () => getCustomRenderComponent(field, "decorators", decorator),
    [field, decorator],
  );

  if (CustomComponent) {
    return <CustomComponent value={decorator}>{children}</CustomComponent>;
  }

  if (DEFAULTS[decorator]) {
    return DEFAULTS[decorator](props);
  }

  return <span>{children}</span>;
};

export { RichTextDecorator };
