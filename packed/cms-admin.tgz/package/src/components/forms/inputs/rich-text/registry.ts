import {
  Code,
  ListBullets,
  ListNumbers,
  Quotes,
  TextB,
  TextHFour,
  TextHOne,
  TextHThree,
  TextHTwo,
  TextItalic,
  TextStrikethrough,
  TextUnderline,
} from "@phosphor-icons/react";

type FeatureEntry = {
  icon?: React.ComponentType;
  title: string;
  name: string;
};

const builtinDecorators: FeatureEntry[] = [
  { name: "strong", title: "Bold", icon: TextB },
  { name: "em", title: "Italic", icon: TextItalic },
  { name: "underline", title: "Underline", icon: TextUnderline },
  { name: "strike-through", title: "Strikethrough", icon: TextStrikethrough },
  { name: "code", title: "Code", icon: Code },
];

const builtinStyles: FeatureEntry[] = [
  { name: "normal", title: "Paragraph" },
  { name: "h1", title: "Heading 1", icon: TextHOne },
  { name: "h2", title: "Heading 2", icon: TextHTwo },
  { name: "h3", title: "Heading 3", icon: TextHThree },
  { name: "h4", title: "Heading 4", icon: TextHFour },
  { name: "blockquote", title: "Blockquote", icon: Quotes },
];

const builtinLists: FeatureEntry[] = [
  { name: "bullet", title: "Bullet List", icon: ListBullets },
  { name: "number", title: "Numbered List", icon: ListNumbers },
];

export type { FeatureEntry };
export { builtinDecorators, builtinLists, builtinStyles };
