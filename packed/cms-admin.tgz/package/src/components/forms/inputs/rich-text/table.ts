import type { BlockObjectDefinition } from "@portabletext/editor";
import { defineTable } from "@portabletext/plugin-table";
import { referenceContainers } from "@portabletext/plugin-table/ui";

/**
 * The built-in table block. Module scope on purpose: `defineTable` binds the
 * container registrations, and a new reference per render would unregister and
 * re-register them on every editor render.
 */
const table = defineTable({ containers: referenceContainers });

/**
 * The schema the editor needs for the blocks `table` produces. The plugin does
 * not define one, so this has to mirror the canonical shape it builds:
 * table -> rows -> cells -> value (regular portable text, inheriting the root
 * schema's styles, decorators, annotations and inline objects).
 */
const tableSchema: BlockObjectDefinition = {
  name: "table",
  title: "Table",
  fields: [
    { name: "headerRows", type: "number" },
    {
      name: "rows",
      type: "array",
      of: [
        {
          type: "object",
          name: "row",
          fields: [
            {
              name: "cells",
              type: "array",
              of: [
                {
                  type: "object",
                  name: "cell",
                  fields: [{ name: "value", type: "array", of: [{ type: "block" }] }],
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};

export { table, tableSchema };
