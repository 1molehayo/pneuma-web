import type { RichTextField } from "@cms/config";
import {
  defineAnnotation,
  defineBlockObject,
  defineDecorator,
  defineInlineObject,
  defineTextBlock,
  type RegistrableNode,
} from "@portabletext/editor";
import { RichTextAnnotation } from "./components/annotation";
import { RichTextBlockObject, RichTextTextBlock } from "./components/block";
import { RichTextDecorator } from "./components/decorator";
import { RichTextInlineBlock } from "./components/inline-block";

/**
 * The editor's render registrations, mounted with `<NodePlugin>`. Renders are
 * plain function calls, so each one returns a component element to keep hooks
 * legal. The table block is left out: `table.Plugin` registers its containers.
 */
const buildNodes = (field: RichTextField): RegistrableNode[] => [
  defineTextBlock({ type: "block", render: (props) => <RichTextTextBlock {...props} /> }),
  defineDecorator({ type: "*", render: (props) => <RichTextDecorator {...props} /> }),
  defineAnnotation({ type: "*", render: (props) => <RichTextAnnotation {...props} /> }),
  ...(field.blocks ?? [])
    .filter((block) => !(field.table && block.name === "table"))
    .map((block) =>
      defineBlockObject({
        type: block.name,
        render: (props) => <RichTextBlockObject {...props} />,
      }),
    ),
  ...(field.inlineBlocks ?? []).map((inlineBlock) =>
    defineInlineObject({
      type: inlineBlock.name,
      render: (props) => <RichTextInlineBlock {...props} />,
    }),
  ),
];

export { buildNodes };
