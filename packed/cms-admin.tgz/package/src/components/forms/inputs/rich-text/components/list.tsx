import { type ReactNode, useMemo } from "react";
import { useRichText } from "../context";
import { getCustomRenderComponent } from "./utils";

type RichTextListItemProps = {
  value: string;
  children: ReactNode;
};

const DEFAULTS: Record<string, (props: RichTextListItemProps) => ReactNode> = {
  bullet: ({ children }) => <li className="list-disc ml-4">{children}</li>,
  number: ({ children }) => <li className="list-decimal ml-4">{children}</li>,
};

const RichTextListItem = (props: RichTextListItemProps) => {
  const { value, children } = props;
  const { field } = useRichText();

  const CustomComponent = useMemo(
    () => getCustomRenderComponent(field, "lists", value),
    [field, value],
  );

  if (CustomComponent) {
    return <CustomComponent value={value}>{children}</CustomComponent>;
  }

  if (DEFAULTS[value]) {
    return DEFAULTS[value](props);
  }

  return <li>{children}</li>;
};

export { RichTextListItem };
