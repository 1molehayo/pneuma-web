import type { RichTextAnnotation, RichTextBlock, RichTextFeature } from "@cms/config";
import { defineSchema } from "@portabletext/editor";
import { builtinDecorators, builtinLists, builtinStyles } from "./registry";
import { tableSchema } from "./table";

const toPortabletextFieldType = (
  type: string,
): "string" | "number" | "boolean" | "array" | "object" => {
  switch (type) {
    case "number":
      return "number";
    case "boolean":
      return "boolean";
    case "object":
    case "union":
    case "json":
      return "object";
    case "array":
    case "richText":
      return "array";
    default:
      return "string";
  }
};

const resolveSchemaEntry = (entry: RichTextFeature | RichTextBlock | RichTextAnnotation) => {
  const name = typeof entry === "string" ? entry : entry.name;

  return {
    name,
    title: name,
    fields:
      typeof entry === "object" && "fields" in entry
        ? entry.fields?.map((f) => ({
            name: f.name,
            type: toPortabletextFieldType(f.type),
          }))
        : [],
  };
};

const buildSchemaDefinition = (resolved: {
  decorators?: RichTextFeature[];
  styles?: RichTextFeature[];
  lists?: RichTextFeature[];
  annotations?: RichTextAnnotation[];
  blocks?: RichTextBlock[];
  inlineBlocks?: RichTextBlock[];
  table?: boolean;
}) => {
  const blockObjects = resolved.blocks?.map(resolveSchemaEntry) ?? [];

  return defineSchema({
    decorators: resolved.decorators?.map(resolveSchemaEntry) || builtinDecorators,
    styles: resolved.styles?.map(resolveSchemaEntry) || builtinStyles,
    lists: resolved.lists?.map(resolveSchemaEntry) || builtinLists,
    annotations: resolved.annotations?.map(resolveSchemaEntry),
    blockObjects: resolved.table
      ? [...blockObjects.filter((b) => b.name !== "table"), tableSchema]
      : blockObjects,
    inlineObjects: resolved.inlineBlocks?.map(resolveSchemaEntry),
  });
};

export { buildSchemaDefinition };
