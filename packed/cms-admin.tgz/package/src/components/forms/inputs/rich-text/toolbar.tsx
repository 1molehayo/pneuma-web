import type { RichTextBlock, RichTextField } from "@cms/config";
import { cn, Drawer, Tooltip } from "@cms/ui";
import {
  ArrowClockwiseIcon,
  ArrowCounterClockwiseIcon,
  CodeIcon,
  LinkIcon,
  ListBulletsIcon,
  ListNumbersIcon,
  PlusIcon,
  PuzzlePieceIcon,
  QuotesIcon,
  TableIcon,
  TextBIcon,
  TextHFiveIcon,
  TextHFourIcon,
  TextHOneIcon,
  TextHSixIcon,
  TextHThreeIcon,
  TextHTwoIcon,
  TextItalicIcon,
  TextStrikethroughIcon,
  TextUnderlineIcon,
} from "@phosphor-icons/react";
import { useEditor } from "@portabletext/editor";
import {
  type ToolbarAnnotationSchemaType,
  type ToolbarBlockObjectSchemaType,
  type ToolbarDecoratorSchemaType,
  type ToolbarInlineObjectSchemaType,
  type ToolbarListSchemaType,
  type ToolbarStyleSchemaType,
  useAnnotationButton,
  useBlockObjectButton,
  useDecoratorButton,
  useHistoryButtons,
  useListButton,
  useStyleSelector,
  useToolbarSchema,
} from "@portabletext/toolbar";
import { useState } from "react";
import { table } from "./table";

type IconComponent = React.ComponentType;

/**
 * Default icons for Portable Text's standard style/decorator/list names. The
 * `@portabletext/toolbar` package ships schema types without icons; we map the
 * conventional names so a user who writes `decorators: ["bold"]` gets the
 * expected glyph without having to wire icons themselves.
 */
const DEFAULT_STYLE_ICONS: Record<string, IconComponent> = {
  h1: TextHOneIcon,
  h2: TextHTwoIcon,
  h3: TextHThreeIcon,
  h4: TextHFourIcon,
  h5: TextHFiveIcon,
  h6: TextHSixIcon,
  blockquote: QuotesIcon,
};

const DEFAULT_DECORATOR_ICONS: Record<string, IconComponent> = {
  strong: TextBIcon,
  bold: TextBIcon,
  em: TextItalicIcon,
  italic: TextItalicIcon,
  code: CodeIcon,
  underline: TextUnderlineIcon,
  "strike-through": TextStrikethroughIcon,
  strikethrough: TextStrikethroughIcon,
};

const DEFAULT_LIST_ICONS: Record<string, IconComponent> = {
  bullet: ListBulletsIcon,
  number: ListNumbersIcon,
};

const DEFAULT_ANNOTATION_ICONS: Record<string, IconComponent> = {
  link: LinkIcon,
};

type ToolbarProps = {
  field: RichTextField;
};

const Toolbar = ({ field }: ToolbarProps) => {
  const toolbarSchema = useToolbarSchema({
    extendAnnotation: (schema) => {
      const icon = field.annotations?.find((b) => b.name === schema.name)?.icon;
      return { ...schema, icon };
    },
    extendBlockObject: (schema) => {
      const icon = field.blocks?.find((b) => b.name === schema.name)?.icon;
      return { ...schema, icon };
    },
    extendInlineObject: (schema) => {
      const icon = field.inlineBlocks?.find((b) => b.name === schema.name)?.icon;
      return { ...schema, icon };
    },
  });

  const styles = toolbarSchema.styles?.filter((s) => s.name !== "normal") ?? [];
  const decorators = toolbarSchema.decorators ?? [];
  const lists = toolbarSchema.lists ?? [];
  const annotations = toolbarSchema.annotations ?? [];
  const tableSchemaType = field.table
    ? toolbarSchema.blockObjects?.find((b) => b.name === "table")
    : undefined;
  const blockObjects =
    (tableSchemaType
      ? toolbarSchema.blockObjects?.filter((b) => b.name !== "table")
      : toolbarSchema.blockObjects) ?? [];
  const inlineObjects = toolbarSchema.inlineObjects ?? [];

  return (
    <div className="flex flex-wrap items-center gap-0.5 border-b border-border px-2 py-1.5">
      {styles.map((entry) => (
        <StyleButton key={entry.name} schemaType={entry} schemaTypes={styles} />
      ))}
      <Divider />
      {decorators.map((entry) => (
        <DecoratorButton key={entry.name} schemaType={entry} />
      ))}
      <Divider />
      {lists.map((entry) => (
        <ListButton key={entry.name} schemaType={entry} />
      ))}
      <Divider />
      {annotations.map((entry) => (
        <AnnotationButton key={entry.name} schemaType={entry} />
      ))}
      <Divider />
      {tableSchemaType ? <InsertTableButton schemaType={tableSchemaType} /> : null}
      <InsertObjectButton field={field} blockObjects={blockObjects} inlineObjects={inlineObjects} />

      <div className="flex gap-0.5 ml-auto items-center">
        <Divider />
        <HistoryButtons />
      </div>
    </div>
  );
};

const HistoryButtons = () => {
  const { send, snapshot } = useHistoryButtons();

  return (
    <>
      <ToolbarButton
        disabled={snapshot.matches("disabled")}
        onClick={() => send({ type: "history.undo" })}
        aria-label="Undo"
      >
        <ArrowCounterClockwiseIcon />
      </ToolbarButton>
      <ToolbarButton
        disabled={snapshot.matches("disabled")}
        onClick={() => send({ type: "history.redo" })}
        aria-label="Redo"
      >
        <ArrowClockwiseIcon />
      </ToolbarButton>
    </>
  );
};

type ToobarButtonProps = React.ComponentPropsWithRef<"button"> & {
  active?: boolean;
};

const ToolbarButton = ({
  active,
  children,
  className,
  type = "button",
  ...props
}: ToobarButtonProps) => {
  return (
    <button
      type={type}
      className={cn(
        "flex items-center justify-center rounded px-1.5 py-1 text-sm font-medium transition-colors cursor-pointer ",
        "hover:bg-foreground/4 active:bg-foreground/8 disabled:pointer-events-none disabled:opacity-50",
        active ? "bg-foreground/10 text-foreground" : "text-muted hover:text-foreground",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
};

const Divider = () => {
  return <div data-divider className="mx-1 h-4 w-px bg-border [&+[data-divider]]:hidden" />;
};

const StyleButton = ({
  schemaType,
  schemaTypes,
}: {
  schemaType: ToolbarStyleSchemaType;
  schemaTypes: ReadonlyArray<ToolbarStyleSchemaType>;
}) => {
  const { send, snapshot } = useStyleSelector({ schemaTypes });
  const active = snapshot.context.activeStyle === schemaType.name;

  const Icon = schemaType.icon || DEFAULT_STYLE_ICONS[schemaType.name] || PlusIcon;
  return (
    <ToolbarButton
      active={active}
      disabled={snapshot.matches("disabled")}
      onClick={() => send({ type: "toggle", style: schemaType.name })}
      aria-label={schemaType.name}
    >
      <Icon />
    </ToolbarButton>
  );
};

const DecoratorButton = ({ schemaType }: { schemaType: ToolbarDecoratorSchemaType }) => {
  const { send, snapshot } = useDecoratorButton({ schemaType });

  const Icon = schemaType.icon || DEFAULT_DECORATOR_ICONS[schemaType.name] || PlusIcon;
  return (
    <ToolbarButton
      active={snapshot.matches({ enabled: "active" })}
      disabled={snapshot.matches("disabled")}
      onClick={() => send({ type: "toggle" })}
      aria-label={schemaType.name}
    >
      <Icon />
    </ToolbarButton>
  );
};

const ListButton = ({ schemaType }: { schemaType: ToolbarListSchemaType }) => {
  const { send, snapshot } = useListButton({ schemaType });

  const Icon = schemaType.icon || DEFAULT_LIST_ICONS[schemaType.name] || PlusIcon;
  return (
    <ToolbarButton
      active={snapshot.matches({ enabled: "active" })}
      disabled={snapshot.matches("disabled")}
      onClick={() => send({ type: "toggle" })}
      aria-label={schemaType.name}
    >
      <Icon />
    </ToolbarButton>
  );
};

const AnnotationButton = ({ schemaType }: { schemaType: ToolbarAnnotationSchemaType }) => {
  const { send, snapshot } = useAnnotationButton({ schemaType });
  const active = snapshot.matches({ enabled: "active" });

  const Icon = schemaType.icon || DEFAULT_ANNOTATION_ICONS[schemaType.name] || PlusIcon;

  return (
    <ToolbarButton
      active={active}
      disabled={snapshot.matches("disabled")}
      onClick={() => {
        if (active) {
          send({ type: "remove" });
        } else {
          send({
            type: "add",
            annotation: { value: schemaType.defaultValues ?? {} },
          });
        }
      }}
      aria-label={schemaType.name}
    >
      <Icon />
    </ToolbarButton>
  );
};

const InsertTableButton = ({ schemaType }: { schemaType: ToolbarBlockObjectSchemaType }) => {
  const editor = useEditor();
  const { snapshot } = useBlockObjectButton({ schemaType });

  return (
    <Tooltip>
      <Tooltip.Trigger asChild>
        <ToolbarButton
          disabled={snapshot.matches("disabled")}
          onClick={() => {
            editor.send({
              type: "insert.block",
              block: table.createBlock({ headerRows: 1 }),
              placement: "auto",
            });
            editor.send({ type: "focus" });
          }}
          aria-label="Insert table"
        >
          <TableIcon />
        </ToolbarButton>
      </Tooltip.Trigger>
      <Tooltip.Content>Insert table</Tooltip.Content>
    </Tooltip>
  );
};

type InsertObjectButtonProps = {
  field: RichTextField;
  blockObjects: ReadonlyArray<ToolbarBlockObjectSchemaType>;
  inlineObjects: ReadonlyArray<ToolbarInlineObjectSchemaType>;
};

/** Single `+` entry point: opens a drawer listing every block and inline object to insert. */
const InsertObjectButton = ({ field, blockObjects, inlineObjects }: InsertObjectButtonProps) => {
  const editor = useEditor();
  const [open, setOpen] = useState(false);

  if (blockObjects.length === 0 && inlineObjects.length === 0) return null;

  const insert = (event: Parameters<typeof editor.send>[0]) => {
    editor.send(event);
    editor.send({ type: "focus" });
    setOpen(false);
  };

  return (
    <>
      <Divider />
      <Tooltip>
        <Tooltip.Trigger asChild>
          <ToolbarButton onClick={() => setOpen(true)} aria-label="Insert object">
            <PlusIcon />
          </ToolbarButton>
        </Tooltip.Trigger>
        <Tooltip.Content>Insert block</Tooltip.Content>
      </Tooltip>
      <Drawer open={open} onOpenChange={setOpen}>
        <Drawer.Content>
          <Drawer.Header>
            <Drawer.Title>Insert block</Drawer.Title>
          </Drawer.Header>
          <div className="flex flex-col gap-4">
            <ObjectSection
              title="Blocks"
              schemaTypes={blockObjects}
              configured={field.blocks}
              onPick={(schemaType) =>
                insert({
                  type: "insert.block object",
                  blockObject: { name: schemaType.name, value: schemaType.defaultValues ?? {} },
                  placement: "auto",
                })
              }
            />
            <ObjectSection
              title="Inline"
              schemaTypes={inlineObjects}
              configured={field.inlineBlocks}
              onPick={(schemaType) =>
                insert({
                  type: "insert.inline object",
                  inlineObject: { name: schemaType.name, value: schemaType.defaultValues ?? {} },
                })
              }
            />
          </div>
        </Drawer.Content>
      </Drawer>
    </>
  );
};

type InsertableSchemaType = ToolbarBlockObjectSchemaType | ToolbarInlineObjectSchemaType;

const ObjectSection = <TSchemaType extends InsertableSchemaType>({
  title,
  schemaTypes,
  configured,
  onPick,
}: {
  title: string;
  schemaTypes: ReadonlyArray<TSchemaType>;
  configured: RichTextBlock[] | undefined;
  onPick: (schemaType: TSchemaType) => void;
}) => {
  if (schemaTypes.length === 0) return null;

  return (
    <div className="flex flex-col gap-1">
      <span className="px-1 text-xs font-medium text-foreground-secondary uppercase">{title}</span>
      {schemaTypes.map((schemaType) => {
        const Icon = schemaType.icon || PuzzlePieceIcon;
        const label = configured?.find((b) => b.name === schemaType.name)?.title ?? schemaType.name;

        return (
          <button
            key={schemaType.name}
            type="button"
            onClick={() => onPick(schemaType)}
            className="flex w-full cursor-pointer items-center gap-3 rounded-lg border border-transparent px-3 py-2.5 text-left transition-colors hover:border-border hover:bg-foreground/4"
          >
            <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-foreground/4 text-foreground-secondary">
              <Icon className="size-4" />
            </span>
            <span className="text-sm font-medium text-foreground">{label}</span>
          </button>
        );
      })}
    </div>
  );
};

export { Toolbar };
