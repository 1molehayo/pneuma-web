import type { RichTextField } from "@cms/config";

const getCustomRenderComponent = (
  field: RichTextField,
  type: "decorators" | "annotations" | "styles" | "lists",
  value: string,
) => {
  const feature = field[type]?.find((customFeature) => {
    return typeof customFeature === "object" && customFeature.name === value;
  });

  return (typeof feature === "object" && feature.render) || null;
};

const getCustomBlockRenderComponent = (
  field: RichTextField,
  type: "blocks" | "inlineBlocks",
  name: string,
) => {
  const feature = field[type]?.find((customFeature) => {
    return typeof customFeature === "object" && customFeature.name === name;
  });

  return (typeof feature === "object" && feature.render) || null;
};

export { getCustomBlockRenderComponent, getCustomRenderComponent };
