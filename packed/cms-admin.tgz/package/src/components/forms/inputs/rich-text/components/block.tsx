import { cn, IconButton } from "@cms/ui";
import { TrashIcon } from "@phosphor-icons/react";
import {
  type BlockObjectRenderProps,
  type TextBlockRenderProps,
  useEditor,
} from "@portabletext/editor";
import { getBlockLabel, renderSummarySlot } from "@/lib/utils/block-label";
import { useRichText } from "../context";
import { RichTextListItem } from "./list";
import { ObjectFields } from "./object-fields";
import { RichTextStyle } from "./style";

const RichTextTextBlock = ({ attributes, children, node }: TextBlockRenderProps) => {
  const content = <RichTextStyle value={node.style ?? "normal"}>{children}</RichTextStyle>;

  return (
    <div {...attributes} className="py-0.5">
      {node.listItem ? (
        <RichTextListItem value={node.listItem}>{content}</RichTextListItem>
      ) : (
        content
      )}
    </div>
  );
};

const RichTextBlockObject = ({ attributes, children, node, path }: BlockObjectRenderProps) => {
  const name = node._type;
  const editor = useEditor();
  const { field } = useRichText();

  const object = field.blocks?.find((b) => b.name === name);

  if (!object) {
    return (
      <div {...attributes}>
        {children}
        <div className="bg-destructive/10 px-4 py-2">Unknown inline-block</div>
      </div>
    );
  }

  const label = getBlockLabel(object, node);
  const media = renderSummarySlot(object, "media", node);

  return (
    <div {...attributes}>
      {children}
      <ObjectFields>
        <div className="my-2 flex items-center gap-1 rounded-lg border border-border pr-2">
          <ObjectFields.Trigger
            className={cn(
              "flex-1 rounded-l-lg px-4 py-2 text-left",
              "hover:bg-foreground/4 cursor-pointer active:bg-foreground/6",
              media && "flex items-center gap-2",
            )}
          >
            {media}
            {renderSummarySlot(object, "title", node) ?? label}
          </ObjectFields.Trigger>
          <IconButton
            variant="ghost"
            className="text-negative not-disabled:hover:bg-negative/8"
            aria-label={`Remove ${label}`}
            onClick={() => editor.send({ type: "delete.block", at: path as [{ _key: string }] })}
          >
            <TrashIcon />
          </IconButton>
        </div>
        <ObjectFields.Form
          title={label}
          fields={object.fields}
          data={node}
          onSave={(newData) => {
            editor.send({
              type: "block.set",
              at: path as [{ _key: string }],
              props: newData,
            });
          }}
        />
      </ObjectFields>
    </div>
  );
};

export { RichTextBlockObject, RichTextTextBlock };
