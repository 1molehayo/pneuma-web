import { cn } from "@cms/ui";
import { type InlineObjectRenderProps, useEditor } from "@portabletext/editor";
import { getBlockLabel, renderSummarySlot } from "@/lib/utils/block-label";
import { useRichText } from "../context";
import { ObjectFields } from "./object-fields";

const RichTextInlineBlock = ({ attributes, children, node, path }: InlineObjectRenderProps) => {
  const name = node._type;
  const editor = useEditor();
  const { field } = useRichText();

  const object = field.inlineBlocks?.find((b) => b.name === name);

  if (!object) {
    return (
      <span {...attributes}>
        {children}
        <span className="bg-destructive/10 px-2 py-1">Unknown inline-block</span>
      </span>
    );
  }

  const label = getBlockLabel(object, node);

  return (
    <span {...attributes}>
      {children}
      <ObjectFields>
        <ObjectFields.Trigger
          className={cn(
            "border border-border rounded-md px-2 py-1 w-full text-left my-2",
            "hover:bg-foreground/4 cursor-pointer active:bg-foreground/6",
          )}
        >
          <div className="flex items-center gap-2">
            {renderSummarySlot(object, "media", node)}
            {renderSummarySlot(object, "title", node) ?? label}
          </div>
        </ObjectFields.Trigger>
        <ObjectFields.Form
          title={label}
          fields={object.fields}
          data={node}
          onSave={(newData) => {
            editor.send({
              type: "child.set",
              at: path,
              props: newData,
            });
          }}
        />
      </ObjectFields>
    </span>
  );
};

export { RichTextInlineBlock };
