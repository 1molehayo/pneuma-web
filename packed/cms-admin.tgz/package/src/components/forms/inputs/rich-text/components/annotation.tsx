import { type AnnotationRenderProps, useEditor } from "@portabletext/editor";
import { useMemo } from "react";
import { useRichText } from "../context";
import { ObjectFields } from "./object-fields";
import { getCustomRenderComponent } from "./utils";

const RichTextAnnotation = ({ children, ...props }: AnnotationRenderProps) => {
  const name = props.annotation._type;
  const { field } = useRichText();

  const CustomComponent = useMemo(
    () => getCustomRenderComponent(field, "annotations", name),
    [field, name],
  );

  if (CustomComponent) {
    return (
      <RichTextAnnotationEditor {...props}>
        <CustomComponent value={name}>{children}</CustomComponent>
      </RichTextAnnotationEditor>
    );
  }

  return (
    <RichTextAnnotationEditor {...props}>
      <span className="text-accent underline">{children}</span>
    </RichTextAnnotationEditor>
  );
};

const RichTextAnnotationEditor = ({
  children,
  path,
  annotation,
}: Pick<AnnotationRenderProps, "path" | "annotation"> & { children: React.ReactNode }) => {
  const name = annotation._type;
  const editor = useEditor();
  const { field } = useRichText();

  const object = field.annotations?.find((b) => b.name === name);

  if (!object) {
    return <span className="bg-destructive/10 px-2 py-1">Unknown inline-block</span>;
  }

  return (
    <ObjectFields>
      <ObjectFields.Trigger>{children}</ObjectFields.Trigger>
      <ObjectFields.Form
        title={name}
        fields={object.fields}
        data={annotation}
        onSave={(newData) => {
          editor.send({
            type: "annotation.set",
            // `path` points at the span (`…block.children[span]`); drop those two
            // segments to reach the block, keeping any ancestors (table cells).
            at: [...path.slice(0, -2), "markDefs", { _key: annotation._key }],
            props: newData,
          });
        }}
      />
    </ObjectFields>
  );
};

export { RichTextAnnotation };
