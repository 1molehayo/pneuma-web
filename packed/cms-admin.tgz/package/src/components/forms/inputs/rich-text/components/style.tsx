import { type ReactNode, useMemo } from "react";
import { useRichText } from "../context";
import { getCustomRenderComponent } from "./utils";

type RichTextStyleProps = {
  value: string;
  children: ReactNode;
};

const DEFAULTS: Record<string, (props: RichTextStyleProps) => ReactNode> = {
  normal: ({ children }) => <p>{children}</p>,
  h1: ({ children }) => <h1 className="text-2xl font-bold">{children}</h1>,
  h2: ({ children }) => <h2 className="text-xl font-bold">{children}</h2>,
  h3: ({ children }) => <h3 className="text-lg font-semibold">{children}</h3>,
  h4: ({ children }) => <h4 className="text-base font-semibold">{children}</h4>,
  h5: ({ children }) => <h5 className="font-semibold">{children}</h5>,
  h6: ({ children }) => <h6 className="font-semibold">{children}</h6>,
  blockquote: ({ children }) => (
    <blockquote className="border-l-2 border-border pl-3 italic text-muted">{children}</blockquote>
  ),
};

const RichTextStyle = (props: RichTextStyleProps) => {
  const { value, children } = props;
  const { field } = useRichText();

  const CustomComponent = useMemo(
    () => getCustomRenderComponent(field, "styles", value),
    [field, value],
  );

  if (CustomComponent) {
    return <CustomComponent value={value}>{children}</CustomComponent>;
  }

  if (DEFAULTS[value]) {
    return DEFAULTS[value](props);
  }

  return <p>{children}</p>;
};

export { RichTextStyle };
