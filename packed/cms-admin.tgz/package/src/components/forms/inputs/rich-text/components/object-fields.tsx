import type { AnyField } from "@cms/config";
import { Button, Dialog, Portal } from "@cms/ui";
import { useState } from "react";
import { FieldsRenderer } from "@/components/forms/fields-renderer";

/**
 * Shared form for editing fields on block objects, inline objects, and annotations.
 * Manages local state and calls `onSave` when the user clicks Apply.
 */

type ObjectFieldsProps = {
  children: React.ReactNode;
};

const ObjectFields = ({ children }: ObjectFieldsProps) => {
  return <Dialog>{children}</Dialog>;
};

const ObjectFieldsTrigger = Dialog.Trigger;

type ObjectFieldsFormProps = {
  title: string;
  fields: ReadonlyArray<AnyField>;
  data: Record<string, unknown>;
  onSave: (data: Record<string, unknown>) => void;
};

const ObjectFieldsForm = ({ title, ...body }: ObjectFieldsFormProps) => {
  return (
    <Portal>
      <Dialog.Content className="md:max-w-2xl">
        <Dialog.Title>Edit {title}</Dialog.Title>
        <ObjectFieldsFormBody {...body} />
      </Dialog.Content>
    </Portal>
  );
};

const ObjectFieldsFormBody = ({
  fields,
  data: initialData,
  onSave,
}: Omit<ObjectFieldsFormProps, "title">) => {
  const [data, setData] = useState<Record<string, unknown>>(() => ({
    ...initialData,
  }));

  return (
    <div className="mt-4 flex flex-col gap-2">
      <FieldsRenderer fields={fields} value={data} onChange={setData} />
      <Dialog.Actions>
        <Dialog.Close asChild onClick={() => onSave(data)}>
          <Button size="sm">Apply</Button>
        </Dialog.Close>
        <Dialog.Close asChild>
          <Button size="sm" variant="outline">
            Discard
          </Button>
        </Dialog.Close>
      </Dialog.Actions>
    </div>
  );
};

const CompoundObjectFields = Object.assign(ObjectFields, {
  Trigger: ObjectFieldsTrigger,
  Form: ObjectFieldsForm,
});

export { CompoundObjectFields as ObjectFields };
