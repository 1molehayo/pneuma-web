import type { RichTextField } from "@cms/config";
import { createContext, use } from "react";

const RichTextContext = createContext<{
  field: RichTextField;
} | null>(null);

const useRichText = () => {
  const ctx = use(RichTextContext);

  if (!ctx) {
    throw new Error("useRichText must be used within a RichTextInput component.");
  }

  return ctx;
};

export { RichTextContext, useRichText };
