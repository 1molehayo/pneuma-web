import type { TextField } from "@cms/config";
import { Input, Textarea } from "@cms/ui";
import type { TypedFieldInputProps } from "./types";

const TextInput = ({
  id,
  field,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<TextField>) => {
  const placeholder = field.placeholder ?? field.title ?? field.name;

  if (field.rows && field.rows > 1) {
    return (
      <Textarea
        id={id}
        rows={field.rows}
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value)}
        invalid={!!invalid}
        disabled={disabled}
        placeholder={placeholder}
        aria-describedby={ariaDescribedBy}
      />
    );
  }

  return (
    <Input
      id={id}
      type={field.name === "password" ? "password" : "text"}
      value={value ?? ""}
      onChange={(e) => onChange(e.target.value)}
      invalid={!!invalid}
      disabled={disabled}
      placeholder={placeholder}
      aria-describedby={ariaDescribedBy}
    />
  );
};

export { TextInput };
