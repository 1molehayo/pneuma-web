import type { ArrayField } from "@cms/config";
import { Button } from "@cms/ui";
import { createContext, use, useCallback, useMemo, useRef, useState } from "react";

type ArrayStateContextValue = {
  field: ArrayField;
  rawItems: unknown[];
  keys: string[];
  openKeys: Record<string, boolean>;
  setOpen: (key: string, open: boolean) => void;
  add: (value?: unknown) => void;
  remove: (index: number) => void;
  duplicate: (index: number) => void;
  update: (index: number, value: unknown) => void;
  reorder: (keys: string[]) => void;
  isCollapsible: boolean;
  allOpen: boolean;
  toggleAll: () => void;
  disabled?: boolean;
};

// Provided once per array field (including nested ones) around both its label
// and its input, so the "Expand all" control can sit next to the label while
// the rows themselves render lower down — both read the same state.
const ArrayStateContext = createContext<ArrayStateContextValue | null>(null);

const useArrayState = () => {
  const context = use(ArrayStateContext);
  if (!context) throw new Error("useArrayState must be used within an ArrayStateProvider");
  return context;
};

// Mounted once by `InputField` around the *whole* array field's root (label + input),
// never by `FieldInput`/`ArrayInput` themselves — `ArrayRootDefault`'s label-adjacent
// `ArrayCollapseToggle` ("Expand all") needs the same provider instance the input's rows
// read, so it has to wrap both siblings from one level up. `field-input.tsx` re-exports
// this for consumers rendering `FieldInput` directly for an array field outside that
// pipeline (a custom field's own array-of-union, say) to replicate the same wrap — do NOT
// have `FieldInput` wrap itself here, or a normal admin array field would end up with two
// independent provider instances (InputField's outer one, FieldInput's inner one), and
// "Expand all" would silently stop affecting the rows it's supposed to control.
type ArrayStateProviderProps = {
  field: ArrayField;
  value: unknown;
  onChange: (value: unknown) => void;
  disabled?: boolean;
  children: React.ReactNode;
};

const ArrayStateProvider = ({
  field,
  value,
  onChange,
  disabled,
  children,
}: ArrayStateProviderProps) => {
  const rawItems = (value as unknown[]) ?? [];
  const keysRef = useRef<string[]>([]);

  while (keysRef.current.length < rawItems.length) {
    keysRef.current.push(crypto.randomUUID());
  }
  keysRef.current.length = rawItems.length;
  const keys = keysRef.current;

  // Existing items load collapsed; a freshly added one opens immediately so the
  // editor lands on its fields instead of having to expand it themselves.
  const [openKeys, setOpenKeys] = useState<Record<string, boolean>>({});

  const add = useCallback(
    (itemValue?: unknown) => {
      const newKey = crypto.randomUUID();
      keysRef.current = [...keysRef.current, newKey];
      setOpenKeys((prev) => ({ ...prev, [newKey]: true }));
      onChange([...rawItems, itemValue ?? (field.of.type === "object" ? {} : undefined)]);
    },
    [rawItems, onChange, field.of.type],
  );

  const remove = useCallback(
    (index: number) => {
      keysRef.current = keysRef.current.filter((_, j) => j !== index);
      onChange(rawItems.filter((_, j) => j !== index));
    },
    [rawItems, onChange],
  );

  const duplicate = useCallback(
    (index: number) => {
      const newKey = crypto.randomUUID();
      const nextKeys = [...keysRef.current];
      nextKeys.splice(index + 1, 0, newKey);
      keysRef.current = nextKeys;
      setOpenKeys((prev) => ({ ...prev, [newKey]: true }));

      const nextItems = [...rawItems];
      nextItems.splice(index + 1, 0, structuredClone(rawItems[index]));
      onChange(nextItems);
    },
    [rawItems, onChange],
  );

  const update = useCallback(
    (index: number, itemValue: unknown) => {
      const next = [...rawItems];
      next[index] = itemValue;
      onChange(next);
    },
    [rawItems, onChange],
  );

  const reorder = useCallback(
    (reorderedKeys: string[]) => {
      const reordered = reorderedKeys.map((k) => rawItems[keys.indexOf(k)]);
      keysRef.current = reorderedKeys;
      onChange(reordered);
    },
    [rawItems, keys, onChange],
  );

  const setOpen = useCallback((key: string, open: boolean) => {
    setOpenKeys((prev) => (prev[key] === open ? prev : { ...prev, [key]: open }));
  }, []);

  const isCollapsible = field.of.storage !== "column";
  const allOpen = isCollapsible && keys.length > 0 && keys.every((key) => openKeys[key]);

  const toggleAll = useCallback(() => {
    setOpenKeys(Object.fromEntries(keys.map((key) => [key, !allOpen])));
  }, [keys, allOpen]);

  const contextValue = useMemo(
    () => ({
      field,
      rawItems,
      keys,
      openKeys,
      setOpen,
      add,
      remove,
      update,
      reorder,
      isCollapsible,
      allOpen,
      toggleAll,
      disabled,
      duplicate,
    }),
    [
      field,
      rawItems,
      keys,
      openKeys,
      setOpen,
      add,
      remove,
      update,
      reorder,
      isCollapsible,
      allOpen,
      toggleAll,
      disabled,
      duplicate,
    ],
  );

  return <ArrayStateContext value={contextValue}>{children}</ArrayStateContext>;
};

const ArrayCollapseToggle = () => {
  const { isCollapsible, keys, allOpen, toggleAll, disabled } = useArrayState();

  if (!isCollapsible || keys.length === 0) return null;

  return (
    <Button type="button" variant="ghost" size="sm" onClick={toggleAll} disabled={disabled}>
      {allOpen ? "Collapse all" : "Expand all"}
    </Button>
  );
};

export { ArrayCollapseToggle, ArrayStateProvider, useArrayState };
