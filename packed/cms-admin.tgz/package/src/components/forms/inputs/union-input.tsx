import type { PickerDefaultProps, UnionField } from "@cms/config";
import { Button, cn, Dropdown, IconButton } from "@cms/ui";
import { PlusIcon, TrashIcon, WarningIcon } from "@phosphor-icons/react";
import { FieldsRenderer } from "../fields-renderer";
import type { FieldInputProps } from "./types";

const UnionDropdown = ({ field, onAdd, disabled, asChild, children }: PickerDefaultProps) => (
  <Dropdown>
    <Dropdown.Trigger asChild={asChild} disabled={disabled}>
      {children}
    </Dropdown.Trigger>
    <Dropdown.Items>
      {field.of.map((variant) => (
        <Dropdown.Item key={variant.typeName} onClick={() => onAdd({ _type: variant.typeName })}>
          {variant.title ?? variant.name}
        </Dropdown.Item>
      ))}
    </Dropdown.Items>
  </Dropdown>
);

// The union's `admin.components.picker` slot, with the dropdown as its `Default`.
const UnionAddTrigger = (props: PickerDefaultProps) => {
  const Picker = props.field.admin?.components?.picker;
  if (!Picker) return <UnionDropdown {...props} />;

  return <Picker Default={UnionDropdown} {...props} />;
};

const UnionInput = ({
  id,
  field,
  value: propValue,
  onChange,
  disabled,
  errors,
  invalid,
  "aria-describedby": ariaDescribedBy,
  parent,
}: FieldInputProps<UnionField>) => {
  const value = propValue as (Record<string, unknown> & { _type: string }) | null | undefined;
  const currentType = value?._type ?? "unknown";
  const currentVariant = field.of.find((v) => v.typeName === currentType);

  if (!value) {
    return (
      <UnionAddTrigger field={field} onAdd={onChange} disabled={disabled} asChild>
        <Button
          id={id}
          variant="outline"
          className="w-full"
          disabled={disabled}
          aria-describedby={ariaDescribedBy}
          aria-invalid={invalid}
        >
          <PlusIcon />
          Add
        </Button>
      </UnionAddTrigger>
    );
  }

  // A stored `_type` with no matching variant — the config it was authored under was
  // renamed or removed. Never route this into `UnionAddTrigger`: picking a replacement
  // there calls `onChange`/`update(i, v)`, which overwrites this array index wholesale,
  // silently discarding the orphaned block's fields the instant a new type is picked.
  if (!currentVariant) {
    return (
      <div
        id={id}
        aria-describedby={ariaDescribedBy}
        aria-invalid={invalid}
        className="flex items-start gap-3 rounded-lg border border-negative/30 bg-negative/5 p-4 text-sm"
      >
        <WarningIcon className="mt-0.5 shrink-0 text-negative" aria-hidden />
        <div className="flex-1 text-foreground-secondary">
          <p className="font-medium text-foreground">Unknown block type "{currentType}"</p>
          <p className="mt-1">
            Its configuration was renamed or removed. The stored content is preserved but can't be
            shown or edited here
            {parent === "array"
              ? " — remove it from this item's menu above to clear it"
              : " — remove it below to clear it"}
            .
          </p>
        </div>
        {parent !== "array" && (
          <IconButton variant="ghost" aria-label="Remove item" onClick={() => onChange(undefined)}>
            <TrashIcon />
          </IconButton>
        )}
      </div>
    );
  }

  return (
    <div className={cn(parent !== "array" && "flex border border-border rounded-lg shadow-xs")}>
      <div className={cn(parent !== "array" && "flex-1 border-r border-border p-4")}>
        <FieldsRenderer
          fields={currentVariant.fields}
          value={value}
          onChange={(next) => onChange({ ...next, _type: currentType })}
          errors={errors}
          disabled={disabled}
        />
      </div>
      {parent !== "array" && (
        <div className="p-3 flex items-center">
          <IconButton variant="ghost" aria-label="Remove item" onClick={() => onChange(undefined)}>
            <TrashIcon />
          </IconButton>
        </div>
      )}
    </div>
  );
};

export { UnionAddTrigger, UnionInput };
