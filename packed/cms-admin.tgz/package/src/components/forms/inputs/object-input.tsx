import type { ObjectField } from "@cms/config";
import { Button, cn } from "@cms/ui";
import { PlusIcon } from "@phosphor-icons/react";
import { FieldsRenderer } from "../fields-renderer";
import type { TypedFieldInputProps } from "./types";

const ObjectInput = ({
  id,
  field,
  value,
  onChange,
  disabled,
  errors,
  "aria-describedby": ariaDescribedBy,
  invalid,
  parent,
}: TypedFieldInputProps<ObjectField>) => {
  const data = (value ?? {}) as Record<string, unknown>;

  if (!value) {
    return (
      <Button
        onClick={() => onChange({})}
        id={id}
        variant="outline"
        disabled={disabled}
        aria-describedby={ariaDescribedBy}
      >
        <PlusIcon />
        Add
      </Button>
    );
  }

  return (
    <div
      id={id}
      aria-describedby={ariaDescribedBy}
      className={cn(
        parent !== "array" && "border-l px-4 py-2 mt-1 border-border",
        invalid && "border-negative",
      )}
    >
      <FieldsRenderer
        fields={field.fields}
        value={data}
        onChange={(next) => onChange(next)}
        errors={errors}
        disabled={disabled}
      />
    </div>
  );
};

export { ObjectInput };
