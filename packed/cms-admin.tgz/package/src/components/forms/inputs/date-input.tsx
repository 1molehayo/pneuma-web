import type { DateField } from "@cms/config";
import { DatePicker, IconButton, Input } from "@cms/ui";
import { XIcon } from "@phosphor-icons/react";
import { formatDate } from "@/lib/utils/dates";
import type { TypedFieldInputProps } from "./types";

/** A day from the calendar plus a time, stored as one ISO date-time in the viewer's timezone. */
const DateInput = ({
  id,
  field,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<DateField>) => {
  const date = value ? new Date(value) : null;

  // A new day keeps the time already set; the first pick starts at midnight.
  const setDay = (day: Date) => {
    const next = new Date(day);
    next.setHours(date?.getHours() ?? 0, date?.getMinutes() ?? 0, 0, 0);
    onChange(next.toISOString());
  };

  const setTime = (time: string) => {
    if (!date || !time) return;
    const [hours = 0, minutes = 0] = time.split(":").map(Number);
    const next = new Date(date);
    next.setHours(hours, minutes, 0, 0);
    onChange(next.toISOString());
  };

  return (
    <div className="flex items-center gap-2">
      <DatePicker>
        <DatePicker.Trigger
          id={id}
          className="grow"
          placeholder="Pick a date"
          invalid={!!invalid}
          disabled={disabled}
          aria-describedby={ariaDescribedBy}
        >
          {value ? formatDate(value) : undefined}
        </DatePicker.Trigger>
        <DatePicker.Panel>
          <DatePicker.Calendar value={date} onDateChange={setDay} />
        </DatePicker.Panel>
      </DatePicker>
      <Input
        type="time"
        aria-label={`${field.title ?? field.name} time`}
        className="w-auto"
        value={date ? toTimeValue(date) : ""}
        onChange={(event) => setTime(event.target.value)}
        invalid={!!invalid}
        disabled={disabled || !date}
      />
      {date && !disabled && (
        <IconButton
          variant="ghost"
          size="sm"
          aria-label={`Clear ${field.title ?? field.name}`}
          onClick={() => onChange(undefined)}
        >
          <XIcon />
        </IconButton>
      )}
    </div>
  );
};

/** `HH:mm` in local time, the format `<input type="time">` reads. */
const toTimeValue = (date: Date) =>
  `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;

export { DateInput };
