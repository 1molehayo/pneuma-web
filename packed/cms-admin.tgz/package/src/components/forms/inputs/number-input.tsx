import type { NumberField } from "@cms/config";
import { Input } from "@cms/ui";
import type { TypedFieldInputProps } from "./types";

const NumberInput = ({
  id,
  field,
  value,
  onChange,
  invalid,
  disabled,
  "aria-describedby": ariaDescribedBy,
}: TypedFieldInputProps<NumberField>) => {
  return (
    <Input
      id={id}
      type="number"
      value={value ?? ""}
      onChange={(e) => {
        const raw = e.target.value;
        onChange(raw === "" ? undefined : Number(raw));
      }}
      invalid={!!invalid}
      disabled={disabled}
      placeholder={field.placeholder ?? field.title ?? field.name}
      aria-describedby={ariaDescribedBy}
    />
  );
};

export { NumberInput };
