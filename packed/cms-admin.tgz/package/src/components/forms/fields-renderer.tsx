import type { AnyField, LayoutDirective } from "@cms/config";
import { isLayoutDirective } from "@cms/config";
import { useQuery } from "@tanstack/react-query";
import { type ReactNode, useMemo, useRef } from "react";
import { getMeQueryOptions } from "@/lib/queries/me";
import { getNestedErrors } from "@/lib/utils/errors";
import { DirectiveField } from "./directive-field";
import { InputField } from "./input-field";

type FieldsRendererProps = {
  fields: ReadonlyArray<AnyField | LayoutDirective>;
  value: Record<string, unknown>;
  onChange: (value: Record<string, unknown>) => void;
  errors?: Record<string, string>;
  disabled?: boolean;
  renderItem?: (key: string, element: ReactNode) => ReactNode;
  excludedFields?: Set<string>;
  readOnlyFields?: Set<string>;
};

const FieldsRenderer = ({
  fields,
  value,
  onChange,
  errors,
  disabled,
  renderItem,
  excludedFields,
  readOnlyFields,
}: FieldsRendererProps) => {
  const data = value ?? {};
  const { data: user } = useQuery(getMeQueryOptions());

  // Refs so cached onChange handlers always read fresh values
  const dataRef = useRef(data);
  dataRef.current = data;
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  // Stable per-field onChange handlers — created once per field name, reused across renders
  const handlersRef = useRef(new Map<string, (v: unknown) => void>());
  const getFieldOnChange = (name: string) => {
    let handler = handlersRef.current.get(name);
    if (!handler) {
      handler = (v: unknown) => {
        onChangeRef.current({ ...dataRef.current, [name]: v });
      };
      handlersRef.current.set(name, handler);
    }
    return handler;
  };

  // Stable nested error objects — only recomputed when errors change
  const nestedErrorsMap = useMemo(() => {
    if (!errors || Object.keys(errors).length === 0) return {};

    const map: Record<string, Record<string, string> | undefined> = {};
    for (const item of fields) {
      if (!isLayoutDirective(item)) {
        map[item.name] = getNestedErrors(errors, item.name);
      }
    }
    return map;
  }, [errors, fields]);

  return fields.map((item, i) => {
    if (isLayoutDirective(item)) {
      const key = `directive-${i}`;
      const el = (
        <DirectiveField
          key={key}
          directive={item}
          value={data}
          onChange={onChange}
          errors={errors}
          disabled={disabled}
          excludedFields={excludedFields}
          readOnlyFields={readOnlyFields}
        />
      );
      return renderItem ? renderItem(key, el) : el;
    }

    if (excludedFields?.has(item.name)) return null;

    if (user && item.admin?.visible?.({ value: data[item.name], data, user }) === false)
      return null;

    const isReadOnly =
      readOnlyFields?.has(item.name) ||
      (user ? (item.admin?.readOnly?.({ value: data[item.name], data, user }) ?? false) : false);

    const el = (
      <InputField
        key={item.name}
        field={item}
        value={data[item.name]}
        onChange={getFieldOnChange(item.name)}
        error={errors?.[item.name]}
        errors={nestedErrorsMap[item.name]}
        disabled={disabled || isReadOnly}
      />
    );
    return renderItem ? renderItem(item.name, el) : el;
  });
};

export { FieldsRenderer };
