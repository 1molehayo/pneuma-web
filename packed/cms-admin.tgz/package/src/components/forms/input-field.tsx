import type {
  AnyField,
  ArrayField,
  DescriptionSlotProps,
  ErrorSlotProps,
  InputSlotProps,
  LabelSlotProps,
  ObjectField,
  RootSlotProps,
} from "@cms/config";
import { Badge, Field, Label as UILabel } from "@cms/ui";
import { TranslateIcon } from "@phosphor-icons/react";
import { memo, use, useId } from "react";
import { DocumentFormContext } from "./document-form-context";
import { ArrayCollapseToggle, ArrayStateProvider } from "./inputs/array-state";
import { FieldInput } from "./inputs/field-input";
import { ObjectClearToggle, ObjectStateProvider } from "./inputs/object-state";

const RootDefault = ({
  field,
  label,
  description,
  input,
  error,
}: Omit<RootSlotProps, "Default">) => (
  <Field data-field-type={field.type}>
    {label}
    {description}
    {input}
    {error}
  </Field>
);

const BooleanRootDefault = ({
  field,
  label,
  description,
  input,
  error,
}: Omit<RootSlotProps, "Default">) => (
  <Field data-field-type={field.type}>
    <div className="flex items-center gap-2.5">
      {input}
      {label}
    </div>
    {description}
    {error}
  </Field>
);

const ArrayRootDefault = ({
  field,
  label,
  description,
  input,
  error,
}: Omit<RootSlotProps, "Default">) => (
  <Field data-field-type={field.type}>
    <div className="flex items-center justify-between gap-2">
      {label}
      <ArrayCollapseToggle />
    </div>
    {description}
    {input}
    {error}
  </Field>
);

const ObjectRootDefault = ({
  field,
  label,
  description,
  input,
  error,
}: Omit<RootSlotProps, "Default">) => (
  <Field data-field-type={field.type}>
    <div className="flex items-center justify-between gap-2">
      <div className="flex flex-col gap-0.5">
        {label}
        {description}
      </div>
      <ObjectClearToggle />
    </div>
    {input}
    {error}
  </Field>
);

/** The asterisk. A function `required` reads the whole form, so it updates as the editor types. */
const RequiredMark = ({ field }: { field: AnyField }) => {
  const documentForm = field.requiredWhen ? use(DocumentFormContext) : null;
  const isRequired =
    field.required || (documentForm && field.requiredWhen?.({ data: documentForm.formData }));
  if (!isRequired) return null;
  return <span className="text-negative"> *</span>;
};

const LabelDefault = ({ htmlFor, field }: Omit<LabelSlotProps, "Default">) => {
  const label = (
    <UILabel htmlFor={htmlFor}>
      {field.title ?? field.name}
      <RequiredMark field={field} />
    </UILabel>
  );
  if (!field.shared) return label;

  return (
    <div className="flex items-center gap-2">
      {label}
      <Badge size="xs" title="Publishing copies this value to every other language">
        <Badge.Icon>
          <TranslateIcon />
        </Badge.Icon>
        Shared across languages
      </Badge>
    </div>
  );
};

const DescriptionDefault = ({ field }: Omit<DescriptionSlotProps, "Default">) => {
  if (!field?.description) return null;

  return <Field.Description>{field.description}</Field.Description>;
};

const InputDefault = (props: Omit<InputSlotProps, "Default">) => <FieldInput {...props} />;

const ErrorDefault = ({ id, error }: Omit<ErrorSlotProps, "Default">) => (
  <Field.Error id={id}>{error}</Field.Error>
);

type InputFieldProps = {
  field: AnyField;
  value: unknown;
  onChange: (value: unknown) => void;
  error?: string;
  errors?: Record<string, string>;
  disabled?: boolean;
};

const InputField = ({ field, error, errors, value, onChange, disabled }: InputFieldProps) => {
  const id = useId();
  const errorId = error ? `${id}-error` : undefined;

  if (field.auto) return null;

  const components = field.admin?.components;
  const CustomRoot = components?.root;
  const CustomLabel = components?.label;
  const CustomDescription = components?.description;
  const CustomInput = components?.input;
  const CustomError = components?.error;

  const inputProps = {
    field,
    value,
    onChange,
    errors,
    disabled,
    id,
    invalid: Boolean(error),
    "aria-describedby": errorId,
  };

  const DefaultRoot =
    field.type === "boolean"
      ? BooleanRootDefault
      : field.type === "array"
        ? ArrayRootDefault
        : field.type === "object"
          ? ObjectRootDefault
          : RootDefault;
  const RootComponent = CustomRoot || DefaultRoot;

  const root = (
    <RootComponent
      Default={DefaultRoot}
      field={field}
      label={
        CustomLabel ? (
          <CustomLabel Default={LabelDefault} field={field} htmlFor={id} />
        ) : (
          <LabelDefault field={field} htmlFor={id} />
        )
      }
      description={
        CustomDescription ? (
          <CustomDescription Default={DescriptionDefault} field={field} />
        ) : (
          <DescriptionDefault field={field} />
        )
      }
      input={
        CustomInput ? (
          <CustomInput Default={InputDefault} {...inputProps} />
        ) : (
          <InputDefault {...inputProps} />
        )
      }
      error={
        error &&
        (CustomError ? (
          <CustomError Default={ErrorDefault} id={errorId} error={error} field={field} />
        ) : (
          <ErrorDefault id={errorId} error={error} field={field} />
        ))
      }
    />
  );

  if (field.type === "array") {
    return (
      <ArrayStateProvider
        field={field as ArrayField}
        value={value}
        onChange={onChange}
        disabled={disabled}
      >
        {root}
      </ArrayStateProvider>
    );
  }

  if (field.type === "object") {
    return (
      <ObjectStateProvider
        field={field as ObjectField}
        value={value}
        onChange={onChange}
        disabled={disabled}
      >
        {root}
      </ObjectStateProvider>
    );
  }

  return root;
};

const MemoizedInputField = memo(InputField);

export { MemoizedInputField as InputField };
