import { IconButton, Tooltip, useTheme } from "@cms/ui";
import { json } from "@codemirror/lang-json";
import { bracketMatching, codeFolding, foldGutter, foldKeymap } from "@codemirror/language";
import { Compartment, EditorState } from "@codemirror/state";
import { drawSelection, EditorView, keymap } from "@codemirror/view";
import { githubDark } from "@fsegurai/codemirror-theme-github-dark";
import { githubLight } from "@fsegurai/codemirror-theme-github-light";
import { CheckIcon, ClipboardIcon } from "@phosphor-icons/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useDocumentForm } from "@/components/forms/document-form";

const panelTheme = EditorView.theme({
  "&": {
    outline: "none",
    width: "100%",
    height: "100%",
    background: "transparent !important",
  },
  "&.cm-editor.cm-focused": { outline: "none", boxShadow: "none !important" },
  ".cm-gutters": { background: "transparent !important", border: "none" },
  ".cm-scroller": {
    fontFamily: "var(--font-mono, ui-monospace, monospace)",
    fontSize: "13px",
    lineHeight: "1.6",
    overflowY: "auto",
    overflowX: "hidden",
    height: "100%",
    background: "transparent !important",
    scrollbarWidth: "thin",
    scrollbarColor: "var(--color-border) transparent",
  },
  ".cm-scroller::-webkit-scrollbar": { width: "6px", height: "6px" },
  ".cm-scroller::-webkit-scrollbar-track": { background: "transparent" },
  ".cm-scroller::-webkit-scrollbar-thumb": {
    backgroundColor: "var(--color-border)",
    borderRadius: "99px",
  },
  ".cm-content": { padding: "12px 16px", outline: "none" },
  ".cm-foldGutter": { paddingLeft: "8px" },
  ".cm-foldGutter .cm-gutterElement": {
    cursor: "pointer",
    color: "var(--color-foreground-secondary)",
    opacity: 0,
    transition: "opacity 120ms",
  },
  "&:hover .cm-foldGutter .cm-gutterElement": { opacity: 1 },
  ".cm-foldGutter .cm-gutterElement:hover": { color: "var(--color-foreground)" },
  ".cm-foldPlaceholder": {
    background: "color-mix(in oklab, var(--color-foreground) 8%, transparent)",
    border: "none",
    borderRadius: "4px",
    margin: "0 4px",
    padding: "0 6px",
    color: "var(--color-foreground-secondary)",
  },
});

function serialize(formData: Record<string, unknown>): string {
  const filtered = Object.fromEntries(
    Object.entries(formData).filter(
      ([key]) => !key.startsWith("_") && key !== "pendingDraftVersionId",
    ),
  );
  return JSON.stringify(filtered, null, 2);
}

export const JsonPreviewPanel = () => {
  const { formData } = useDocumentForm();
  const { theme } = useTheme();
  const containerRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | null>(null);
  const themeCompartmentRef = useRef<Compartment | null>(null);
  const lastValueRef = useRef<string>("");
  const copyTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [copied, setCopied] = useState(false);

  const serialized = useMemo(() => serialize(formData), [formData]);

  // biome-ignore lint/correctness/useExhaustiveDependencies: editor mounts once; theme and content synced via separate effects
  useEffect(() => {
    if (!containerRef.current) return;

    const themeCompartment = new Compartment();
    themeCompartmentRef.current = themeCompartment;
    lastValueRef.current = serialized;

    const view = new EditorView({
      state: EditorState.create({
        doc: serialized,
        extensions: [
          json(),
          drawSelection(),
          bracketMatching(),
          codeFolding(),
          foldGutter(),
          keymap.of(foldKeymap),
          EditorView.lineWrapping,
          EditorView.editable.of(false),
          EditorState.readOnly.of(true),
          themeCompartment.of(theme === "dark" ? githubDark : githubLight),
          panelTheme,
        ],
      }),
      parent: containerRef.current,
    });

    viewRef.current = view;
    return () => view.destroy();
  }, []);

  useEffect(() => {
    const view = viewRef.current;
    if (!view || serialized === lastValueRef.current) return;
    view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: serialized } });
    lastValueRef.current = serialized;
  }, [serialized]);

  useEffect(() => {
    const view = viewRef.current;
    const compartment = themeCompartmentRef.current;
    if (!view || !compartment) return;
    view.dispatch({
      effects: compartment.reconfigure(theme === "dark" ? githubDark : githubLight),
    });
  }, [theme]);

  const handleCopy = () => {
    navigator.clipboard.writeText(serialized);
    setCopied(true);
    if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    copyTimeoutRef.current = setTimeout(() => setCopied(false), 3000);
  };

  useEffect(
    () => () => {
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
    },
    [],
  );

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-border border-dashed shrink-0">
        <span className="text-xs font-medium text-foreground-secondary">JSON</span>
        <Tooltip.Group>
          <Tooltip>
            <Tooltip.Trigger asChild>
              <IconButton variant="ghost" size="xs" aria-label="Copy JSON" onClick={handleCopy}>
                {copied ? <CheckIcon /> : <ClipboardIcon />}
              </IconButton>
            </Tooltip.Trigger>
            <Tooltip.Content>{copied ? "Copied!" : "Copy"}</Tooltip.Content>
          </Tooltip>
        </Tooltip.Group>
      </div>
      <div ref={containerRef} className="grow overflow-hidden" />
    </div>
  );
};
