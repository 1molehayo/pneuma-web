import { ClientError } from "@cms/client";
import type { AnyField, FieldRuleIssue, LayoutDirective, SlugField } from "@cms/config";
import { checkFieldRules, slugify as defaultSlugify, flattenFields } from "@cms/config";
import { Button, type ButtonProps, cn, Dialog, toast } from "@cms/ui";
import { CheckIcon, FloppyDiskIcon, UploadSimpleIcon } from "@phosphor-icons/react";
import { useBlocker } from "@tanstack/react-router";
import {
  type ComponentPropsWithRef,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";
import { useFieldPermissions } from "@/lib/hooks/use-field-permissions";
import { CollapsibleGroupProvider, CollapsibleGroupToggle } from "./directives/collapsible-group";
import { DocumentFormContext, useDocumentForm } from "./document-form-context";
import { FieldsRenderer } from "./fields-renderer";

const FORM_ID = "document-form";

type DocumentFormProviderProps = {
  fields: ReadonlyArray<AnyField | LayoutDirective>;
  initialData?: Record<string, unknown>;
  onSubmit: (data: Record<string, unknown>) => Promise<unknown>;
  children: React.ReactNode;
};

/** All slug fields with a configured `source`. */
function findDerivedSlugFields(
  fields: ReadonlyArray<AnyField | LayoutDirective>,
): readonly SlugField[] {
  return flattenFields(fields).filter((f): f is SlugField => f.type === "slug" && !!f.source);
}

/** Resolves the source value (raw, pre-slugify) from current form data. Supports dot-paths. */
function readSlugSource(field: SlugField, formData: Record<string, unknown>): string | null {
  if (!field.source) return null;
  let raw: unknown;
  if (typeof field.source === "function") {
    raw = field.source(formData);
  } else {
    raw = formData;
    for (const segment of field.source.split(".")) {
      if (raw == null || typeof raw !== "object") {
        raw = undefined;
        break;
      }
      raw = (raw as Record<string, unknown>)[segment];
    }
  }
  return typeof raw === "string" && raw.length > 0 ? raw : null;
}

/**
 * Seeds each field's configured `defaultValue` into data missing that key —
 * covers both a brand-new document and an existing one saved before the
 * field existed. Never overrides a value already present (including an
 * explicit `null`).
 */
function withFieldDefaults(
  data: Record<string, unknown>,
  fields: ReadonlyArray<AnyField | LayoutDirective>,
): Record<string, unknown> {
  let next = data;
  for (const field of flattenFields(fields)) {
    if (field.defaultValue === undefined) continue;
    if (next[field.name] !== undefined) continue;
    if (next === data) next = { ...data };
    next[field.name] = field.defaultValue;
  }
  return next;
}

/** Re-derive linked slugs on every formData change. */
function applyDerivations(
  data: Record<string, unknown>,
  derivedFields: readonly SlugField[],
  linked: Record<string, boolean>,
): Record<string, unknown> {
  let next = data;
  for (const field of derivedFields) {
    if (!linked[field.name]) continue;
    const source = readSlugSource(field, data);
    if (source === null) continue;
    const transform = field.slugify ?? defaultSlugify;
    const derived = transform(source);
    if (derived !== data[field.name]) {
      if (next === data) next = { ...data };
      next[field.name] = derived;
    }
  }
  return next;
}

/** Shows field errors as a toast too: a field can sit in a closed tab or be hidden by `admin.visible`. */
function toastFieldErrors(details: readonly FieldRuleIssue[]) {
  const [onlyDetail] = details;
  if (details.length === 1 && onlyDetail) {
    toast({
      title: `${onlyDetail.field}: ${onlyDetail.message}`,
      variant: "negative",
      duration: 10000,
    });
    return;
  }
  toast({
    title: `${details.length} fields failed validation`,
    description: details.map((detail) => `"${detail.field}": "${detail.message}"`).join(", "),
    variant: "negative",
    duration: 10000,
  });
}

const DocumentFormProvider = ({
  fields,
  initialData,
  onSubmit,
  children,
}: DocumentFormProviderProps) => {
  const derivedSlugFields = useMemo(() => findDerivedSlugFields(fields), [fields]);
  const dataWithDefaults = useMemo(
    () => withFieldDefaults(initialData ?? {}, fields),
    [initialData, fields],
  );
  // Linked only when the saved slug is empty — protects existing slugs from
  // being overwritten by the next source-field edit.
  const [linkedSlugs, setLinkedSlugs] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    for (const f of derivedSlugFields) {
      const v = dataWithDefaults[f.name];
      init[f.name] = v === undefined || v === null || v === "";
    }
    return init;
  });
  // Ref mirror so same-tick derivation (unlink → change) reads the latest
  // committed linked state, not the stale closure — otherwise the user's
  // first keystroke gets re-derived away.
  const linkedSlugsRef = useRef(linkedSlugs);
  linkedSlugsRef.current = linkedSlugs;
  const [formData, setFormData] = useState<Record<string, unknown>>(() =>
    applyDerivations(dataWithDefaults, derivedSlugFields, linkedSlugs),
  );
  const [serverErrors, setServerErrors] = useState<Record<string, string>>({});
  // Rules (function `required`, `validate`) run on submit, then follow every
  // edit live so an error clears, or a newly required field flags, as you type.
  const [showRuleErrors, setShowRuleErrors] = useState(false);
  const ruleErrors = useMemo(() => {
    if (!showRuleErrors) return {};
    return Object.fromEntries(
      checkFieldRules(fields, formData).map((issue) => [issue.field, issue.message]),
    );
  }, [showRuleErrors, fields, formData]);
  const fieldErrors = useMemo(
    () =>
      Object.keys(ruleErrors).length === 0 ? serverErrors : { ...serverErrors, ...ruleErrors },
    [serverErrors, ruleErrors],
  );
  const [isPending, startTransition] = useTransition();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isDirty, setIsDirty] = useState(false);

  const formDataRef = useRef(formData);
  formDataRef.current = formData;
  const isDirtyRef = useRef(isDirty);
  isDirtyRef.current = isDirty;

  const handleFormDataChange = useCallback(
    (data: Record<string, unknown>) => {
      setFormData((prev) => {
        const withDerivations = applyDerivations(data, derivedSlugFields, linkedSlugsRef.current);
        // TODO: deeper equality than JSON round-trip.
        if (JSON.stringify(prev) === JSON.stringify(withDerivations)) {
          return prev;
        }

        setServerErrors((prevErrors) => {
          if (Object.keys(prevErrors).length === 0) return prevErrors;
          const next = { ...prevErrors };
          let changed = false;
          for (const key of Object.keys(withDerivations)) {
            if (prev[key] !== withDerivations[key] && key in next) {
              delete next[key];
              changed = true;
            }
          }
          return changed ? next : prevErrors;
        });

        setIsDirty(true);
        return withDerivations;
      });
    },
    [derivedSlugFields],
  );

  const setSlugLinked = useCallback(
    (name: string, linked: boolean) => {
      // Compute next from prev so two setSlugLinked calls in one tick see each
      // other. Sync the ref so concurrent handleFormDataChange reads the
      // updated state.
      let nextLinked: Record<string, boolean> | null = null;
      setLinkedSlugs((prev) => {
        if (prev[name] === linked) return prev;
        const next = { ...prev, [name]: linked };
        nextLinked = next;
        linkedSlugsRef.current = next;
        return next;
      });
      if (linked && nextLinked) {
        setFormData((prev) => applyDerivations(prev, derivedSlugFields, nextLinked ?? {}));
      }
    },
    [derivedSlugFields],
  );

  // Reset on initialData change (save + refetch), but only when not dirty.
  const initialDataRef = useRef(initialData);
  useEffect(() => {
    if (initialData === initialDataRef.current) return;
    initialDataRef.current = initialData;
    if (isDirtyRef.current) return;
    setFormData(initialData ?? {});
    setServerErrors({});
    setShowRuleErrors(false);
  }, [initialData]);

  const fieldsRef = useRef(fields);
  fieldsRef.current = fields;

  const handleSubmit = useCallback(
    (e: React.SubmitEvent<HTMLFormElement>) => {
      e.preventDefault();

      setIsSubmitted(false);

      startTransition(async () => {
        setServerErrors({});

        const currentFormData = formDataRef.current;
        const ruleIssues = checkFieldRules(fieldsRef.current, currentFormData);
        if (ruleIssues.length > 0) {
          setShowRuleErrors(true);
          toastFieldErrors(ruleIssues);
          return;
        }

        try {
          await onSubmit(currentFormData);
          toast({ title: "Document saved", variant: "positive" });
          setIsSubmitted(true);
          setIsDirty(false);
          setShowRuleErrors(false);
        } catch (err) {
          if (err instanceof ClientError && err.details?.length) {
            const errors: Record<string, string> = {};
            for (const detail of err.details) {
              errors[detail.field] = detail.message;
            }
            setServerErrors(errors);
            toastFieldErrors(err.details);
          } else {
            toast({
              title: err instanceof ClientError ? err.message : "Failed to save",
              variant: "negative",
            });
          }
        }
      });
    },
    [onSubmit],
  );

  const context = useMemo(
    () => ({
      fields,
      formData,
      setFormData: handleFormDataChange,
      fieldErrors,
      handleSubmit,
      isPending,
      isSubmitted,
      isDirty,
      linkedSlugs,
      setSlugLinked,
    }),
    [
      fields,
      formData,
      handleFormDataChange,
      fieldErrors,
      isSubmitted,
      isPending,
      handleSubmit,
      isDirty,
      linkedSlugs,
      setSlugLinked,
    ],
  );

  return <DocumentFormContext value={context}>{children}</DocumentFormContext>;
};

type DocumentFormFieldsProps = Omit<ComponentPropsWithRef<"form">, "id" | "children"> & {
  entityName: string;
  op: "create" | "update";
};

const DocumentFormFields = ({
  className,
  onSubmit,
  entityName,
  op,
  ...props
}: DocumentFormFieldsProps) => {
  const { fields, formData, setFormData, fieldErrors, isPending, handleSubmit } = useDocumentForm();
  const { hiddenFields, readOnlyFields } = useFieldPermissions(entityName, op);

  return (
    <form
      id={FORM_ID}
      inert={isPending}
      className={cn("flex flex-col gap-0 my-8", className)}
      onSubmit={(e) => {
        onSubmit?.(e);

        if (e.defaultPrevented) {
          return;
        }

        handleSubmit(e);
      }}
      {...props}
    >
      <CollapsibleGroupProvider>
        <CollapsibleGroupToggle />
        <FieldsRenderer
          fields={fields}
          value={formData}
          onChange={setFormData}
          errors={fieldErrors}
          excludedFields={hiddenFields}
          readOnlyFields={readOnlyFields}
        />
      </CollapsibleGroupProvider>
    </form>
  );
};

type DocumentFormSubmitProps = Omit<ButtonProps, "isLoading">;

const DocumentFormSubmit = ({ children, ...props }: DocumentFormSubmitProps) => {
  const { isSubmitted, isPending } = useDocumentForm();

  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    setIsSuccess(isSubmitted);

    setTimeout(() => {
      setIsSuccess(false);
    }, 1500);
  }, [isSubmitted]);

  return (
    <Button type="submit" form={FORM_ID} isLoading={isPending} {...props}>
      {isSuccess ? (
        <CheckIcon />
      ) : children === "Create" ? (
        <UploadSimpleIcon />
      ) : (
        <FloppyDiskIcon />
      )}
      {children}
    </Button>
  );
};

/** Exposed so consumers can render their own submit buttons with per-mutation loading state. */
export const DOCUMENT_FORM_ID = FORM_ID;

const DocumentFormUnsavedChangesBlocker = () => {
  const { isDirty } = useDocumentForm();

  const blocker = useBlocker({
    shouldBlockFn: ({ current, next }) => {
      // If the user is navigating from a new document to an existing document, don't block
      // it most likely is a redirect after creation
      if (current.pathname.endsWith("/new") && "id" in next.params) return false;

      if (current.pathname === next.pathname) return false;
      return isDirty;
    },
    withResolver: true,
    enableBeforeUnload: false,
  });

  return (
    <Dialog open={blocker.status === "blocked"} onOpenChange={(open) => !open && blocker.reset?.()}>
      <Dialog.Content>
        <Dialog.Title>Unsaved changes</Dialog.Title>
        <Dialog.Description>
          You have unsaved changes. If you leave now, your changes will be lost.
        </Dialog.Description>
        <Dialog.Actions>
          <Button variant="outline" onClick={blocker.reset}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={blocker.proceed}>
            Leave
          </Button>
        </Dialog.Actions>
      </Dialog.Content>
    </Dialog>
  );
};

export const DocumentForm = Object.assign(DocumentFormProvider, {
  Fields: DocumentFormFields,
  Submit: DocumentFormSubmit,
  UnsavedChangesBlocker: DocumentFormUnsavedChangesBlocker,
});

export { useDocumentForm };
