import CMS_CONFIG from "virtual:cms-config";
import { ClientError } from "@cms/client";
import { Button, type ButtonProps, cn, Field, Input, Label, Listbox, toast } from "@cms/ui";
import {
  type ComponentPropsWithRef,
  createContext,
  use,
  useCallback,
  useMemo,
  useState,
  useTransition,
} from "react";
import type { User } from "@/lib/schemas";

const FORM_ID = "users-form";

type UsersFormData = {
  email: string;
  name: string;
  role: string;
};

type UsersFormContextValue = {
  formData: UsersFormData;
  setFormData: React.Dispatch<React.SetStateAction<UsersFormData>>;
  handleSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
  fieldErrors: Record<string, string>;
  isPending: boolean;
  isEditing: boolean;
};

const UsersFormContext = createContext<UsersFormContextValue | null>(null);

const useUsersForm = () => {
  const context = use(UsersFormContext);

  if (!context) {
    throw new Error("useUsersForm must be used within UsersForm");
  }

  return context;
};

type UsersFormProviderProps = {
  initialData?: User;
  onSubmit: (data: UsersFormData) => Promise<unknown>;
  children: React.ReactNode;
};

const UsersFormProvider = ({ initialData, onSubmit, children }: UsersFormProviderProps) => {
  const isEditing = !!initialData;

  const [formData, setFormData] = useState<UsersFormData>({
    email: initialData?.email ?? "",
    name: initialData?.name ?? "",
    role: initialData?.role ?? "",
  });
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [isPending, startTransition] = useTransition();

  const handleSubmit = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();

      startTransition(async () => {
        setFieldErrors({});

        try {
          await onSubmit(formData);
        } catch (err) {
          if (err instanceof ClientError && err.details?.length) {
            const errors: Record<string, string> = {};
            for (const detail of err.details) {
              errors[detail.field] = detail.message;
            }
            setFieldErrors(errors);
            toast({ title: "Invalid user values", variant: "negative" });
          } else {
            toast({
              title: err instanceof ClientError ? err.message : "Failed to save",
              variant: "negative",
            });
          }
        }
      });
    },
    [formData, onSubmit],
  );

  const context = useMemo(
    () => ({
      formData,
      setFormData,
      fieldErrors,
      handleSubmit,
      isPending,
      isEditing,
    }),
    [formData, fieldErrors, isPending, isEditing, handleSubmit],
  );

  return <UsersFormContext value={context}>{children}</UsersFormContext>;
};

type UsersFormFieldsProps = Omit<ComponentPropsWithRef<"form">, "id" | "children">;

const UsersFormFields = ({ className, onSubmit, ...props }: UsersFormFieldsProps) => {
  const { formData, setFormData, fieldErrors, isPending, handleSubmit } = useUsersForm();

  return (
    <form
      id={FORM_ID}
      inert={isPending}
      className={cn("my-6", className)}
      onSubmit={(e) => {
        onSubmit?.(e);

        if (e.defaultPrevented) {
          return;
        }

        handleSubmit(e);
      }}
      {...props}
    >
      <Field>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          placeholder="user@example.com"
          value={formData.email}
          invalid={!!fieldErrors.email}
          onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
        />
        {fieldErrors.email && <Field.Error>{fieldErrors.email}</Field.Error>}
      </Field>

      <Field>
        <Label htmlFor="name">Name</Label>
        <Input
          id="name"
          placeholder="John Doe"
          value={formData.name}
          invalid={!!fieldErrors.name}
          onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
        />
        {fieldErrors.name && <Field.Error>{fieldErrors.name}</Field.Error>}
      </Field>

      <Field>
        <Label htmlFor="role">Role</Label>
        <Listbox
          value={formData.role}
          onChange={(value) => setFormData((prev) => ({ ...prev, role: value }))}
          invalid={!!fieldErrors.role}
        >
          <Listbox.Trigger id="role" placeholder="Select a role" className="capitalize">
            {formData.role || null}
          </Listbox.Trigger>
          <Listbox.Options>
            {CMS_CONFIG.roles.map((role) => (
              <Listbox.Option key={role.name} value={role.name} className="capitalize">
                {role.name}
              </Listbox.Option>
            ))}
          </Listbox.Options>
        </Listbox>
        {fieldErrors.role && <Field.Error>{fieldErrors.role}</Field.Error>}
      </Field>
    </form>
  );
};

type UsersFormSubmitProps = Omit<ButtonProps, "isLoading">;

const UsersFormSubmit = ({ children, ...props }: UsersFormSubmitProps) => {
  const { isPending } = useUsersForm();

  return (
    <Button type="submit" form={FORM_ID} isLoading={isPending} {...props}>
      {children}
    </Button>
  );
};

const UsersForm = Object.assign(UsersFormProvider, {
  Fields: UsersFormFields,
  Submit: UsersFormSubmit,
});

export type { UsersFormData };
export { UsersForm, useUsersForm };
