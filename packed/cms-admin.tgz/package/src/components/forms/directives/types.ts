import type { LayoutDirective } from "@cms/config";

type DirectiveProps<T extends LayoutDirective> = {
  directive: T;
  value: Record<string, unknown>;
  onChange: (value: Record<string, unknown>) => void;
  errors?: Record<string, string>;
  disabled?: boolean;
  excludedFields?: Set<string>;
  readOnlyFields?: Set<string>;
};

export type { DirectiveProps };
