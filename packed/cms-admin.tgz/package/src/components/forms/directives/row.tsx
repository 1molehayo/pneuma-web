import type { RowDirective } from "@cms/config";
import { FieldsRenderer } from "../fields-renderer";
import type { DirectiveProps } from "./types";

type RowDirectiveProps = DirectiveProps<RowDirective>;

const Row = ({ directive, ...props }: RowDirectiveProps) => {
  return (
    <div className="flex gap-3 my-4">
      <FieldsRenderer
        fields={directive.fields}
        renderItem={(key, el) => (
          <div key={key} className="min-w-0 flex-1">
            {el}
          </div>
        )}
        {...props}
      />
    </div>
  );
};

export { Row };
