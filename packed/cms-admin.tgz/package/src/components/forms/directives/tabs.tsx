import type { TabsDirective } from "@cms/config";
import { flattenFields } from "@cms/config";
import { Tabs as UITabs } from "@cms/ui";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { getMeQueryOptions } from "@/lib/queries/me";
import { FieldsRenderer } from "../fields-renderer";
import type { DirectiveProps } from "./types";

type TabsDirectiveProps = DirectiveProps<TabsDirective>;

const Tabs = ({ directive, errors, value, ...props }: TabsDirectiveProps) => {
  const data = value ?? {};
  const { data: user } = useQuery(getMeQueryOptions());

  // A tab's `visible` hides the whole tab (strip item + panel), unlike a field's `admin.visible`
  // which only suppresses the input — see the `TabDef.visible` doc in @cms/config. Fails open
  // (tab stays visible) while `user` hasn't loaded yet, matching FieldsRenderer's own field-level
  // check, so tabs don't flicker hidden then visible on first render.
  const visibleTabs = useMemo(
    () =>
      directive.tabs
        .map((tab, index) => ({ tab, index }))
        .filter(({ tab }) => !user || tab.visible?.({ data, user }) !== false),
    [directive.tabs, data, user],
  );

  // For each visible tab, check if any of its fields (recursively) have an error
  const tabErrorFlags = useMemo(() => {
    if (!errors || Object.keys(errors).length === 0) return null;
    return visibleTabs.map(({ tab }) => {
      return flattenFields(tab.fields).some((field) => {
        if (errors[field.name]) return true;
        const prefix = `${field.name}.`;
        return Object.keys(errors).some((key) => key.startsWith(prefix));
      });
    });
  }, [errors, visibleTabs]);

  return (
    <UITabs className="mt-2 mb-6">
      <UITabs.Items>
        {visibleTabs.map(({ tab, index }, i) => {
          const hasError = tabErrorFlags?.[i];
          return (
            <UITabs.Item key={index}>
              <span>{tab.label}</span>
              {hasError && (
                <span className="size-1.5 rounded-full bg-negative" aria-hidden="true" />
              )}
            </UITabs.Item>
          );
        })}
      </UITabs.Items>
      <UITabs.Panels className="pt-5">
        {visibleTabs.map(({ tab, index }) => (
          <UITabs.Panel key={index}>
            <FieldsRenderer fields={tab.fields} value={data} errors={errors} {...props} />
          </UITabs.Panel>
        ))}
      </UITabs.Panels>
    </UITabs>
  );
};

export { Tabs };
