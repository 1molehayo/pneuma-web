import { Button } from "@cms/ui";
import { createContext, use, useCallback, useMemo, useState } from "react";

type CollapsibleGroupContextValue = {
  openMap: Record<string, boolean>;
  register: (id: string, defaultOpen: boolean) => void;
  unregister: (id: string) => void;
  setOpen: (id: string, open: boolean) => void;
  hasCollapsibles: boolean;
  allOpen: boolean;
  expandAll: () => void;
  collapseAll: () => void;
};

// Tracks every `collapsible()` directive currently mounted within one document form so a
// single "Expand all / Collapse all" control can drive them together. Optional by design —
// a `Collapsible` rendered without this provider just falls back to its own `defaultOpen`.
const CollapsibleGroupContext = createContext<CollapsibleGroupContextValue | null>(null);

const useCollapsibleGroup = () => use(CollapsibleGroupContext);

const CollapsibleGroupProvider = ({ children }: { children: React.ReactNode }) => {
  const [openMap, setOpenMap] = useState<Record<string, boolean>>({});

  const register = useCallback((id: string, defaultOpen: boolean) => {
    setOpenMap((prev) => (id in prev ? prev : { ...prev, [id]: defaultOpen }));
  }, []);

  const unregister = useCallback((id: string) => {
    setOpenMap((prev) => {
      if (!(id in prev)) return prev;
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const setOpen = useCallback((id: string, open: boolean) => {
    setOpenMap((prev) => (prev[id] === open ? prev : { ...prev, [id]: open }));
  }, []);

  const expandAll = useCallback(() => {
    setOpenMap((prev) => Object.fromEntries(Object.keys(prev).map((id) => [id, true])));
  }, []);

  const collapseAll = useCallback(() => {
    setOpenMap((prev) => Object.fromEntries(Object.keys(prev).map((id) => [id, false])));
  }, []);

  const ids = Object.keys(openMap);
  const hasCollapsibles = ids.length > 0;
  const allOpen = hasCollapsibles && ids.every((id) => openMap[id]);

  const value = useMemo(
    () => ({
      openMap,
      register,
      unregister,
      setOpen,
      hasCollapsibles,
      allOpen,
      expandAll,
      collapseAll,
    }),
    [openMap, register, unregister, setOpen, hasCollapsibles, allOpen, expandAll, collapseAll],
  );

  return <CollapsibleGroupContext value={value}>{children}</CollapsibleGroupContext>;
};

const CollapsibleGroupToggle = () => {
  const group = useCollapsibleGroup();

  if (!group?.hasCollapsibles) return null;

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      className="self-end"
      onClick={group.allOpen ? group.collapseAll : group.expandAll}
    >
      {group.allOpen ? "Collapse all" : "Expand all"}
    </Button>
  );
};

export { CollapsibleGroupProvider, CollapsibleGroupToggle, useCollapsibleGroup };
