import type { CollapsibleDirective } from "@cms/config";
import { Disclosure } from "@cms/ui";
import { useEffect, useId } from "react";
import { FieldsRenderer } from "../fields-renderer";
import { useCollapsibleGroup } from "./collapsible-group";
import type { DirectiveProps } from "./types";

type CollapsibleDirectiveProps = DirectiveProps<CollapsibleDirective>;

const Collapsible = ({ directive, ...props }: CollapsibleDirectiveProps) => {
  const id = useId();
  const group = useCollapsibleGroup();
  const defaultOpen = directive.defaultOpen ?? false;

  // Keyed on the stable callbacks, not `group`: its value changes with every open/close, and
  // re-running this would unregister then re-register the row at `defaultOpen`, undoing the toggle
  const register = group?.register;
  const unregister = group?.unregister;
  useEffect(() => {
    if (!register || !unregister) return;
    register(id, defaultOpen);
    return () => unregister(id);
  }, [register, unregister, id, defaultOpen]);

  const open = group ? (group.openMap[id] ?? defaultOpen) : undefined;

  return (
    <Disclosure
      className="rounded-xl border border-border overflow-hidden"
      {...(group
        ? { open, onOpenChange: (next: boolean) => group.setOpen(id, next) }
        : { defaultOpen })}
    >
      <Disclosure.Trigger className="flex w-full items-center justify-between px-4 py-3 text-sm font-medium hover:bg-foreground/2 active:bg-foreground/4 cursor-pointer">
        {directive.label}
        <Disclosure.Chevron className="text-muted" />
      </Disclosure.Trigger>
      <Disclosure.Content>
        <div className="p-4 pb-6 border-t border-border">
          <FieldsRenderer fields={directive.fields} {...props} />
        </div>
      </Disclosure.Content>
    </Disclosure>
  );
};

export { Collapsible };
