import { FileInput, toast } from "@cms/ui";
import { BoxArrowUpIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo } from "react";
import { uploadAsset } from "@/lib/client";
import { invalidate } from "@/lib/queries/keys";

type AssetUploadInputProps = {
  types: ("_image" | "_video" | "_file")[];
  multiple?: boolean;
};

const AssetUploadInput = ({ types, multiple }: AssetUploadInputProps) => {
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (files: File[]) => Promise.all(files.map(uploadAsset)),
    onSuccess: () => {
      toast({
        title: "Upload successful",
        variant: "positive",
      });

      for (const type of types) {
        invalidate.afterListWrite(queryClient, { entity: type, ids: [] });
      }
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "negative",
      });
    },
  });

  const accepts = useMemo(() => {
    const accepts: string[] = [];
    if (types.includes("_image")) {
      accepts.push("image/*");
    }
    if (types.includes("_video")) {
      accepts.push("video/*");
    }
    if (types.includes("_file")) {
      accepts.push("application/pdf");
    }
    return accepts.join(",");
  }, [types]);

  return (
    <FileInput
      onChange={(files) => uploadMutation.mutate(files)}
      loading={uploadMutation.isPending}
      accept={accepts}
      multiple={multiple}
    >
      <FileInput.Dropzone>
        <BoxArrowUpIcon className="size-4" />
        Drag and drop your files here
      </FileInput.Dropzone>
    </FileInput>
  );
};

export { AssetUploadInput };
