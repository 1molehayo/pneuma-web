import { ClientError } from "@cms/client";
import { Button, EmptyState } from "@cms/ui";
import { WarningCircleIcon } from "@phosphor-icons/react";
import { type ErrorComponentProps, useRouter } from "@tanstack/react-router";
import { useEffect } from "react";
import { reportError } from "@/lib/plugins";

/**
 * Shown when a route throws while loading or rendering. Without it a crash leaves a blank page.
 * The request id, when there is one, is what support needs to find the request in the logs.
 */
export function RouteError({ error, reset }: ErrorComponentProps) {
  const router = useRouter();
  const requestId = error instanceof ClientError ? error.requestId : undefined;

  useEffect(() => {
    reportError(error, "render");
  }, [error]);

  const retry = () => {
    reset();
    void router.invalidate();
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <EmptyState className="max-w-md">
        <EmptyState.Icon>
          <WarningCircleIcon />
        </EmptyState.Icon>
        <EmptyState.Title>Something went wrong</EmptyState.Title>
        <EmptyState.Description>
          This page failed to load. Try again, and if it keeps happening, let whoever maintains the
          CMS know{requestId ? ", with this request id:" : "."}
        </EmptyState.Description>
        {requestId ? (
          <EmptyState.Description className="font-mono text-xs">{requestId}</EmptyState.Description>
        ) : null}
        <EmptyState.Actions>
          <Button onClick={retry}>Try again</Button>
        </EmptyState.Actions>
      </EmptyState>
    </div>
  );
}
