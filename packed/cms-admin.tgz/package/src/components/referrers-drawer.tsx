import { Drawer, IconButton, Skeleton } from "@cms/ui";
import { XIcon } from "@phosphor-icons/react";
import { useQuery } from "@tanstack/react-query";
import { ReferrerList } from "@/components/referrer-list";
import { getReferrersQueryOptions } from "@/lib/queries/referrers";

type ReferrersDrawerProps = {
  entityName: string;
  documentId: string;
  /** When true, the drawer is open. The parent owns the state. */
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

/** "Used in": the documents that point at this one, and the fields they point from. */
const ReferrersDrawer = ({ entityName, documentId, open, onOpenChange }: ReferrersDrawerProps) => {
  const { data, isPending, isError } = useQuery({
    ...getReferrersQueryOptions(entityName, documentId),
    enabled: open,
  });

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <Drawer.Content className="md:max-w-md">
        <Drawer.Header className="flex items-center justify-between">
          <Drawer.Title>Used in</Drawer.Title>
          <IconButton
            variant="ghost"
            size="sm"
            aria-label="Close used in"
            onClick={() => onOpenChange(false)}
          >
            <XIcon />
          </IconButton>
        </Drawer.Header>

        {isError ? (
          <p className="px-1 py-8 text-center text-sm text-negative">
            Couldn't load where this is used.
          </p>
        ) : isPending ? (
          <div className="flex flex-col gap-4 px-1">
            {Array.from({ length: 4 }).map((_, index) => (
              <Skeleton key={index} className="h-10" />
            ))}
          </div>
        ) : data.meta.total === 0 ? (
          <p className="px-1 py-8 text-center text-sm text-foreground-secondary">
            No other document points here.
          </p>
        ) : (
          <ReferrerList
            referrers={data.data}
            hidden={data.meta.hidden}
            onNavigate={() => onOpenChange(false)}
          />
        )}
      </Drawer.Content>
    </Drawer>
  );
};

export { ReferrersDrawer };
