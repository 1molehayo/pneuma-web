import { type ButtonProps, IconButton } from "@cms/ui";
import { CheckIcon, CopyIcon } from "@phosphor-icons/react";
import { useEffect, useRef, useState } from "react";

type CopyButtonProps = Omit<ButtonProps, "children"> & {
  text: string;
};

const CopyButton = ({ text, onClick, ...props }: CopyButtonProps) => {
  const [isCopied, setIsCopied] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    if (onClick) onClick(e);
    if (e.defaultPrevented) return;

    navigator.clipboard.writeText(text);
    setIsCopied(true);

    timeoutRef.current && clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => setIsCopied(false), 2000);
  };

  useEffect(() => {
    return () => {
      timeoutRef.current && clearTimeout(timeoutRef.current);
    };
  }, []);

  return (
    <IconButton aria-label="Copy" onClick={handleClick} {...props}>
      {isCopied ? <CheckIcon /> : <CopyIcon />}
    </IconButton>
  );
};

export { CopyButton };
