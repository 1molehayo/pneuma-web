import CMS_CONFIG from "virtual:cms-config";
import { Badge, Skeleton } from "@cms/ui";
import { useQueries } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { getMiniDocumentsQueryOptions } from "@/lib/queries/documents";
import type { Referrer } from "@/lib/queries/referrers";
import { resolveEntityTitle } from "@/lib/utils/config";
import { resolveDocumentMeta } from "@/lib/utils/documents";

/** Referrers listed by title; the rest are counted. Titles are fetched by id, so this bounds the URL. */
const LISTED_REFERRERS = 50;

type ReferrerListProps = {
  referrers: Referrer[];
  /** Referrers the viewer can't read: counted, never named. */
  hidden: number;
  /** Called when the editor follows a link, e.g. to close the dialog around the list. */
  onNavigate?: () => void;
};

/**
 * The documents that point at a document: each one's title, linked to its edit screen, and the
 * fields it points from. A field only a pending draft holds is marked.
 */
const ReferrerList = ({ referrers, hidden, onNavigate }: ReferrerListProps) => {
  const listed = referrers.slice(0, LISTED_REFERRERS);
  const more = referrers.length - listed.length;

  // Globals have no list route; they're named by their entity title instead.
  const idsByEntity = new Map<string, string[]>();
  for (const referrer of listed) {
    if (isGlobal(referrer.entity)) continue;
    idsByEntity.set(referrer.entity, [...(idsByEntity.get(referrer.entity) ?? []), referrer.id]);
  }
  const summaries = useQueries({
    queries: [...idsByEntity].map(([entity, ids]) =>
      getMiniDocumentsQueryOptions(entity, {
        filter: { id: { $in: ids } },
        limitOverride: ids.length,
      }),
    ),
  });
  const isPending = summaries.some((summary) => summary.isPending);
  const documents = new Map(
    summaries
      .flatMap((summary) => summary.data?.data ?? [])
      .map((miniDocument) => [miniDocument.id, miniDocument]),
  );

  return (
    <div className="flex flex-col gap-2">
      <ul className="flex flex-col">
        {listed.map((referrer) => {
          const document = documents.get(referrer.id);
          const global = isGlobal(referrer.entity);
          const title = global
            ? resolveEntityTitle(referrer.entity)
            : document
              ? resolveDocumentMeta(referrer.entity, document).title
              : null;
          const linkProps = global
            ? {
                to: "/global/$name/{-$locale}" as const,
                params: { name: referrer.entity, locale: referrer.locale ?? undefined },
              }
            : {
                to: "/entity/$name/$id" as const,
                params: { name: referrer.entity, id: referrer.id },
              };

          return (
            <li key={`${referrer.entity}:${referrer.id}`}>
              <Link
                {...linkProps}
                onClick={onNavigate}
                className="flex flex-col gap-1 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-foreground/5 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring active:bg-foreground/8"
              >
                <span className="flex items-center gap-2">
                  {title === null && isPending ? (
                    <Skeleton className="h-4 w-32" />
                  ) : (
                    <span className="truncate font-medium">{title ?? "Untitled"}</span>
                  )}
                  <span className="shrink-0 text-xs text-foreground-secondary">
                    {resolveEntityTitle(referrer.entity)}
                  </span>
                  {referrer.locale && (
                    <Badge size="xs" variant="info" className="ml-auto uppercase">
                      {referrer.locale}
                    </Badge>
                  )}
                </span>
                <span className="flex flex-wrap gap-1">
                  {referrer.fields.map((field) => (
                    <Badge
                      key={field.path}
                      size="xs"
                      variant={field.draft ? "warning" : "neutral"}
                      title={field.draft ? "Only the unpublished draft points here" : undefined}
                    >
                      {field.path}
                      {field.draft && " · draft"}
                    </Badge>
                  ))}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
      {more > 0 && <p className="px-2 text-xs text-foreground-secondary">And {more} more.</p>}
      {hidden > 0 && (
        <p className="px-2 text-xs text-foreground-secondary">
          {hidden} {hidden === 1 ? "document" : "documents"} you can't view also{" "}
          {hidden === 1 ? "points" : "point"} here.
        </p>
      )}
    </div>
  );
};

const isGlobal = (entityName: string) =>
  !!CMS_CONFIG.entities.find((entity) => entity.name === entityName)?.global;

export { ReferrerList };
