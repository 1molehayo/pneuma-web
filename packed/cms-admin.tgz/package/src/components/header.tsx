import CMS_CONFIG from "virtual:cms-config";
import { Avatar, Button, Dropdown, IconButton, ThemeToggle } from "@cms/ui";
import {
  DatabaseIcon,
  KeyIcon,
  ListBulletsIcon,
  ListIcon,
  MagnifyingGlassIcon,
  SignOutIcon,
  UsersIcon,
  XIcon,
} from "@phosphor-icons/react";
import { Link, useLocation, useRouteContext } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useCanReadAuditLog } from "@/lib/hooks/use-can-read-audit-log";

const isMac = typeof navigator !== "undefined" && /Mac|iPad|iPhone|iPod/.test(navigator.userAgent);

type HeaderProps = {
  onSearchOpen?: () => void;
};

const Header = ({ onSearchOpen }: HeaderProps) => {
  const { me } = useRouteContext({ from: "/_authenticated" });
  const canReadAuditLog = useCanReadAuditLog();

  return (
    <header className="px-2 gap-1 h-(--header-height) flex items-center border-b border-border sticky top-0 bg-background z-30 shrink-0">
      <HeaderMenuToggle />

      <Button asChild variant="ghost" className="mr-auto">
        <Link to="/">
          {CMS_CONFIG.admin?.logo ?? <DatabaseIcon strokeWidth={2} className="size-4" />}
          {CMS_CONFIG.admin?.title ?? "CMS"}
        </Link>
      </Button>

      <IconButton
        variant="ghost"
        size="sm"
        onClick={onSearchOpen}
        aria-label="Open search"
        aria-keyshortcuts={isMac ? "Meta+K" : "Control+K"}
      >
        <MagnifyingGlassIcon />
      </IconButton>

      <ThemeToggle size="sm" />
      <Dropdown>
        <Dropdown.Trigger asChild>
          <IconButton aria-label="settings" variant="ghost">
            <Avatar size="xs">
              <Avatar.Fallback>{me.email.toUpperCase()}</Avatar.Fallback>
            </Avatar>
          </IconButton>
        </Dropdown.Trigger>
        <Dropdown.Items>
          <Dropdown.Section>
            <Dropdown.Heading>Settings</Dropdown.Heading>
            <Dropdown.Item asChild>
              <Link to="/settings/api-keys">
                <KeyIcon />
                API keys
              </Link>
            </Dropdown.Item>
            <Dropdown.Item asChild>
              <Link to="/settings/users">
                <UsersIcon />
                Users
              </Link>
            </Dropdown.Item>
            {canReadAuditLog && (
              <Dropdown.Item asChild>
                <Link to="/settings/activity">
                  <ListBulletsIcon />
                  Activity
                </Link>
              </Dropdown.Item>
            )}
          </Dropdown.Section>
          <Dropdown.Section>
            <Dropdown.Item className="text-negative" asChild>
              <Link to="/logout">
                <SignOutIcon />
                Logout
              </Link>
            </Dropdown.Item>
          </Dropdown.Section>
        </Dropdown.Items>
      </Dropdown>
    </header>
  );
};

const HeaderMenuToggle = () => {
  const [isOpen, setIsOpen] = useState(false);

  const pathname = useLocation({
    select: (location) => location.pathname,
  });

  // biome-ignore lint/correctness/useExhaustiveDependencies: intentional
  useEffect(() => {
    setIsOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (isOpen) {
      document.body.setAttribute("data-menu-open", "true");
    } else {
      document.body.removeAttribute("data-menu-open");
    }
  }, [isOpen]);

  return (
    <IconButton
      aria-label="Toggle menu"
      variant="ghost"
      size="sm"
      className="md:hidden -mr-2"
      aria-expanded={isOpen}
      onClick={() => setIsOpen(!isOpen)}
    >
      {isOpen ? <XIcon /> : <ListIcon />}
    </IconButton>
  );
};

export { Header };
