import { ClientError } from "@cms/client";
import type { AnyEntity, EntityAdminBulkAction, EntityAdminBulkActionMessages } from "@cms/config";
import { Button, Dialog, Divider, Tooltip, toast, useTheme } from "@cms/ui";
import { CloudArrowUpIcon, CloudSlashIcon, TrashIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { type DeleteScope, DeleteScopeChoice } from "@/components/delete-scope-choice";
import { client } from "@/lib/client";
import { invalidate } from "@/lib/queries/keys";
import { getLocaleLabel } from "@/lib/utils/i18n";

// biome-ignore lint/suspicious/noExplicitAny: TData is erased at runtime
type AnyBulkAction = EntityAdminBulkAction<any>;

type MutableAction =
  | { type: "delete"; scope: DeleteScope }
  | { type: "publish" }
  | { type: "unpublish" }
  | {
      type: "custom";
      action: AnyBulkAction;
      data: Record<string, unknown> | ((doc: Record<string, unknown>) => Record<string, unknown>);
      messages?: EntityAdminBulkActionMessages;
      confirmModal?: NonNullable<AnyBulkAction["confirmModal"]>;
    };

type PendingAction =
  | Exclude<MutableAction, { type: "delete" }>
  | { type: "delete" }
  | {
      type: "custom-unresolved";
      action: AnyBulkAction;
      confirmModal: NonNullable<AnyBulkAction["confirmModal"]>;
    };

type MiniDocument = {
  id: string;
  _translations?: Record<string, { id: string }>;
  [key: string]: unknown;
};

type BulkActionBarProps = {
  entity: AnyEntity;
  selectedIds: Set<string>;
  selectedDocuments: MiniDocument[];
  clearSelection: () => void;
  /** Group-collapse mode: which locale the selection is in, and what else it reaches. */
  localeScope?: {
    locale: string;
    /** Every locale any selected document exists in, the active one included. */
    locales: string[];
    /** How many selected documents also exist in another locale. */
    translatedCount: number;
  };
};

export function BulkActionBar({
  entity,
  selectedIds,
  selectedDocuments,
  clearSelection,
  localeScope,
}: BulkActionBarProps) {
  const [pendingAction, setPendingAction] = useState<PendingAction | null>(null);
  const [deleteScope, setDeleteScope] = useState<DeleteScope>("locale");
  const [resolvingAction, setResolvingAction] = useState<string | null>(null);
  const cancelButtonRef = useRef<HTMLButtonElement>(null);
  const prevCountRef = useRef(0);
  const { theme } = useTheme();
  const queryClient = useQueryClient();

  const count = selectedDocuments.length;
  const configuredBulkActions = entity.admin?.bulkActions ?? [];

  // Focus Cancel when the bar first appears
  useEffect(() => {
    if (prevCountRef.current === 0 && count > 0) {
      cancelButtonRef.current?.focus();
    }
    prevCountRef.current = count;
  }, [count]);

  // biome-ignore lint/suspicious/noExplicitAny: TData is erased at runtime
  const resolveBulkAction = async (action: EntityAdminBulkAction<any>) => {
    let data:
      | Record<string, unknown>
      | ((doc: Record<string, unknown>) => Record<string, unknown>)
      | undefined;

    const fetchDocs = async (fields: readonly string[]) => {
      const { data: docs } = await client.list(entity.name, {
        fields: ["id", ...fields],
        filter: { id: { $in: [...selectedIds] } },
        limit: selectedIds.size,
      });
      return docs as Record<string, unknown>[];
    };

    const messages = await action.callback({
      set: (d) => {
        data = d as typeof data;
      },
      map: async (fields, fn) => {
        const docs = await fetchDocs(fields);
        const byId = Object.fromEntries(docs.map((d) => [d.id, d]));
        // biome-ignore lint/suspicious/noExplicitAny: TData is erased at runtime
        data = (doc) => fn({ ...doc, ...byId[doc.id as string] } as any) as Record<string, unknown>;
      },
    });

    if (data === undefined) {
      toast({ title: `${action.label}: callback must call set() or map()`, variant: "negative" });
      return { data: undefined, messages: undefined };
    }

    return { data, messages: messages ?? undefined };
  };

  // biome-ignore lint/suspicious/noExplicitAny: TData is erased at runtime
  const fireBulkAction = async (action: EntityAdminBulkAction<any>) => {
    try {
      const { data, messages } = await resolveBulkAction(action);
      if (data) bulkMutation.mutate({ type: "custom", action, data, messages });
    } catch {
      toast({ title: `Failed to prepare ${action.label.toLowerCase()}`, variant: "negative" });
    }
  };

  // Flatten the selection into a single id list. The list passes one document
  // per selected row: in group-collapse mode that's the active-locale row
  // (siblings are untouched — bulk acts on the locale you're viewing); in the
  // bare list each row carries its `_translations`, kept here for the
  // single-locale case where the map is empty.
  const flattenIds = () =>
    selectedDocuments.flatMap((doc) => [
      doc.id,
      ...Object.values(doc._translations || {}).map((t) => t.id),
    ]);

  const bulkMutation = useMutation({
    mutationFn: async (action: MutableAction): Promise<{ succeeded: number; failed: number }> => {
      if (action.type === "delete") {
        // One atomic bulk-delete request. `allLocales` has the engine widen the
        // selection to every translation in the same transaction, and handle
        // slug/polymorphic cleanup there too.
        const res = await client.request<{
          data: { deleted: number; ids: string[]; skipped: string[] };
        }>(`/${entity.name}/_bulk-delete`, {
          method: "POST",
          body: { ids: flattenIds(), ...(action.scope === "all" && { allLocales: true }) },
        });
        return { succeeded: res.data.deleted, failed: res.data.skipped.length };
      }

      if (action.type === "publish") {
        // Publish acts on exactly the selected ids — in group-collapse mode the
        // list resolves each group to its active-locale row, so publish hits the
        // locale being viewed (sibling locales keep their own publish state).
        const res = await client.request<{
          data: { published: number; ids: string[]; skipped: string[] };
        }>(`/${entity.name}/_bulk-publish`, {
          method: "POST",
          body: { ids: [...selectedIds] },
        });
        return { succeeded: res.data.published, failed: res.data.skipped.length };
      }

      if (action.type === "unpublish") {
        const res = await client.request<{
          data: { unpublished: number; ids: string[]; skipped: string[] };
        }>(`/${entity.name}/_bulk-unpublish`, {
          method: "POST",
          body: { ids: [...selectedIds] },
        });
        return { succeeded: res.data.unpublished, failed: res.data.skipped.length };
      }

      if (typeof action.data === "function") {
        // Per-row dynamic data (e.g. each doc computes its own patch). Can't
        // collapse into one SQL UPDATE — fall back to a per-doc PUT loop.
        // Still a step up from the previous all-rows-as-individual-requests
        // pattern because we batch per doc (so translation siblings share a
        // single Promise.all).
        const resolveData = action.data;
        const results = await Promise.allSettled(
          selectedDocuments.map((doc) => {
            const ids = [doc.id, ...Object.values(doc._translations || {}).map((t) => t.id)];
            const body = resolveData(doc as Record<string, unknown>);
            return Promise.all(
              ids.map((id) => client.request(`/${entity.name}/${id}`, { method: "PUT", body })),
            );
          }),
        );
        return {
          succeeded: results.filter((r) => r.status === "fulfilled").length,
          failed: results.filter((r) => r.status === "rejected").length,
        };
      }

      // Static data — bulk-update path, single SQL UPDATE for the whole batch.
      const res = await client.request<{
        data: { updated: number; ids: string[]; skipped: string[] };
      }>(`/${entity.name}/_bulk-update`, {
        method: "POST",
        body: { ids: flattenIds(), data: action.data },
      });
      return { succeeded: res.data.updated, failed: res.data.skipped.length };
    },
    // The written ids, taken when the request starts: the selection can change before it ends.
    onMutate: () => ({ ids: flattenIds() }),
    onError: (err) => {
      // A broken unique rule repeats its message on each of its fields: show it once.
      const detailMessages = new Set(
        err instanceof ClientError ? err.details?.map((detail) => detail.message) : [],
      );
      toast({
        title: "Action failed",
        description:
          detailMessages.size > 0
            ? [...detailMessages].join(" ")
            : err instanceof ClientError
              ? err.message
              : undefined,
        variant: "negative",
      });
    },
    onSuccess: ({ succeeded, failed }, action, { ids }) => {
      invalidate.afterListWrite(queryClient, { entity: entity.name, ids });
      setPendingAction(null);
      clearSelection();

      const noun = succeeded === 1 ? "document" : "documents";
      const totalNoun = succeeded + failed === 1 ? "document" : "documents";

      if (action.type === "delete" && localeScope && localeScope.translatedCount > 0) {
        const documents = `${count} ${count === 1 ? "document" : "documents"}`;
        const rowNoun = succeeded + failed === 1 ? "translation" : "translations";
        if (action.scope === "locale" && failed === 0) {
          toast({
            title: `${documents} deleted from ${getLocaleLabel(localeScope.locale)}`,
            variant: "positive",
          });
        } else if (failed === 0) {
          toast({ title: `${documents} deleted from all locales`, variant: "positive" });
        } else if (succeeded === 0) {
          toast({ title: `Failed to delete ${documents}`, variant: "negative" });
        } else {
          toast({
            title: `${succeeded} of ${succeeded + failed} ${rowNoun} deleted, ${failed} skipped`,
            variant: "negative",
          });
        }
      } else if (action.type === "delete") {
        if (failed === 0) {
          toast({ title: `${succeeded} ${noun} deleted`, variant: "positive" });
        } else if (succeeded === 0) {
          toast({ title: `Failed to delete ${totalNoun}`, variant: "negative" });
        } else {
          toast({ title: `${succeeded} ${noun} deleted, ${failed} failed`, variant: "negative" });
        }
      } else if (action.type === "publish") {
        if (failed === 0) {
          toast({ title: `${succeeded} ${noun} published`, variant: "positive" });
        } else if (succeeded === 0) {
          toast({ title: `Failed to publish ${totalNoun}`, variant: "negative" });
        } else {
          toast({ title: `${succeeded} ${noun} published, ${failed} failed`, variant: "negative" });
        }
      } else if (action.type === "unpublish") {
        if (failed === 0) {
          toast({ title: `${succeeded} ${noun} unpublished`, variant: "positive" });
        } else if (succeeded === 0) {
          toast({ title: `Failed to unpublish ${totalNoun}`, variant: "negative" });
        } else {
          toast({
            title: `${succeeded} ${noun} unpublished, ${failed} failed`,
            variant: "negative",
          });
        }
      } else {
        const { label } = action.action;
        const { messages } = action;
        if (failed === 0) {
          toast({
            title: messages?.success
              ? messages.success(succeeded)
              : `${label}: ${succeeded} ${noun}`,
            variant: "positive",
          });
        } else if (succeeded === 0) {
          toast({
            title: messages?.error ?? `${label}: failed`,
            variant: "negative",
          });
        } else {
          toast({
            title: messages?.partialSuccess
              ? messages.partialSuccess(succeeded, failed)
              : `${label}: ${succeeded} succeeded, ${failed} failed`,
            variant: "negative",
          });
        }
      }
    },
  });

  return (
    <>
      <output aria-live="polite" aria-atomic="true" className="sr-only">
        {count > 0 ? `${count} ${count === 1 ? "item" : "items"} selected` : ""}
      </output>

      <AnimatePresence>
        {count > 0 && (
          <motion.div
            className="fixed bottom-6 inset-x-0 flex justify-center z-50 pointer-events-none select-none"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0, transition: { duration: 0.25, ease: [0.16, 1, 0.3, 1] } }}
            exit={{ opacity: 0, y: 12, transition: { duration: 0.15, ease: [0.4, 0, 1, 0.6] } }}
          >
            <motion.div
              layout
              data-theme={theme === "dark" ? "light" : "dark"}
              className="bg-background rounded-2xl shadow-2xl px-1.5 py-1.5 flex items-center gap-0.5 pointer-events-auto overflow-hidden"
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            >
              <span className="text-sm px-3 text-foreground/50 tabular-nums whitespace-nowrap">
                <motion.span
                  key={count}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                >
                  {count}
                </motion.span>{" "}
                {count === 1 ? "item" : "items"} selected
              </span>

              <Button ref={cancelButtonRef} variant="ghost" size="sm" onClick={clearSelection}>
                Cancel
              </Button>
              {configuredBulkActions.length > 0 && (
                <>
                  <Divider
                    orientation="vertical"
                    decorative
                    className="h-5 mx-0.5 bg-foreground/15"
                  />
                  <Tooltip.Group>
                    {configuredBulkActions.map((action) => {
                      const Icon = action.icon;
                      const iconOnly = !!Icon && !!action.iconOnly;
                      const isResolving = resolvingAction === action.label;

                      const button = (
                        <Button
                          key={action.label}
                          variant="ghost"
                          size="sm"
                          aria-label={iconOnly ? action.label : undefined}
                          isLoading={isResolving}
                          onClick={() => {
                            if (action.confirmModal) {
                              setPendingAction({
                                type: "custom-unresolved",
                                action,
                                confirmModal: action.confirmModal,
                              });
                            } else {
                              fireBulkAction(action);
                            }
                          }}
                        >
                          {Icon && <Icon />}
                          {!iconOnly && action.label}
                        </Button>
                      );

                      if (!iconOnly) return button;

                      return (
                        <Tooltip key={action.label} offset={12}>
                          <Tooltip.Trigger asChild>{button}</Tooltip.Trigger>
                          <Tooltip.Content className="bg-background text-foreground [&_svg]:fill-background">
                            {action.label}
                          </Tooltip.Content>
                        </Tooltip>
                      );
                    })}
                  </Tooltip.Group>
                </>
              )}
              {entity.versions?.drafts && (
                <>
                  <Divider
                    orientation="vertical"
                    decorative
                    className="h-5 mx-0.5 bg-foreground/15"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPendingAction({ type: "publish" })}
                  >
                    <CloudArrowUpIcon />
                    Publish
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPendingAction({ type: "unpublish" })}
                  >
                    <CloudSlashIcon />
                    Unpublish
                  </Button>
                </>
              )}
              <Divider orientation="vertical" decorative className="h-5 mx-0.5 bg-foreground/15" />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setDeleteScope("locale");
                  setPendingAction({ type: "delete" });
                }}
                className="text-negative"
              >
                <TrashIcon />
                Delete
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Dialog
        open={!!pendingAction}
        onOpenChange={(open) => {
          if (!open) setPendingAction(null);
        }}
      >
        <Dialog.Content>
          {pendingAction?.type === "delete" ? (
            <>
              <Dialog.Title>
                Delete {count} {count === 1 ? "document" : "documents"}?
              </Dialog.Title>
              {!localeScope ? (
                <Dialog.Description>This action cannot be undone.</Dialog.Description>
              ) : localeScope.translatedCount === 0 ? (
                <Dialog.Description>
                  This removes {count === 1 ? "it" : "them"} from all locales and cannot be undone.
                </Dialog.Description>
              ) : (
                <>
                  <Dialog.Description>
                    {localeScope.translatedCount}{" "}
                    {localeScope.translatedCount === 1
                      ? "document also exists"
                      : "documents also exist"}{" "}
                    in other locales. This action cannot be undone.
                  </Dialog.Description>
                  <DeleteScopeChoice
                    value={deleteScope}
                    onValueChange={setDeleteScope}
                    locale={localeScope.locale}
                    locales={localeScope.locales}
                    disabled={bulkMutation.isPending}
                  />
                </>
              )}
              <Dialog.Actions>
                <Dialog.Close asChild>
                  <Button variant="outline">Cancel</Button>
                </Dialog.Close>
                <Button
                  autoFocus
                  variant="destructive"
                  isLoading={bulkMutation.isPending}
                  onClick={() =>
                    bulkMutation.mutate({
                      type: "delete",
                      scope: localeScope?.translatedCount ? deleteScope : "locale",
                    })
                  }
                >
                  Delete {count === 1 ? "document" : `${count} documents`}
                </Button>
              </Dialog.Actions>
            </>
          ) : pendingAction?.type === "publish" ? (
            <>
              <Dialog.Title>
                Publish {count} {count === 1 ? "document" : "documents"}?
              </Dialog.Title>
              <Dialog.Description>
                {count === 1 ? "It" : "They"} will become publicly visible.
              </Dialog.Description>
              <Dialog.Actions>
                <Dialog.Close asChild>
                  <Button variant="outline">Cancel</Button>
                </Dialog.Close>
                <Button
                  autoFocus
                  isLoading={bulkMutation.isPending}
                  onClick={() => bulkMutation.mutate({ type: "publish" })}
                >
                  Publish {count === 1 ? "document" : `${count} documents`}
                </Button>
              </Dialog.Actions>
            </>
          ) : pendingAction?.type === "unpublish" ? (
            <>
              <Dialog.Title>
                Unpublish {count} {count === 1 ? "document" : "documents"}?
              </Dialog.Title>
              <Dialog.Description>
                {count === 1 ? "It" : "They"} will be hidden from the public.
              </Dialog.Description>
              <Dialog.Actions>
                <Dialog.Close asChild>
                  <Button variant="outline">Cancel</Button>
                </Dialog.Close>
                <Button
                  autoFocus
                  isLoading={bulkMutation.isPending}
                  onClick={() => bulkMutation.mutate({ type: "unpublish" })}
                >
                  Unpublish {count === 1 ? "document" : `${count} documents`}
                </Button>
              </Dialog.Actions>
            </>
          ) : pendingAction?.type === "custom-unresolved" ? (
            <>
              <Dialog.Title>{pendingAction.confirmModal.title}</Dialog.Title>
              <Dialog.Description>{pendingAction.confirmModal.description}</Dialog.Description>
              <Dialog.Actions>
                <Dialog.Close asChild>
                  <Button variant="outline">
                    {pendingAction.confirmModal.actions?.cancel ?? "Cancel"}
                  </Button>
                </Dialog.Close>
                <Button
                  autoFocus
                  isLoading={
                    bulkMutation.isPending || resolvingAction === pendingAction.action.label
                  }
                  onClick={async () => {
                    const { action } = pendingAction;
                    setResolvingAction(action.label);
                    try {
                      const { data, messages } = await resolveBulkAction(action);
                      if (data) bulkMutation.mutate({ type: "custom", action, data, messages });
                    } catch {
                      toast({
                        title: `Failed to prepare ${action.label.toLowerCase()}`,
                        variant: "negative",
                      });
                    } finally {
                      setResolvingAction(null);
                    }
                  }}
                >
                  {pendingAction.confirmModal.actions?.confirm ?? "Confirm"}
                </Button>
              </Dialog.Actions>
            </>
          ) : null}
        </Dialog.Content>
      </Dialog>
    </>
  );
}
