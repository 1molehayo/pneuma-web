import { ClientError } from "@cms/client";
import type { Entity } from "@cms/config";
import { Badge, Button, cn, Drawer, IconButton, Skeleton, toast } from "@cms/ui";
import {
  ArrowCounterClockwiseIcon,
  ArrowRightIcon,
  CaretDownIcon,
  XIcon,
} from "@phosphor-icons/react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { client } from "@/lib/client";
import { useCanReadAuditLog } from "@/lib/hooks/use-can-read-audit-log";
import { useConfig } from "@/lib/hooks/use-config";
import { useMe } from "@/lib/hooks/use-me";
import {
  AUDIT_LOG_PAGE_SIZE,
  type AuditEntry,
  getAuditLogQueryOptions,
} from "@/lib/queries/audit-log";
import {
  getVersionQueryOptions,
  getVersionsQueryOptions,
  type VersionRow,
} from "@/lib/queries/documents";
import { invalidate, type VersionScope } from "@/lib/queries/keys";
import { auditActionLabel, auditActorLabel } from "@/lib/utils/audit-log";
import { formatDate } from "@/lib/utils/dates";
import { formatFieldPath, isRichTextBlockPath, visibleChanges } from "@/lib/utils/field-path";
import {
  buildHistoryTimeline,
  type HistoryRow,
  previousVersion,
} from "@/lib/utils/history-timeline";
import {
  diffVersionData,
  formatDiffValue,
  formatEdit,
  type VersionChange,
} from "@/lib/utils/version-diff";

type HistoryDrawerProps = {
  entity: Entity;
  /** A collection document. Omitted for a global, which `locale` scopes instead. */
  documentId?: string;
  /** A translatable global's locale. */
  locale?: string;
  /** When true, the drawer is open. The parent owns the state. */
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

type TimelineRow = HistoryRow<AuditEntry, VersionRow>;

const isForbidden = (error: unknown) => error instanceof ClientError && error.status === 403;

/**
 * One document's history, newest first. Audit entries (admins only) say who did what and which
 * fields changed; versions supply the detail: expanding a row with a version diffs it against the
 * version before it, and offers a restore. Without audit access the timeline is versions only.
 */
const HistoryDrawer = ({ entity, documentId, locale, open, onOpenChange }: HistoryDrawerProps) => {
  const versionScope: VersionScope = { entityName: entity.name, documentId, locale };
  const queryClient = useQueryClient();
  const canReadAuditLog = useCanReadAuditLog();
  const versionsEnabled = !!entity.versions;
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const auditFilters = { entity: entity.name, documentId, locale };
  // Lazy fetch — only when the drawer opens.
  const auditQuery = useQuery({
    ...getAuditLogQueryOptions({ ...auditFilters, page: 1 }),
    enabled: open && canReadAuditLog,
  });
  const versionsQuery = useQuery({
    ...getVersionsQueryOptions(versionScope),
    enabled: open && versionsEnabled,
  });

  // A query that's off still serves its cache: an admin's entries stay cached after a sign-out.
  const entries = canReadAuditLog ? (auditQuery.data?.data ?? []) : [];
  const versions = versionsQuery.data ?? [];
  const rows = buildHistoryTimeline(entries, versions);
  const isPending =
    (canReadAuditLog && auditQuery.isPending) || (versionsEnabled && versionsQuery.isPending);
  // It fails only with neither side loaded. A role without `versions.read` gets a 403 on versions:
  // its timeline is the audit side, or empty.
  const isError =
    (!canReadAuditLog || auditQuery.isError) &&
    (!versionsEnabled || versionsQuery.isError) &&
    !isForbidden(versionsQuery.error);

  const restoreMutation = useMutation({
    mutationFn: async (versionId: string) => {
      if (documentId) {
        await client.versions.restore(entity.name, documentId, versionId);
      } else {
        await client.versions.restore(entity.name, versionId, { locale });
      }
    },
    onSuccess: async () => {
      await invalidate.afterRestore(queryClient, versionScope);
      toast({ variant: "positive", title: "Version restored" });
      setExpandedId(null);
    },
    onError: (error: unknown) => {
      if (
        error instanceof ClientError &&
        (error.code === "VERSION_INCOMPATIBLE" || error.code === "VALIDATION_ERROR")
      ) {
        toast({
          variant: "negative",
          title:
            error.code === "VERSION_INCOMPATIBLE"
              ? "Restore failed: version is incompatible with the current schema"
              : error.message,
          description: error.details
            ?.map((detail) => `"${detail.field}": ${detail.message}`)
            .join(", "),
          duration: 10000,
        });
        return;
      }
      const message = error instanceof Error ? error.message : "Restore failed";
      toast({ variant: "negative", title: "Restore failed", description: message });
    },
  });

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <Drawer.Content className="md:max-w-lg">
        <Drawer.Header className="flex items-center justify-between">
          <Drawer.Title>History</Drawer.Title>
          <IconButton
            variant="ghost"
            size="sm"
            aria-label="Close history"
            onClick={() => onOpenChange(false)}
          >
            <XIcon />
          </IconButton>
        </Drawer.Header>

        {!versionsEnabled && (
          <p className="px-1 pb-4 text-xs text-foreground-secondary">
            Turn on versions for this entity to keep changes you can compare and restore.
          </p>
        )}

        {isError ? (
          <p className="px-1 py-8 text-center text-sm text-negative">Couldn't load the history.</p>
        ) : isPending ? (
          <div className="flex flex-col gap-6 px-1">
            {Array.from({ length: 4 }).map((_, index) => (
              <Skeleton key={index} className="h-10" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <p className="px-1 py-8 text-center text-sm text-foreground-secondary">
            No history recorded yet.
          </p>
        ) : (
          <ol className="px-1">
            {rows.map((row) => (
              <HistoryItem
                key={row.id}
                row={row}
                entity={entity}
                versionScope={versionScope}
                versions={versions}
                isExpanded={expandedId === row.id}
                onToggle={() => setExpandedId(expandedId === row.id ? null : row.id)}
                onRestore={(versionId) => restoreMutation.mutate(versionId)}
                isRestoring={restoreMutation.isPending}
              />
            ))}
          </ol>
        )}

        {canReadAuditLog && (
          <Drawer.Actions className="items-center justify-between">
            <p className="text-xs text-foreground-secondary">
              {auditQuery.data && auditQuery.data.meta.total > AUDIT_LOG_PAGE_SIZE
                ? `Latest ${AUDIT_LOG_PAGE_SIZE} of ${auditQuery.data.meta.total} audit entries`
                : null}
            </p>
            <Button asChild variant="outline" size="sm">
              <Link to="/settings/activity" search={auditFilters}>
                Filter and search
                <ArrowRightIcon />
              </Link>
            </Button>
          </Drawer.Actions>
        )}
      </Drawer.Content>
    </Drawer>
  );
};

type HistoryItemProps = {
  row: TimelineRow;
  entity: Entity;
  versionScope: VersionScope;
  /** Every version of the document, newest first: the row's diff base is the next one down. */
  versions: ReadonlyArray<VersionRow>;
  isExpanded: boolean;
  onToggle: () => void;
  onRestore: (versionId: string) => void;
  isRestoring: boolean;
};

/** A timeline step: a dot on the rail, who did what and when, the changed fields, and the diff. */
const HistoryItem = ({
  row,
  entity,
  versionScope,
  versions,
  isExpanded,
  onToggle,
  onRestore,
  isRestoring,
}: HistoryItemProps) => {
  const drafts = entity.versions?.drafts ?? false;
  const version = row.version;
  const canRestore = !!version && !version.isCurrent && !version.isPublished;

  const summary = (
    <div className="flex min-w-0 flex-1 flex-col gap-1">
      <div className="flex items-start justify-between gap-2">
        {row.kind === "audit" ? <AuditSummary entry={row.entry} /> : <VersionSummary row={row} />}
        {version && (
          <div className="flex shrink-0 items-center gap-1.5">
            {version.isCurrent && (
              <Badge variant="success" size="xs">
                Current
              </Badge>
            )}
            {drafts && version.isPublished && (
              <Badge variant="neutral" size="xs">
                Published
              </Badge>
            )}
            <CaretDownIcon
              aria-hidden
              className={cn(
                "size-3.5 text-foreground-secondary transition-transform duration-200 ease-(--ease-emphasized-decelerate) motion-reduce:transition-none",
                isExpanded && "rotate-180",
              )}
            />
          </div>
        )}
      </div>
      <time dateTime={row.createdAt} className="text-xs text-foreground-secondary">
        {formatDate(row.createdAt, "dateTime")}
        {row.kind === "audit" && ` · ${row.entry.actor.role}`}
      </time>
      {row.kind === "audit" && row.entry.changedFields.length > 0 && (
        <div className="mt-1 flex flex-wrap gap-1">
          {row.entry.changedFields.map((path) => (
            <Badge key={path} variant="neutral" size="xs" title={path}>
              {formatFieldPath(entity.fields, path)}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <li className="group relative flex gap-3 pb-6 last:pb-0">
      <span
        aria-hidden
        className="absolute top-4 bottom-0 left-1 w-px -translate-x-1/2 bg-border group-last:hidden"
      />
      <span aria-hidden className="mt-1.5 size-2 shrink-0 rounded-full bg-foreground-secondary" />
      <div className="flex min-w-0 flex-1 flex-col gap-3">
        {version ? (
          <button
            type="button"
            aria-expanded={isExpanded}
            className="-m-1 flex rounded-md p-1 text-left transition-colors hover:bg-foreground/5 focus-visible:outline-2 focus-visible:outline-ring"
            onClick={onToggle}
          >
            {summary}
          </button>
        ) : (
          summary
        )}
        {version && isExpanded && (
          <div className="flex flex-col gap-3">
            <VersionChanges
              fields={entity.fields}
              versionScope={versionScope}
              version={version}
              previous={previousVersion(versions, version.id)}
            />
            {canRestore && (
              <div>
                <Button
                  size="sm"
                  variant="outline"
                  isLoading={isRestoring}
                  onClick={() => onRestore(version.id)}
                >
                  <ArrowCounterClockwiseIcon />
                  Restore this version
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </li>
  );
};

const AuditSummary = ({ entry }: { entry: AuditEntry }) => {
  const { roles } = useConfig();
  return (
    <p className="text-sm">
      <span className="font-medium">{auditActorLabel(entry.actor, roles)}</span>{" "}
      <span className="text-foreground-secondary">
        {auditActionLabel(entry.action).toLowerCase()}
      </span>
    </p>
  );
};

/** A version without an audit entry: its author comes with the version. */
const VersionSummary = ({ row }: { row: Extract<TimelineRow, { kind: "version" }> }) => {
  const { data: me } = useMe();
  return (
    <p className="text-sm">
      <span className="font-medium">{versionAuthorLabel(row.version, me?.id)}</span>{" "}
      <span className="text-foreground-secondary">saved a version</span>
    </p>
  );
};

const versionAuthorLabel = (version: VersionRow, myId: string | undefined) => {
  if (!version.createdBy) return "System";
  if (version.createdBy === myId) return "You";
  return version.author?.name || version.author?.email || "Unknown user";
};

type VersionChangesProps = {
  fields: Entity["fields"];
  versionScope: VersionScope;
  version: VersionRow;
  /** The version it's compared with; null for the oldest one kept. */
  previous: VersionRow | null;
};

/** The fields a version changed from the one before it. Shows nothing to a role that can't read versions. */
const VersionChanges = ({ fields, versionScope, version, previous }: VersionChangesProps) => {
  const { data: me } = useMe();
  const versionQuery = useQuery(getVersionQueryOptions(versionScope, version.id));
  const previousQuery = useQuery({
    ...getVersionQueryOptions(versionScope, previous?.id ?? ""),
    enabled: !!previous,
  });

  if (isForbidden(versionQuery.error) || isForbidden(previousQuery.error)) return null;
  if (versionQuery.isError || previousQuery.isError) {
    return <p className="text-xs text-negative">Couldn't load the changes.</p>;
  }
  if (!previous) {
    return (
      <p className="text-xs text-foreground-secondary">
        Initial version: there's no earlier one to compare with.
      </p>
    );
  }
  if (!versionQuery.data || !previousQuery.data) return <Skeleton className="h-12" />;

  const before = previousQuery.data.data ?? {};
  const after = versionQuery.data.data ?? {};
  const allChanges = diffVersionData(before, after, {
    isAtomic: (path) => isRichTextBlockPath(fields, path),
  });
  const changes = me ? visibleChanges(fields, allChanges, { before, after }, me) : allChanges;

  if (changes.length === 0) {
    return (
      <p className="text-xs text-foreground-secondary">Same content as the version before it.</p>
    );
  }

  return (
    <ul className="flex flex-col gap-2 rounded-md border border-border p-3">
      {changes.map((change) => (
        <ChangeLine
          key={`${change.kind}:${change.path.join(".")}:${change.kind === "moved" ? change.to : ""}`}
          change={change}
          fields={fields}
        />
      ))}
    </ul>
  );
};

/** The badge after a changed path. An edited value has none: its before → after says it. */
const changeBadges = {
  added: { variant: "success", label: "Added" },
  removed: { variant: "error", label: "Removed" },
  moved: { variant: "info", label: "Moved" },
  replaced: { variant: "warning", label: "Replaced" },
} as const satisfies Record<
  Exclude<VersionChange["kind"], "edited">,
  { variant: string; label: string }
>;

const ChangeLine = ({ change, fields }: { change: VersionChange; fields: Entity["fields"] }) => {
  const badge = change.kind === "edited" ? null : changeBadges[change.kind];
  return (
    <li className="flex min-w-0 flex-col gap-1 text-xs">
      <div className="flex items-center gap-1.5">
        <span className="font-medium">{formatFieldPath(fields, change.path)}</span>
        {badge && (
          <Badge variant={badge.variant} size="xs">
            {badge.label}
          </Badge>
        )}
      </div>
      <ChangeDetail change={change} />
    </li>
  );
};

const ChangeDetail = ({ change }: { change: VersionChange }) => {
  switch (change.kind) {
    case "added":
    case "removed":
      return (
        <p className="break-words text-foreground-secondary">{formatDiffValue(change.value)}</p>
      );
    case "moved":
      return (
        <p className="break-words text-foreground-secondary">
          {formatDiffValue(change.value)}: from {change.from + 1} to {change.to + 1}
        </p>
      );
    case "replaced":
      return <BeforeAfter before={change.beforeType} after={change.afterType} />;
    case "edited":
      return <BeforeAfter {...formatEdit(change.before, change.after)} />;
  }
};

const BeforeAfter = ({ before, after }: { before: string; after: string }) => (
  <p className="flex min-w-0 flex-wrap items-baseline gap-1.5 break-words">
    <span className="text-foreground-secondary line-through">{before}</span>
    <ArrowRightIcon aria-label="changed to" className="size-3 shrink-0 self-center" />
    <span>{after}</span>
  </p>
);

export { HistoryDrawer };
