import { cn } from "@cms/ui";
import { type ReactNode, useEffect } from "react";
import { Group, Panel, Separator, useDefaultLayout, usePanelRef } from "react-resizable-panels";

const MAIN_PANEL_ID = "cms-panel-main";
const SIDE_PANEL_ID = "cms-panel-side";
const PANEL_IDS = [MAIN_PANEL_ID, SIDE_PANEL_ID];

/** One storage key for every document route: drag a width once, keep it everywhere. */
const GROUP_ID = "document-side-panel";

/**
 * Panel content asks for a width by firing this on `window` rather than through
 * a prop, so packages that render into the panel (@cms/live-preview, or any
 * consumer-supplied `admin.preview` component) need no dependency on the admin.
 * The name is the whole contract; @cms/live-preview re-exports it as
 * `SIDE_PANEL_RESIZE_EVENT`.
 */
const SIDE_PANEL_RESIZE_EVENT = "cms-side-panel-resize";

declare global {
  interface WindowEventMap {
    [SIDE_PANEL_RESIZE_EVENT]: CustomEvent<{ size: string }>;
  }
}

/**
 * The page scrolls in the window and the side panel is sticky inside it, so
 * neither the group nor the panels may become scroll containers: any `overflow`
 * other than `visible` on an ancestor breaks `position: sticky`.
 */
const GROUP_STYLE = { height: "auto", overflow: "visible" } as const;
const PANEL_STYLE = { overflow: "visible", maxHeight: "none" } as const;

type SidePanelLayoutProps = {
  children: ReactNode;
  collapseMainOnMobile?: boolean;
};

const SidePanelLayout = ({ children, collapseMainOnMobile }: SidePanelLayoutProps) => {
  const { defaultLayout, onLayoutChanged } = useDefaultLayout({
    id: GROUP_ID,
    panelIds: PANEL_IDS,
  });

  return (
    <Group
      id={GROUP_ID}
      defaultLayout={defaultLayout}
      onLayoutChanged={onLayoutChanged}
      // Hiding `Main`'s content would leave its flex slot behind, so the group
      // reaches for the panel element itself — always its first child.
      className={cn(collapseMainOnMobile && "max-md:[&>[data-panel]:first-child]:hidden")}
      style={GROUP_STYLE}
    >
      {children}
    </Group>
  );
};

const SidePanelLayoutMain = ({ children }: { children: ReactNode }) => (
  <Panel id={MAIN_PANEL_ID} minSize="20%" className="min-w-0" style={PANEL_STYLE}>
    {children}
  </Panel>
);

type SidePanelLayoutSideProps = {
  children: ReactNode;
  /** Any size the panel accepts ("50%", "480px"), used until the user drags it. */
  defaultSize?: string;
};

const SidePanelLayoutSide = ({ children, defaultSize = "50%" }: SidePanelLayoutSideProps) => {
  const panelRef = usePanelRef();

  useEffect(() => {
    const handleResize = ({ detail }: WindowEventMap[typeof SIDE_PANEL_RESIZE_EVENT]) => {
      if (detail?.size) panelRef.current?.resize(detail.size);
    };

    window.addEventListener(SIDE_PANEL_RESIZE_EVENT, handleResize);
    return () => window.removeEventListener(SIDE_PANEL_RESIZE_EVENT, handleResize);
  }, [panelRef]);

  return (
    <>
      <Separator
        aria-label="Resize panel"
        className={cn(
          "relative z-30 w-0 border-border border-l border-dashed outline-none max-md:hidden",
          "ring-ring transition-colors focus-visible:ring-4",
          "hover:border-ring hover:border-solid",
          "active:border-ring active:border-solid",
        )}
      >
        {/* Widens the hover target without taking up layout space. */}
        <span aria-hidden className="-left-1.5 absolute inset-y-0 w-3" />
      </Separator>
      <Panel
        id={SIDE_PANEL_ID}
        panelRef={panelRef}
        defaultSize={defaultSize}
        minSize="20%"
        maxSize="80%"
        className="sticky top-(--page-top) h-[calc(100vh-var(--page-top))]"
        style={PANEL_STYLE}
      >
        {children}
      </Panel>
    </>
  );
};

const CompoundSidePanelLayout = Object.assign(SidePanelLayout, {
  Main: SidePanelLayoutMain,
  Side: SidePanelLayoutSide,
});

export { CompoundSidePanelLayout as SidePanelLayout };
