import { cn } from "@cms/ui";
import type { ComponentPropsWithRef } from "react";

type BaseLayoutProps = ComponentPropsWithRef<"main">;

const BaseLayout = ({ className, children, ...props }: BaseLayoutProps) => {
  return (
    <main className={cn("flex flex-1", className)} {...props}>
      {children}
    </main>
  );
};

type BaseLayoutContentProps = ComponentPropsWithRef<"div">;

const BaseLayoutContent = ({ className, children, ...props }: BaseLayoutContentProps) => {
  return (
    <div className={cn("bg-background-secondary/8 w-full", className)} {...props}>
      {children}
    </div>
  );
};

type BaseLayoutAsideProps = ComponentPropsWithRef<"aside">;

const BaseLayoutAside = ({ className, children, ...props }: BaseLayoutAsideProps) => {
  return (
    <aside
      className={cn(
        "sticky top-(--header-height) w-64 shrink-0 border-r border-border bg-background",
        "max-h-[calc(100vh-var(--header-height))] overflow-y-auto",
        "max-md:fixed max-md:top-(--header-height) max-md:left-0 max-md:z-50 max-md:size-full",
        "max-md:not-in-data-menu-open:hidden",
        className,
      )}
      {...props}
    >
      {children}
    </aside>
  );
};

const CompoundBaseLayout = Object.assign(BaseLayout, {
  Aside: BaseLayoutAside,
  Content: BaseLayoutContent,
});

export { CompoundBaseLayout as BaseLayout };
