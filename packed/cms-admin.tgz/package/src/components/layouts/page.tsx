import { cn } from "@cms/ui";
import type { ComponentPropsWithRef } from "react";

type PageLayoutProps = ComponentPropsWithRef<"div">;

const PageLayout = ({ className, children, ...props }: PageLayoutProps) => {
  return (
    <div
      className={cn(
        "[--page-navbar-height:--spacing(12)] [--page-actions-height:--spacing(12)]",
        "[--page-top:var(--header-height)] [--page-bottom:0]",
        "has-data-layout-page-navbar:[--page-top:calc(var(--header-height)+var(--page-navbar-height))]",
        "has-data-layout-page-actions:[--page-bottom:var(--page-actions-height)]",
        "pt-(--page-navbar-height) has-data-layout-page-navbar:pt-0",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
};

type PageLayoutContainerProps = ComponentPropsWithRef<"div">;

const PageContainerLayout = ({ className, children, ...props }: PageLayoutContainerProps) => {
  return (
    <div
      className={cn(
        "max-w-200 pb-12 mx-auto px-4 md:min-w-lg md:px-6 pt-1 min-h-[calc(100vh-var(--page-top)-var(--page-bottom))]",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
};

type PageLayoutHeaderProps = ComponentPropsWithRef<"section">;

const PageLayoutHeader = ({ className, children, ...props }: PageLayoutHeaderProps) => {
  return (
    <section className={cn("my-6 lg:mt-10", className)} {...props}>
      {children}
    </section>
  );
};

type PageLayoutMediaProps = ComponentPropsWithRef<"figure">;

const PageLayoutMedia = ({ className, children, ...props }: PageLayoutMediaProps) => {
  return (
    <figure
      className={cn(
        "size-12 bg-foreground/4 mb-4 rounded-lg overflow-hidden flex items-center justify-center",
        "[&_img]:size-full *:object-cover",
        className,
      )}
      {...props}
    >
      {children}
    </figure>
  );
};

type PageLayoutTitleProps = ComponentPropsWithRef<"h1">;

const PageLayoutTitle = ({ className, children, ...props }: PageLayoutTitleProps) => {
  return (
    <h1 className={cn("text-3xl font-semibold capitalize line-clamp-1", className)} {...props}>
      {children}
    </h1>
  );
};

type PageLayoutDescriptionProps = ComponentPropsWithRef<"p">;

const PageLayoutDescription = ({ className, children, ...props }: PageLayoutDescriptionProps) => {
  return (
    <p className={cn("text-lg text-foreground-secondary mt-1 line-clamp-2", className)} {...props}>
      {children}
    </p>
  );
};

type PageLayoutNavbarProps = ComponentPropsWithRef<"div">;

const PageLayoutNavbar = ({ className, children, ...props }: PageLayoutNavbarProps) => {
  return (
    <div
      data-layout-page-navbar
      className={cn(
        "sticky h-(--page-navbar-height) top-(--header-height) py-3 border-b border-dashed border-border flex items-center gap-3 px-4 bg-background z-30",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
};

type PageLayoutActionsProps = ComponentPropsWithRef<"div">;

const PageLayoutActions = ({ className, children, ...props }: PageLayoutActionsProps) => {
  return (
    <div
      data-layout-page-actions
      className={cn(
        "sticky h-(--page-actions-height) bottom-0 py-3 border-t border-dashed border-border flex items-center justify-end gap-3 px-4 bg-background z-30",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
};

const CompoundPageLayout = Object.assign(PageLayout, {
  Container: PageContainerLayout,
  Header: PageLayoutHeader,
  Title: PageLayoutTitle,
  Description: PageLayoutDescription,
  Media: PageLayoutMedia,
  Navbar: PageLayoutNavbar,
  Actions: PageLayoutActions,
});

export { CompoundPageLayout as PageLayout };
