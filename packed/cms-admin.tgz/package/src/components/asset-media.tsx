import { FileTextIcon } from "@phosphor-icons/react";
import type { ComponentProps } from "react";
import type { Asset } from "@/lib/schemas";

type AssetMediaProps = Omit<ComponentProps<"div">, "children"> & {
  asset: Asset;
};

const AssetMedia = ({ asset, ...props }: AssetMediaProps) => {
  return (
    <div {...props}>
      {asset._entity === "_image" && (
        <img src={asset.url} alt={asset.filename} className="object-cover size-full" />
      )}
      {asset._entity === "_video" && (
        <video src={asset.url} className="object-cover size-full" muted controls />
      )}
      {asset._entity === "_file" && (
        <div className="flex items-center justify-center size-full text-foreground-secondary">
          <FileTextIcon className="size-8" />
        </div>
      )}
    </div>
  );
};

export { AssetMedia };
