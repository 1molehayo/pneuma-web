import { cn, Radio } from "@cms/ui";
import { useId } from "react";
import { formatLocaleList, getLocaleLabel } from "@/lib/utils/i18n";

type DeleteScope = "locale" | "all";

type DeleteScopeChoiceProps = {
  value: DeleteScope;
  onValueChange: (scope: DeleteScope) => void;
  /** The locale being viewed — what "Only" deletes. */
  locale: string;
  /** Every locale the deletion can reach, the active one included. */
  locales: readonly string[];
  disabled?: boolean;
};

/** Whether a delete removes the active locale's row only or the whole translation group. */
const DeleteScopeChoice = ({
  value,
  onValueChange,
  locale,
  locales,
  disabled,
}: DeleteScopeChoiceProps) => {
  const name = useId();
  const otherLocales = locales.filter((value) => value !== locale);
  const options = [
    {
      scope: "locale",
      title: `Only ${getLocaleLabel(locale)}`,
      description: `${formatLocaleList(otherLocales)} ${otherLocales.length === 1 ? "stays" : "stay"}.`,
    },
    {
      scope: "all",
      title: "All locales",
      description: `Removes ${formatLocaleList(locales)}.`,
    },
  ] satisfies Array<{ scope: DeleteScope; title: string; description: string }>;

  return (
    <fieldset className="flex flex-col gap-2 pt-2" disabled={disabled}>
      <legend className="sr-only">Delete from</legend>
      {options.map((option) => (
        <label
          key={option.scope}
          htmlFor={`${name}-${option.scope}`}
          className={cn(
            "flex cursor-pointer items-start gap-3 rounded-lg border border-border p-3 transition",
            "not-has-checked:hover:bg-foreground/2 has-checked:border-accent has-checked:bg-accent/5",
            "has-disabled:cursor-not-allowed",
          )}
        >
          <Radio
            id={`${name}-${option.scope}`}
            name={name}
            value={option.scope}
            checked={value === option.scope}
            onChange={() => onValueChange(option.scope)}
          />
          <span className="flex flex-col gap-0.5 text-sm">
            <span className="font-medium text-foreground">{option.title}</span>
            <span className="text-foreground-secondary">{option.description}</span>
          </span>
        </label>
      ))}
    </fieldset>
  );
};

export { type DeleteScope, DeleteScopeChoice };
