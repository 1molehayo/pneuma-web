import CMS_CONFIG from "virtual:cms-config";
import type { DocumentBannerProps } from "@cms/config";
import { cn } from "@cms/ui";
import { useRouteContext } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { canOpenPage } from "@/lib/utils/sidebar";

/** The project's banners, then each plugin's, loaded the first time an editor renders them. */
const BANNERS = [
  ...(CMS_CONFIG.admin?.documentBanners ?? []),
  ...CMS_CONFIG.plugins.flatMap((plugin) => plugin.admin?.documentBanners ?? []),
].map((banner) => ({ def: banner, Banner: lazy(banner.component) }));

type DocumentBannersProps = DocumentBannerProps & { className?: string };

/**
 * The `admin.documentBanners` the editor's role may see, above a document's fields. Each one
 * decides on its own whether it applies; the list takes no room when none renders.
 */
export function DocumentBanners({ entity, document, className }: DocumentBannersProps) {
  const { me } = useRouteContext({ from: "/_authenticated" });
  const role = CMS_CONFIG.roles.find((candidate) => candidate.name === me.role);
  const visible = role ? BANNERS.filter((banner) => canOpenPage(banner.def, role)) : [];
  if (visible.length === 0) return null;
  return (
    <Suspense fallback={null}>
      <div className={cn("flex flex-col gap-2 empty:hidden", className)}>
        {visible.map(({ Banner }, index) => (
          // The list is fixed at build time, so the index is a stable key.
          <Banner key={index} entity={entity} document={document} />
        ))}
      </div>
    </Suspense>
  );
}
