import { Button, cn, Dialog, Input, Skeleton, Slot, useDelayedLoading } from "@cms/ui";
import {
  CheckIcon,
  FileTextIcon,
  MagnifyingGlassIcon,
  TagIcon,
  XIcon,
} from "@phosphor-icons/react";
import { createContext, use, useCallback, useEffect, useMemo, useState } from "react";
import { AssetUploadInput } from "@/components/forms/asset-upload-input";
import { useAssets } from "@/lib/hooks/use-assets";
import type { Asset } from "@/lib/schemas";

type AssetType = "_image" | "_video" | "_file";

type AssetManagerContextValue = {
  open: boolean;
  setOpen: (open: boolean) => void;
};

const AssetManagerContext = createContext<AssetManagerContextValue | null>(null);

const useAssetManagerContext = () => {
  const context = use(AssetManagerContext);
  if (!context) {
    throw new Error("AssetManager compound components must be used within <AssetManager>");
  }
  return context;
};

type AssetManagerProps = {
  types: AssetType[];
  value: string[];
  onChange: (value: string[]) => void;
  min?: number;
  max?: number;
  children: React.ReactNode;
};

const AssetManager = ({ types, value, onChange, min, max, children }: AssetManagerProps) => {
  const [open, setOpen] = useState(false);

  const ctx = useMemo(() => ({ open, setOpen }), [open]);

  return (
    <AssetManagerContext value={ctx}>
      {children}
      <AssetManagerDialog
        open={open}
        onOpenChange={setOpen}
        types={types}
        value={value}
        onChange={onChange}
        min={min}
        max={max}
      />
    </AssetManagerContext>
  );
};

type AssetManagerTriggerProps = React.ComponentPropsWithRef<"button"> & {
  asChild?: boolean;
};

const AssetManagerTrigger = ({ asChild, children, ...props }: AssetManagerTriggerProps) => {
  const { setOpen } = useAssetManagerContext();

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    props.onClick?.(event);
    if (!event.defaultPrevented) {
      setOpen(true);
    }
  };

  const Component = asChild ? Slot : "button";

  return (
    <Component type={asChild ? undefined : "button"} {...props} onClick={handleClick}>
      {children}
    </Component>
  );
};

type AssetManagerDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  types: AssetType[];
  value: string[];
  onChange: (value: string[]) => void;
  min?: number;
  max?: number;
};

const AssetManagerDialog = ({
  open,
  onOpenChange,
  types,
  value,
  onChange,
  max,
}: AssetManagerDialogProps) => {
  const [selected, setSelected] = useState<string[]>(value);
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const [search, setSearch] = useState("");

  const { data: assets, isPending } = useAssets(types);
  const showPending = useDelayedLoading(isPending);

  const allTags = useMemo(() => {
    if (!assets) return [];
    const set = new Set<string>();
    for (const asset of assets) {
      for (const tag of asset.tags ?? []) set.add(tag);
    }
    return [...set].sort();
  }, [assets]);

  const filteredAssets = useMemo(() => {
    if (!assets) return assets;
    return assets.filter((a) => {
      if (activeTags.length > 0 && !activeTags.every((t) => a.tags?.includes(t))) return false;
      if (search.trim()) {
        return a.filename.toLowerCase().includes(search.trim().toLowerCase());
      }
      return true;
    });
  }, [assets, activeTags, search]);

  const toggleTag = (tag: string) => {
    setActiveTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  const atMax = max !== undefined && selected.length >= max;

  const toggle = useCallback(
    (id: string) => {
      setSelected((prev) => {
        if (prev.includes(id)) {
          return prev.filter((x) => x !== id);
        }

        if (max === 1) {
          return [id];
        }

        if (max !== undefined && prev.length >= max) {
          return prev;
        }

        return [...prev, id];
      });
    },
    [max],
  );

  const handleConfirm = () => {
    onChange(selected);
    onOpenChange(false);
  };

  useEffect(() => {
    setSelected(value);
  }, [value]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <Dialog.Content className="md:max-w-4xl h-[80svh] flex flex-col">
        <Dialog.Title>Select asset</Dialog.Title>
        <div className="mt-3">
          <AssetUploadInput types={types} multiple />
        </div>
        <Input.Group className="mt-3">
          <Input.Addon>
            <MagnifyingGlassIcon size={14} className="text-foreground-secondary" />
          </Input.Addon>
          <Input
            placeholder="Search by filename…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </Input.Group>
        {allTags.length > 0 && (
          <div className="mt-3 flex items-center gap-3 rounded-lg bg-background-secondary px-3 py-2">
            <TagIcon size={14} className="shrink-0 text-foreground-secondary" />
            <div className="flex flex-1 flex-wrap gap-1.5">
              {allTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={cn(
                    "cursor-pointer rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
                    activeTags.includes(tag)
                      ? "bg-foreground text-background"
                      : "bg-background text-foreground/70 hover:text-foreground",
                  )}
                >
                  {tag}
                </button>
              ))}
            </div>
            {activeTags.length > 0 && (
              <button
                type="button"
                onClick={() => setActiveTags([])}
                className="inline-flex shrink-0 cursor-pointer items-center gap-1 text-xs text-foreground-secondary transition-colors hover:text-foreground"
              >
                <XIcon size={12} />
                Clear
              </button>
            )}
          </div>
        )}
        <div className="mt-4 max-h-[60vh] overflow-y-auto flex-1">
          {showPending ? (
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-5 md:grid-cols-6">
              {new Array(12).fill(null).map((_, i) => (
                <Skeleton key={`skeleton-${i}`} className="aspect-square rounded-lg" />
              ))}
            </div>
          ) : filteredAssets?.length === 0 ? (
            <p className="py-10 text-center text-sm text-foreground-secondary">
              No assets yet — upload one above
            </p>
          ) : (
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-5 md:grid-cols-6">
              {filteredAssets?.map((asset) => (
                <AssetPickerItem
                  key={asset.id}
                  asset={asset}
                  isSelected={selected.includes(asset.id)}
                  disabled={max !== 1 && atMax && !selected.includes(asset.id)}
                  onToggle={() => toggle(asset.id)}
                />
              ))}
            </div>
          )}
        </div>
        <Dialog.Actions>
          <Dialog.Close asChild>
            <Button variant="outline">Cancel</Button>
          </Dialog.Close>
          <Button onClick={handleConfirm}>Select {max && max > 1 ? selected.length : ""}</Button>
        </Dialog.Actions>
      </Dialog.Content>
    </Dialog>
  );
};

type AssetPickerItemProps = {
  asset: Asset;
  isSelected: boolean;
  disabled: boolean;
  onToggle: () => void;
};

const AssetPickerItem = ({ asset, isSelected, disabled, onToggle }: AssetPickerItemProps) => {
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={disabled}
      className={cn(
        "flex flex-col gap-1 cursor-pointer rounded-xl border-2 transition-colors",
        "disabled:opacity-40 p-0.5",
        isSelected ? "border-accent" : "border-transparent hover:border-border",
      )}
    >
      <div className="relative aspect-square w-full overflow-hidden rounded-lg">
        {asset._entity === "_image" && (
          <img
            src={asset.url}
            alt={asset.alt ?? asset.filename}
            className="h-full w-full object-cover"
          />
        )}
        {asset._entity === "_video" && (
          <video src={asset.url} className="h-full w-full object-cover" muted />
        )}
        {asset._entity === "_file" && (
          <div className="flex flex-col items-center justify-center gap-1 h-full w-full bg-foreground/2 text-foreground-secondary">
            <FileTextIcon className="size-6" />
          </div>
        )}
        {isSelected && (
          <span className="absolute top-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-accent text-accent-foreground">
            <CheckIcon size={12} />
          </span>
        )}
      </div>
      <span className="truncate px-0.5 pb-0.5 text-xs text-foreground-secondary">
        {asset.filename}
      </span>
    </button>
  );
};

const CompoundAssetManager = Object.assign(AssetManager, {
  Trigger: AssetManagerTrigger,
});

export type { AssetType };
export { CompoundAssetManager as AssetManager };
