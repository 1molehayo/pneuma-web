import CMS_CONFIG from "virtual:cms-config";
import { Button, Dropdown } from "@cms/ui";
import { CaretDownIcon, CheckIcon, TranslateIcon } from "@phosphor-icons/react";
import { getLocaleLabel } from "@/lib/utils/i18n";

const locales = CMS_CONFIG.i18n.locales || [];

type ListLocaleSwitcherProps = {
  /** The locale the list is currently scoped to. */
  activeLocale: string;
  /** Scope the list to a different locale (sets `?locale=`). */
  onSelect: (locale: string) => void;
};

/**
 * List-level locale switcher — reuses the document switcher's look, but its
 * action scopes the whole list to a locale (`?locale=`) rather than navigating
 * to a sibling document. Only rendered for translatable entities in projects
 * with more than one locale.
 */
export function ListLocaleSwitcher({ activeLocale, onSelect }: ListLocaleSwitcherProps) {
  return (
    <Dropdown>
      <Dropdown.Trigger asChild>
        <Button variant="outline" size="sm">
          <TranslateIcon />
          {getLocaleLabel(activeLocale)}
          <CaretDownIcon className="ml-2" />
        </Button>
      </Dropdown.Trigger>
      <Dropdown.Items>
        {locales.map((locale) => {
          const isActive = locale.value === activeLocale;
          return (
            <Dropdown.Item
              key={locale.value}
              onSelect={() => onSelect(locale.value)}
              disabled={isActive}
            >
              {locale.label}
              {isActive && <CheckIcon className="ml-auto" />}
            </Dropdown.Item>
          );
        })}
      </Dropdown.Items>
    </Dropdown>
  );
}
