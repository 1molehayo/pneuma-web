import CMS_CONFIG from "virtual:cms-config";
import { cn } from "@cms/ui";
import { useRouteContext } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { canOpenPage } from "@/lib/utils/sidebar";

/** The project's widgets, loaded the first time the dashboard renders them. Plugins add none. */
const WIDGETS = (CMS_CONFIG.admin?.dashboardWidgets ?? []).map((widget) => ({
  def: widget,
  Widget: lazy(widget.component),
}));

/** The `admin.dashboardWidgets` the editor's role may see, as a grid of cards. */
export function DashboardWidgets({ className }: { className?: string }) {
  const { me } = useRouteContext({ from: "/_authenticated" });
  const role = CMS_CONFIG.roles.find((candidate) => candidate.name === me.role);
  const visible = role ? WIDGETS.filter((widget) => canOpenPage(widget.def, role)) : [];
  if (visible.length === 0) return null;
  return (
    <Suspense fallback={null}>
      <section className={cn("grid gap-3 empty:hidden sm:grid-cols-2", className)}>
        {visible.map(({ Widget }, index) => (
          // The list is fixed at build time, so the index is a stable key.
          <Widget key={index} />
        ))}
      </section>
    </Suspense>
  );
}
