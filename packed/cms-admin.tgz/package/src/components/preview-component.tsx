import type { Entity } from "@cms/config";
import { useQueries } from "@tanstack/react-query";
import { useMemo, useRef } from "react";
import { useDocumentForm } from "@/components/forms/document-form";
import { getDocumentQueryOptions } from "@/lib/queries/documents";

type RelationRef = { id: string; _entity: string };

const isRelationRef = (value: unknown): value is RelationRef =>
  typeof value === "object" &&
  value !== null &&
  typeof (value as RelationRef).id === "string" &&
  typeof (value as RelationRef)._entity === "string";

/** Every relation ref ({ id, _entity }) found anywhere in `data`, deduplicated. */
const collectRelationRefs = (
  data: unknown,
  acc: Map<string, RelationRef> = new Map(),
): Map<string, RelationRef> => {
  if (Array.isArray(data)) {
    for (const item of data) collectRelationRefs(item, acc);
  } else if (isRelationRef(data)) {
    acc.set(`${data._entity}:${data.id}`, data);
  } else if (typeof data === "object" && data !== null) {
    for (const value of Object.values(data)) collectRelationRefs(value, acc);
  }
  return acc;
};

/** Replace each relation ref in `data` with its resolved record from `byId`,
 *  leaving unresolved refs and all non-relation values untouched. */
const resolveRelationRefs = (data: unknown, byId: Map<string, unknown>): unknown => {
  if (Array.isArray(data)) {
    return data.map((item) => resolveRelationRefs(item, byId));
  }
  if (isRelationRef(data)) {
    return byId.get(data.id) ?? data;
  }
  if (typeof data === "object" && data !== null) {
    return Object.fromEntries(
      Object.entries(data).map(([key, value]) => [key, resolveRelationRefs(value, byId)]),
    );
  }
  return data;
};

interface PreviewComponentProps {
  component: NonNullable<Entity["admin"]["preview"]>;
  schema: Entity["schema"];
  initialData: Record<string, unknown>;
}

/**
 * Renders the user-supplied preview component with the *last valid* form state.
 * While the editor is mid-edit, intermediate values that don't match the entity
 * schema would crash entity-specific previews (e.g. number fields showing `""`),
 * so we safeParse on every render and freeze at the last shape the schema
 * accepted.
 *
 * The form stores all relations as bare `{ id, _entity }` refs, but consumer
 * previews expect resolved records. We fetch and inline every ref found anywhere
 * in the data tree, so images, links, and any future relation type all resolve
 * without needing per-field patches. Newly picked relations resolve as soon as
 * their fetch lands.
 */
export const PreviewComponent = ({
  component: Component,
  schema,
  initialData,
}: PreviewComponentProps) => {
  const { formData } = useDocumentForm();
  const lastValidRef = useRef<Record<string, unknown>>(initialData);

  const data = useMemo(() => {
    const result = schema.safeParse(formData);
    if (result.success) {
      lastValidRef.current = result.data as Record<string, unknown>;
    }
    return lastValidRef.current;
  }, [formData, schema]);

  const relationRefs = useMemo(() => [...collectRelationRefs(data).values()], [data]);
  const relationQueries = useQueries({
    queries: relationRefs.map((ref) => getDocumentQueryOptions(ref._entity, ref.id)),
  });

  const resolved = useMemo(() => {
    const byId = new Map<string, unknown>();
    relationQueries.forEach((query, index) => {
      const ref = relationRefs[index];
      if (ref && query.data) byId.set(ref.id, query.data);
    });
    return byId.size > 0 ? resolveRelationRefs(data, byId) : data;
  }, [data, relationRefs, relationQueries]);

  return <Component data={resolved as Parameters<typeof Component>[0]["data"]} />;
};
