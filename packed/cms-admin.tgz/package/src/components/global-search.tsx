import CMS_CONFIG from "virtual:cms-config";
import { Badge, cn, Kbd, Modal, Spinner, useDelayedLoading } from "@cms/ui";
import { MagnifyingGlassIcon, WarningIcon, XIcon } from "@phosphor-icons/react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useId, useRef, useState } from "react";
import type { SearchResult } from "@/lib/queries/search";
import { getSearchQueryOptions } from "@/lib/queries/search";
import { resolveEntityTitle } from "@/lib/utils/config";
import { resolveDocumentMeta } from "@/lib/utils/documents";

const isMac = typeof navigator !== "undefined" && /Mac|iPad|iPhone|iPod/.test(navigator.userAgent);
const locales = CMS_CONFIG.i18n.locales || [];
const isMultiLocale = locales.length > 1;

type GlobalSearchProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

const GlobalSearch = ({ open, onOpenChange }: GlobalSearchProps) => {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const [selectedLocale, setSelectedLocale] = useState<string | undefined>(undefined);
  const inputRef = useRef<HTMLInputElement>(null);
  const listboxId = useId();

  useEffect(() => {
    if (!open) {
      setQuery("");
      setDebouncedQuery("");
      setActiveIndex(0);
      setSelectedLocale(undefined);
    } else {
      setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [open]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query.trim()), 300);
    return () => clearTimeout(timer);
  }, [query]);

  const { data, isFetching, isError } = useQuery(
    getSearchQueryOptions(debouncedQuery, selectedLocale),
  );
  const results = data?.results ?? [];
  const showFetching = useDelayedLoading(isFetching);

  // biome-ignore lint/correctness/useExhaustiveDependencies: reset index when results change, not on every render
  useEffect(() => setActiveIndex(0), [data]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      const result = results[activeIndex];
      if (result) {
        onOpenChange(false);
        document.getElementById(`search-result-${activeIndex}`)?.click();
      }
    }
  };

  const showResults = results.length > 0;
  const showEmpty = debouncedQuery && !isFetching && !isError && results.length === 0;
  const showError = isError && debouncedQuery;
  const showLocaleFilter = isMultiLocale && debouncedQuery.length > 0;

  return (
    <Modal open={open} onOpenChange={onOpenChange}>
      <Modal.Content
        catchFocus={false}
        className={cn(
          "mt-[15vh] max-w-xl mx-auto w-[calc(100vw-(--spacing(4)))] block rounded-2xl border border-border bg-background shadow-lg",
          "backdrop:bg-black/20 backdrop:backdrop-blur-sm",
          "transition-all duration-300 backdrop:transition-all motion-reduce:transition-none motion-reduce:backdrop:transition-none",
          "not-data-[status=open]:translate-y-2 not-data-[status=open]:scale-95 not-data-[status=open]:opacity-0 not-data-[status=open]:duration-150 not-data-[status=open]:backdrop:opacity-0",
        )}
      >
        <Modal.Title className="sr-only">Search</Modal.Title>

        {/* overflow-hidden is on this inner div, not the animated dialog, so scale stays GPU-composited */}
        <div className="w-full overflow-hidden rounded-[inherit]">
          <div
            className={cn(
              "flex h-12 items-center gap-3 px-4",
              (showResults || showEmpty || showError || showLocaleFilter) &&
                "border-b border-border",
            )}
          >
            <label
              htmlFor="global-search-input"
              className="flex size-4 shrink-0 items-center justify-center text-foreground-secondary"
            >
              <MagnifyingGlassIcon aria-hidden />
            </label>
            <input
              ref={inputRef}
              id="global-search-input"
              role="combobox"
              aria-expanded={showResults}
              aria-controls={listboxId}
              aria-activedescendant={showResults ? `search-result-${activeIndex}` : undefined}
              aria-autocomplete="list"
              className="h-full flex-1 bg-transparent text-base font-medium outline-none placeholder:text-foreground-secondary"
              placeholder="Search..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            {showFetching ? (
              <Spinner size="sm" className="shrink-0 text-foreground-secondary" />
            ) : (
              !query && (
                <Kbd.Group aria-hidden className="shrink-0">
                  <Kbd size="sm">{isMac ? "⌘" : "Ctrl"}</Kbd>
                  <Kbd size="sm">K</Kbd>
                </Kbd.Group>
              )
            )}
          </div>

          {showLocaleFilter && (
            <div
              className="flex items-center gap-1.5 border-b border-border px-3 py-2"
              role="group"
              aria-label="Filter by locale"
            >
              {locales.map((locale) => {
                const isActive = selectedLocale === locale.value;
                return (
                  <Badge
                    key={locale.value}
                    asChild
                    size="sm"
                    variant="neutral"
                    className={cn(
                      "cursor-pointer uppercase transition-opacity",
                      selectedLocale !== undefined && !isActive && "opacity-40",
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => setSelectedLocale(isActive ? undefined : locale.value)}
                    >
                      {locale.value}
                      {isActive && <XIcon weight="bold" />}
                    </button>
                  </Badge>
                );
              })}
            </div>
          )}

          {showResults && (
            <div
              id={listboxId}
              role="listbox"
              tabIndex={-1}
              aria-label="Search results"
              className="max-h-96 overflow-y-auto p-1.5"
            >
              {results.map((result, i) => (
                <ResultItem
                  key={`${result.entity}-${result.document.id}`}
                  id={`search-result-${i}`}
                  result={result}
                  active={i === activeIndex}
                  onClose={() => onOpenChange(false)}
                  onHover={() => setActiveIndex(i)}
                />
              ))}
            </div>
          )}

          {showEmpty && (
            <p className="px-4 py-8 text-center text-sm text-foreground-secondary">
              No results for &ldquo;{debouncedQuery}&rdquo;
            </p>
          )}

          {showError && (
            <p className="flex items-center justify-center gap-2 px-4 py-8 text-center text-sm text-foreground-secondary">
              <WarningIcon className="text-negative" aria-hidden />
              Search failed — try again
            </p>
          )}
        </div>
      </Modal.Content>
    </Modal>
  );
};

type ResultItemProps = {
  id: string;
  result: SearchResult;
  active: boolean;
  onClose: () => void;
  onHover: () => void;
};

const ResultItem = ({ id, result, active, onClose, onHover }: ResultItemProps) => {
  const ref = useRef<HTMLAnchorElement>(null);
  const meta = resolveDocumentMeta(result.entity, result.document);
  const locale = result.document.locale as string | undefined;

  useEffect(() => {
    if (active) ref.current?.scrollIntoView({ block: "nearest" });
  }, [active]);

  const linkProps = result.global
    ? {
        to: "/global/$name/{-$locale}" as const,
        params: { name: result.entity, locale: locale ?? undefined },
      }
    : { to: "/entity/$name/$id" as const, params: { name: result.entity, id: result.document.id } };

  return (
    <Link
      ref={ref}
      id={id}
      role="option"
      aria-selected={active}
      className={cn(
        "flex w-full cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors",
        "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring",
        active
          ? "bg-foreground/8 active:bg-foreground/12"
          : "hover:bg-foreground/5 active:bg-foreground/8",
      )}
      onClick={onClose}
      onMouseEnter={onHover}
      {...linkProps}
    >
      <figure className="flex size-8 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-border bg-background-secondary text-base *:object-cover [&_img]:size-full">
        {meta.media}
      </figure>
      <span className="flex min-w-0 flex-col">
        <span className="truncate font-medium leading-snug">{meta.title}</span>
        <span className="text-xs text-foreground-secondary">
          {resolveEntityTitle(result.entity)}
        </span>
      </span>
      <span className="ml-auto flex shrink-0 items-center gap-1.5">
        {isMultiLocale && locale && (
          <Badge size="xs" variant="info" className="uppercase">
            {locale.toUpperCase()}
          </Badge>
        )}
        {result.global && (
          <span className="rounded-md border border-border px-1.5 py-0.5 text-xs text-foreground-secondary">
            Global
          </span>
        )}
      </span>
    </Link>
  );
};

export { GlobalSearch };
