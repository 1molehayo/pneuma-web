// What a project's or plugin's admin page needs, behind a subpath whose static graph never
// reaches `virtual:cms-config` (unlike the main entry), so a package can import and type-check
// it on its own: the API client, signed in as the editor, the built-in pages' layout, the
// admin router's `Link`, `useNavigate` and `useSearch`, so a page links to (or moves on to)
// documents and other pages without a full reload and reads its own `?query`, and the project's
// config with the way the admin shows a document, for a package's field input that picks
// documents (searched under a key every write refreshes) and read a picked one the way a
// relation card does.
export { Link, useNavigate, useSearch } from "@tanstack/react-router";
export { PageLayout } from "./components/layouts/page";
export { useAdminConfig } from "./lib/admin-config";
export { client } from "./lib/client";
export { getDocumentSummaryQueryOptions } from "./lib/queries/document-summaries";
export { getEntitySearchQueryOptions } from "./lib/queries/search";
export { type DocumentMeta, getDocumentMeta } from "./lib/utils/document-meta";
