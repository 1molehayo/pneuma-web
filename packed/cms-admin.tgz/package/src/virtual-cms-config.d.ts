declare module "virtual:cms-config" {
  import type { CmsConfig } from "@cms/config";

  const config: CmsConfig;
  export default config;
}
