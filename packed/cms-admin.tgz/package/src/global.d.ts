import "react";

declare module "react" {
  interface CSSProperties {
    [key: `--${string}`]: string | number;
  }
  interface HTMLAttributes {
    popover?: undefined; // Custom attribute for popover
  }
}
