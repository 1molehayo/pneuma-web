import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import type { CmsConfig } from "@cms/config";
import tailwindcss from "@tailwindcss/vite";
import { TanStackRouterVite } from "@tanstack/router-plugin/vite";
import react from "@vitejs/plugin-react";
import type { InlineConfig, Plugin, PluginOption, ViteDevServer } from "vite";
import { build as viteBuild, createServer as viteCreateServer } from "vite";
import { getConfigFilePath, virtualConfigPlugin } from "../virtual-cms-config";
import { serverModuleStubPlugin } from "./server-module-stub";
import { uiPackageSources } from "./ui-package-sources";

function configTailwindSourcePlugin(): Plugin {
  return {
    name: "cms-config-tailwind-source",
    enforce: "pre",
    transform(code, id) {
      if (!id.endsWith("/src/styles/global.css")) return;
      // Tailwind's scanner roots at the admin package, but the consumer's
      // cms.config.tsx (and any custom components it imports) lives outside
      // it, and so do packages that render admin UI (plugin pages, field
      // inputs) — their class names would never compile. Add them as explicit
      // sources.
      const configDir = dirname(getConfigFilePath());
      const sources = [configDir, ...uiPackageSources(configDir)];
      const directives = sources.map((dir) => `@source "${dir.replaceAll("\\", "/")}";`);
      return `${code}\n${directives.join("\n")}\n`;
    },
  };
}

function runtimeEnvScriptPlugin(): Plugin {
  return {
    name: "cms-runtime-env-script",
    transformIndexHtml() {
      // Load the engine-served public runtime env (window[__CMS_PUBLIC_ENV__])
      // before the app boots. A non-module script in <head> runs synchronously
      // ahead of the deferred module entry, so custom components can read
      // env() on first render. The engine serves /admin/runtime-env.js in both
      // `cms dev` (Vite) and `cms start` (static).
      return [
        { tag: "script", attrs: { src: "/admin/runtime-env.js" }, injectTo: "head" as const },
      ];
    },
  };
}

export function adminViteConfig(_config: CmsConfig): InlineConfig {
  // This file lives one level below the package root in both layouts:
  // src/build.ts (monorepo) and dist/build.js (published tarball).
  const adminRoot = resolve(import.meta.dirname, "..");

  return {
    configFile: false,
    root: adminRoot,
    base: "/admin/",
    envDir: process.cwd(),
    // When @cms/admin is installed from a tarball, its source lives inside the
    // consumer's node_modules. Vite refuses to pre-bundle any dependency whose
    // importer is inside node_modules, so deps reached only through code-split
    // route chunks (autoCodeSplitting) get served raw at runtime — breaking CJS
    // named-export interop (e.g. use-sync-external-store). Point the dep scanner
    // at the admin source so every dependency is discovered and pre-bundled at
    // startup, before that guard can apply — matching how the monorepo behaves.
    optimizeDeps: {
      // Scan every browser source directory so all third-party deps are
      // discovered and pre-bundled at startup — including those reached only
      // through code-split route chunks (autoCodeSplitting), where Vite's
      // "don't pre-bundle deps imported from inside node_modules" guard would
      // otherwise serve them raw and break CJS named-export interop. `lib/` is
      // listed explicitly: with `@` excluded below, its deps are no longer
      // discovered transitively through a pre-bundled `@/lib/*` module, so it
      // must be a scan root in its own right. `build.ts` is intentionally NOT
      // scanned — it is node-only (imports vite, @tailwindcss/vite, the native
      // oxide binary) and pulling it into the browser optimizer crashes it.
      entries: [
        resolve(adminRoot, "index.html"),
        resolve(adminRoot, "src/routes/**/*.{ts,tsx}"),
        resolve(adminRoot, "src/components/**/*.{ts,tsx}"),
        resolve(adminRoot, "src/lib/**/*.{ts,tsx}"),
        // Tests and fixtures import dev-only packages (vitest) a consumer never
        // installs; as scan entries they fail the whole scan and skip pre-bundling.
        `!${resolve(adminRoot, "src/**/*.test.{ts,tsx}")}`,
        `!${resolve(adminRoot, "src/**/__fixtures__/**")}`,
      ],
      // The admin's own source must never be pre-bundled as a dependency — only
      // real third-party packages should be. Under a tarball install the source
      // lives inside the consumer's node_modules, so the dep scanner can't tell
      // admin source from a dep: a `@/…`-aliased import resolves into
      // node_modules and gets flattened into a pre-bundle. That bakes a SECOND
      // copy of any module ALSO reached via a relative import — harmless for
      // stateless modules, but fatal for singletons like the DocumentForm
      // context, where `useDocumentForm()` would read a different instance than
      // the provider sets ("must be used within DocumentForm"). Excluding the
      // `@` alias prefix (matches only `@/…`, never scoped packages like
      // `@cms/ui`) keeps admin source out of the optimizer entirely, so `@/…`
      // and `./…` always converge on one shared source module — import style no
      // longer affects module identity. `@cms/admin` stays excluded so consumer
      // custom components importing `@cms/admin/document-form-context` as a bare
      // specifier resolve to the same source module via the alias below.
      // (Build mode is unaffected — Rollup applies the aliases everywhere.)
      exclude: ["@cms/admin", "@"],
      // The optimizer bundles third-party packages without the main plugin
      // pipeline, so a package's `.server.js` reached from cms.config would
      // otherwise be pre-bundled for real. Plugins listed here also run before
      // the dep scanner's own loader.
      rolldownOptions: { plugins: [serverModuleStubPlugin()] },
    },
    // cms.config.ts is bundled into the browser via the virtual plugin.
    // Any process.env.X access in it should silently resolve to undefined
    // in the browser — the server reads the real env at startup. Node-only
    // code belongs in `*.server.ts` modules, which serverModuleStubPlugin
    // replaces with throwing stubs.
    define: {
      "process.env": "{}",
    },
    plugins: [
      TanStackRouterVite({
        target: "react",
        autoCodeSplitting: true,
      }),
      react(),
      configTailwindSourcePlugin(),
      tailwindcss(),
      serverModuleStubPlugin(),
      virtualConfigPlugin(),
      runtimeEnvScriptPlugin(),
    ],
    resolve: {
      // The consumer's cms.config.tsx (and anything it imports, e.g. compiled
      // @cms/paths) is bundled together with the admin source. Both sides must
      // resolve shared modules to a single instance — a duplicated React or a
      // duplicated context module breaks hooks and `useContext` silently.
      dedupe: [
        "react",
        "react-dom",
        "zod",
        "motion",
        "@phosphor-icons/react",
        "@tanstack/react-query",
        "@cms/ui",
        "@cms/config",
        "@cms/client",
      ],
      // Package-specifier imports of @cms/admin (from consumer custom
      // components) must converge on the same modules the SPA imports
      // relatively. Without this, a subpath would resolve to its compiled dist
      // copy instead — a second module instance, fatal for anything holding
      // shared singleton state (a `createContext`, a module-level cache/ref).
      // `field-input` needs this for the same reason `document-form-context`
      // does: it transitively imports `document-form-context.ts` (via
      // `union-input.tsx`/`object-input.tsx`'s own `useDocumentForm()` calls),
      // so a duplicated copy makes their `use(DocumentFormContext)` look for a
      // provider of a Context object the real DocumentForm never provided —
      // "must be used within DocumentForm" even though one is genuinely
      // mounted, just via the other copy.
      // Order matters: longest match first.
      alias: [
        {
          find: "@cms/admin/document-form-context",
          replacement: resolve(adminRoot, "src/components/forms/document-form-context.ts"),
        },
        {
          find: "@cms/admin/field-input",
          replacement: resolve(adminRoot, "src/components/forms/inputs/field-input.tsx"),
        },
        { find: "@cms/admin/page", replacement: resolve(adminRoot, "src/page.ts") },
        { find: /^@cms\/admin$/, replacement: resolve(adminRoot, "src/index.ts") },
        { find: "@", replacement: resolve(adminRoot, "src") },
      ],
    },
    build: {
      outDir: resolve(process.cwd(), ".cms/admin-dist"),
      // Not `assets`: the admin's Assets page is routed at /admin/assets.
      assetsDir: "_assets",
      emptyOutDir: true,
    },
  };
}

export async function createAdminDevServer(config: CmsConfig): Promise<ViteDevServer> {
  return viteCreateServer({
    ...adminViteConfig(config),
    server: { middlewareMode: true },
  });
}

function getAdminVersion(adminRoot: string): string {
  const pkg = JSON.parse(readFileSync(resolve(adminRoot, "package.json"), "utf8")) as {
    version?: string;
  };
  return pkg.version ?? "0.0.0";
}

export type AdminBuildMeta = {
  adminVersion: string;
  configHash: string;
  builtAt: string;
};

export function hashConfigFile(): string {
  return createHash("sha256").update(readFileSync(getConfigFilePath())).digest("hex");
}

export async function buildAdmin(config: CmsConfig): Promise<void> {
  const viteConfig = adminViteConfig(config);
  // Build-only — `cms dev` never runs plugins' build hooks. No source maps unless a plugin asks
  // for them (hidden: no sourceMappingURL comment in the served bundle), e.g. to upload them.
  const pluginBuilds = await Promise.all(config.plugins.map((plugin) => plugin.build?.vite?.()));
  await viteBuild({
    ...viteConfig,
    plugins: [
      ...(viteConfig.plugins ?? []),
      ...pluginBuilds.flatMap((pluginBuild) => (pluginBuild?.plugins ?? []) as PluginOption[]),
    ],
    build: {
      ...viteConfig.build,
      sourcemap: pluginBuilds.some((pluginBuild) => pluginBuild?.sourcemap === "hidden")
        ? "hidden"
        : false,
    },
  });

  // Stamp the build so `cms start` can detect missing or stale admin builds.
  const adminRoot = resolve(import.meta.dirname, "..");
  const meta: AdminBuildMeta = {
    adminVersion: getAdminVersion(adminRoot),
    configHash: hashConfigFile(),
    builtAt: new Date().toISOString(),
  };
  const outDir = resolve(process.cwd(), ".cms/admin-dist");
  await writeFile(resolve(outDir, "meta.json"), `${JSON.stringify(meta, null, 2)}\n`);
}
