import { existsSync, readFileSync, realpathSync } from "node:fs";
import { dirname, join } from "node:path";

type PackageJson = {
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  peerDependencies?: Record<string, string>;
};

/** Packages whose classes the admin's stylesheet already covers. */
const CORE_PACKAGES = new Set(["@cms/admin", "@cms/ui", "@cms/engine"]);
const UI_PEERS = ["@cms/admin", "@cms/ui"];

const readPackageJson = (dir: string): PackageJson =>
  JSON.parse(readFileSync(join(dir, "package.json"), "utf8")) as PackageJson;

/** The nearest directory at or above `from` holding `relativePath`, or null. */
function findUp(from: string, relativePath: string): string | null {
  let dir = from;
  while (true) {
    if (existsSync(join(dir, relativePath))) return dir;
    const parent = dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

/**
 * The directories of the project's dependencies that render admin UI: plugin pages and custom
 * field inputs from packages (`@cms/redirects`, `@cms/paths`). Tailwind never scans
 * `node_modules`, so without these as sources a class only such a package uses would get no CSS.
 * A package counts when it depends or peers on `@cms/admin` or `@cms/ui`; the project's direct
 * dependencies are read from the `package.json` nearest `configDir`.
 */
export function uiPackageSources(configDir: string): string[] {
  const projectDir = findUp(configDir, "package.json");
  if (!projectDir) return [];
  const project = readPackageJson(projectDir);
  const names = Object.keys({ ...project.dependencies, ...project.devDependencies });

  return names.flatMap((name) => {
    if (CORE_PACKAGES.has(name)) return [];
    const installedIn = findUp(projectDir, join("node_modules", name, "package.json"));
    if (!installedIn) return [];
    const packageDir = realpathSync(join(installedIn, "node_modules", name));
    const manifest = readPackageJson(packageDir);
    const uses = { ...manifest.dependencies, ...manifest.peerDependencies };
    return UI_PEERS.some((peer) => peer in uses) ? [packageDir] : [];
  });
}
