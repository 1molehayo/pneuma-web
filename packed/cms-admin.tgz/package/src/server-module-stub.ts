import { readFile } from "node:fs/promises";
import { isBuiltin } from "node:module";
import { relative } from "node:path";
import type { Plugin } from "vite";
import { normalizePath, parseSync } from "vite";

// `*.server.ts` / `.server.js` (and the tsx/jsx/mts/mjs/cts/cjs variants),
// with or without a query string (`?v=hash` in dev).
const SERVER_MODULE_RE = /\.server\.[cm]?[jt]sx?(?:\?.*)?$/;

const displayPathOf = (id: string): string =>
  normalizePath(relative(process.cwd(), id.replace(/\?.*$/, "")));

// Same-exports stand-in for a server-only module: every export (functions and
// values alike) becomes a function that throws when called. The admin never
// calls hook or route handlers, so a stub only ever runs if browser code reaches
// for server code by mistake — and then it fails loudly, naming the module.
export function serverModuleStub(code: string, filename: string, displayPath: string): string {
  const { module, errors } = parseSync(filename, code);
  if (errors.length > 0) {
    throw new Error(`Could not parse server-only module ${displayPath}: ${errors[0]?.message}`);
  }
  // Export names come from static ESM syntax; `module.exports` can't be read.
  if (!module.hasModuleSyntax) {
    throw new Error(
      `Server-only module ${displayPath} is not an ES module, so the admin build cannot stub it. Write it with import/export.`,
    );
  }

  const names = new Set<string>();
  for (const entry of module.staticExports.flatMap((staticExport) => staticExport.entries)) {
    if (entry.isType) continue;
    if (entry.importName.kind === "AllButDefault") {
      throw new Error(
        `Server-only module ${displayPath} uses \`export * from "${entry.moduleRequest?.value}"\`, which the admin build cannot stub. List the re-exported names explicitly.`,
      );
    }
    if (entry.exportName.kind === "Default") names.add("default");
    if (entry.exportName.kind === "Name" && entry.exportName.name) {
      names.add(entry.exportName.name);
    }
  }

  const lines = [
    `const modulePath = ${JSON.stringify(displayPath)};`,
    "const serverOnly = (name) => function () {",
    '  throw new Error(JSON.stringify(name) + " from " + modulePath + " is server-only and was called in the browser.");',
    "};",
  ];
  // Export through a generated local under the quoted original name, so any
  // valid export name works: `default`, or a string such as `"foo-bar"`.
  for (const [index, name] of [...names].entries()) {
    const quotedName = JSON.stringify(name);
    lines.push(`const export${index} = serverOnly(${quotedName});`);
    lines.push(`export { export${index} as ${quotedName} };`);
  }
  return `${lines.join("\n")}\n`;
}

// Replaces every `*.server.*` module — a local file or a package's published
// `.server.js` — with its stub, so Node-only code imported by cms.config (DB
// drivers, SDKs, secrets) never reaches the admin bundle. Node loads the real
// module, so the engine is unaffected. Matches on the resolved file path, so it
// applies however the module was imported.
//
// It also fails the build when a project file outside a `.server` module
// imports a Node built-in that Vite would externalize for the browser — Vite
// only warns, so server code left in a plain file would otherwise ship silently.
// Packages in node_modules keep Vite's warning: many map built-ins to browser
// fallbacks, and a package's server code is expected to ship as `.server.js`.
export function serverModuleStubPlugin(): Plugin {
  return {
    name: "cms-server-module-stub",
    enforce: "pre",
    resolveId: {
      async handler(source, importer, options) {
        if (!importer || importer.includes("/node_modules/") || !isBuiltin(source)) return;
        // An installed polyfill (`events`, `buffer`) resolves to node_modules and
        // is fine; only Vite's browser-external placeholder means Node-only code.
        const resolved = await this.resolve(source, importer, { ...options, skipSelf: true });
        if (!resolved?.id.startsWith("__vite-browser-external")) return resolved;
        this.error(
          `"${source}" imported by ${displayPathOf(importer)} would reach the admin bundle. cms.config and everything it imports runs in the browser too: move Node-only code into a *.server.ts file.`,
        );
      },
    },
    load: {
      filter: { id: SERVER_MODULE_RE },
      async handler(id) {
        const filename = id.replace(/\?.*$/, "");
        const code = await readFile(filename, "utf8");
        return { code: serverModuleStub(code, filename, displayPathOf(id)), moduleType: "js" };
      },
    },
  };
}
