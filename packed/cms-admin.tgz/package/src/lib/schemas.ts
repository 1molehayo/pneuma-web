import z from "zod";

const apiKeySchema = z.object({
  id: z.string().uuid(),
  createdAt: z.string(),
  createdBy: z.string().nullable(),
  keyPrefix: z.string(),
  name: z.string(),
  revokedAt: z.string().nullable(),
  role: z.string(),
});

type ApiKey = z.infer<typeof apiKeySchema>;

const userSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  name: z.string(),
  role: z.string(),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
});

type User = z.infer<typeof userSchema>;

const documentSchema = z
  .object({
    _entity: z.string(),
    id: z.string(),
    createdAt: z.string(),
    updatedAt: z.string(),
    translationGroup: z.string().optional(),
    locale: z.string().optional(),
    _translations: z
      .record(z.string(), z.object({ id: z.string() }).catchall(z.unknown()))
      .optional(),
  })
  .catchall(z.unknown());

type Document = z.infer<typeof documentSchema>;

const translatableDocumentSchema = documentSchema.extend({
  locale: z.string(),
  translationGroup: z.string(),
  _translations: z.record(z.string(), z.object({ id: z.string() }).catchall(z.unknown())),
});

type TranslatableDocument = z.infer<typeof translatableDocumentSchema>;

/** What an entity list filters by: live documents, drafts, or (in a translation list) untranslated groups. */
export const listStatusSchema = z.enum(["live", "draft", "untranslated"]);

export type ListStatus = z.infer<typeof listStatusSchema>;

/** Per-locale presence + publish state, returned by the group-collapse list
 *  mode for the locale status pips. */
const localeStatusSchema = z.object({
  id: z.string(),
  status: listStatusSchema.exclude(["untranslated"]),
});

/** One entry per `translationGroup` from the group-collapse list endpoint
 *  (`?view=translations`). `row` is the active-locale row, or `null` for an
 *  untranslated placeholder. `locales` carries every sibling for the pips. */
const groupedDocumentSchema = z.object({
  translationGroup: z.string(),
  row: documentSchema.nullable(),
  // Representative sibling row used to label untranslated placeholders.
  fallback: documentSchema.nullable(),
  locales: z.record(z.string(), localeStatusSchema),
});

type GroupedDocument = z.infer<typeof groupedDocumentSchema>;

const imageAssetSchema = documentSchema.extend({
  _entity: z.literal("_image"),
  filename: z.string(),
  mimeType: z.string(),
  size: z.number().nullable(),
  width: z.number().nullable(),
  height: z.number().nullable(),
  alt: z.string().nullable(),
  tags: z.array(z.string()).nullable(),
  url: z.string(),
  private: z.boolean().nullable(),
});

type ImageAsset = z.infer<typeof imageAssetSchema>;

const videoAssetSchema = documentSchema.extend({
  _entity: z.literal("_video"),
  filename: z.string(),
  mimeType: z.string(),
  size: z.number().nullable(),
  width: z.number().nullable(),
  height: z.number().nullable(),
  tags: z.array(z.string()).nullable(),
  url: z.string(),
  private: z.boolean().nullable(),
});

type VideoAsset = z.infer<typeof videoAssetSchema>;

const fileAssetSchema = documentSchema.extend({
  _entity: z.literal("_file"),
  filename: z.string(),
  mimeType: z.string(),
  size: z.number().nullable(),
  tags: z.array(z.string()).nullable(),
  url: z.string(),
  private: z.boolean().nullable(),
});

type FileAsset = z.infer<typeof fileAssetSchema>;

// Entity name → specific schema. Falls back to documentSchema for unknown entities.
const entitySchemas = {
  _image: imageAssetSchema,
  _video: videoAssetSchema,
  _file: fileAssetSchema,
} as const;

type EntitySchemas = typeof entitySchemas;

type EntitySchema<K extends string> = K extends keyof EntitySchemas
  ? EntitySchemas[K]
  : typeof documentSchema;

function resolveEntitySchema<K extends string>(entityName: K): EntitySchema<K> {
  return ((entitySchemas as Record<string, unknown>)[entityName] ??
    documentSchema) as EntitySchema<K>;
}

type Asset = ImageAsset | VideoAsset | FileAsset;

export {
  apiKeySchema,
  documentSchema,
  fileAssetSchema,
  groupedDocumentSchema,
  imageAssetSchema,
  resolveEntitySchema,
  userSchema,
  videoAssetSchema,
};

type ResolvedEntity<K extends string> = z.infer<EntitySchema<K>>;

export type {
  ApiKey,
  Asset,
  Document,
  EntitySchema,
  FileAsset,
  GroupedDocument,
  ImageAsset,
  ResolvedEntity,
  TranslatableDocument,
  User,
  VideoAsset,
};
