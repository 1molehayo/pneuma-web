import { useConfig } from "./use-config";
import { useMe } from "./use-me";

/** Whether the signed-in role may read the audit log. Admins only: it spans every entity. */
const useCanReadAuditLog = () => {
  const config = useConfig();
  const { data: user } = useMe();
  const role = config.roles.find((candidate) => candidate.name === user?.role);
  return !!role?.isAdmin;
};

export { useCanReadAuditLog };
