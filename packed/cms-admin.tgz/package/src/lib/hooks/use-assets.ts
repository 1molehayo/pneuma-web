import type { RuntimeParams } from "@cms/client";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { getDocumentsQueryOptions } from "@/lib/queries/documents";
import type { Asset } from "@/lib/schemas";

type AssetType = "_image" | "_video" | "_file";

const useAssets = (types: AssetType[], params?: RuntimeParams) => {
  const images = useQuery({
    ...getDocumentsQueryOptions("_image", params),
    enabled: types.includes("_image"),
  });
  const videos = useQuery({
    ...getDocumentsQueryOptions("_video", params),
    enabled: types.includes("_video"),
  });
  const files = useQuery({
    ...getDocumentsQueryOptions("_file", params),
    enabled: types.includes("_file"),
  });

  const isPending = useMemo(() => {
    return (
      (types.includes("_image") && images.isPending) ||
      (types.includes("_video") && videos.isPending) ||
      (types.includes("_file") && files.isPending)
    );
  }, [types, images.isPending, videos.isPending, files.isPending]);

  const data = useMemo(() => {
    if (isPending) return [];

    let assets: Asset[] = [];

    if (types.includes("_image")) {
      assets = [...assets, ...(images.data || [])];
    }
    if (types.includes("_video")) {
      assets = [...assets, ...(videos.data || [])];
    }
    if (types.includes("_file")) {
      assets = [...assets, ...(files.data || [])];
    }

    return assets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [isPending, images.data, videos.data, files.data, types]);

  return {
    data,
    isPending,
  };
};

export { useAssets };
