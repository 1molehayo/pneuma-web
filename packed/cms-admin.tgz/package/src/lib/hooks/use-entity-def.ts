import { useMemo } from "react";
import { useConfig } from "./use-config";

const useEntityDef = (name: string) => {
  const { entities } = useConfig();

  const def = useMemo(() => {
    return entities.find((entity) => entity.name === name);
  }, [entities, name]);

  if (!def) {
    throw new Error(`Entity ${name} not found`);
  }

  return def;
};

export { useEntityDef };
