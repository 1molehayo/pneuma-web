import { useEffect, useRef, useState } from "react";

type DocumentIdentity = {
  id?: string;
  updatedAt?: string;
  _status?: string;
  pendingDraftVersionId?: string;
  _draftCreatedAt?: string;
};

/**
 * Key to remount `DocumentForm` on server-side content changes that it can't
 * reconcile on its own (restore, unpublish, discard, draft-overlay swap) —
 * `pendingDraftVersionId`/`_draftCreatedAt` cover restore-on-published, which
 * only moves the FK and doesn't bump `updatedAt`.
 *
 * A document's own save/publish also bumps `updatedAt`, but `DocumentForm`
 * already re-syncs `initialData` itself when not dirty, so remounting there
 * would only cost UI state (selected tab, open disclosures) for nothing.
 * Call `markOwnSave` from that mutation's `onSuccess` to skip the remount.
 */
export function useDocumentFormKey(document: DocumentIdentity | null | undefined) {
  const identity = `${document?.id ?? "new"}:${document?.updatedAt ?? ""}:${document?._status ?? ""}:${document?.pendingDraftVersionId ?? ""}:${document?._draftCreatedAt ?? ""}`;
  const [key, setKey] = useState(identity);
  const prevIdentityRef = useRef(identity);
  const skipNextRef = useRef(false);

  useEffect(() => {
    if (identity === prevIdentityRef.current) return;
    prevIdentityRef.current = identity;
    if (skipNextRef.current) {
      skipNextRef.current = false;
      return;
    }
    setKey(identity);
  }, [identity]);

  const markOwnSave = () => {
    skipNextRef.current = true;
  };

  return [key, markOwnSave] as const;
}
