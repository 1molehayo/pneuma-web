import { useMemo } from "react";
import { useConfig } from "./use-config";

const useGlobalDef = (name: string) => {
  const { entities } = useConfig();

  const def = useMemo(() => {
    return entities.find((e) => e.name === name && e.global);
  }, [entities, name]);

  if (!def) {
    throw new Error(`Global ${name} not found`);
  }

  return def;
};

export { useGlobalDef };
