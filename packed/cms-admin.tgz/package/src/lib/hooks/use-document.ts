import { useQuery } from "@tanstack/react-query";
import { getDocumentQueryOptions } from "@/lib/queries/document-queries";

const useDocument = (...params: Parameters<typeof getDocumentQueryOptions>) => {
  return useQuery(getDocumentQueryOptions(...params));
};

export { useDocument };
