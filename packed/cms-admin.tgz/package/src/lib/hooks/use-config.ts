import CMS_CONFIG from "virtual:cms-config";

const useConfig = () => {
  const config = CMS_CONFIG;

  return config;
};

export { useConfig };
