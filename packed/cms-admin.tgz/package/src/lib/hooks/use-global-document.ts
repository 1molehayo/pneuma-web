import { useQuery } from "@tanstack/react-query";
import { getGlobalDocumentQueryOptions } from "@/lib/queries/documents";

const useGlobalDocument = (...params: Parameters<typeof getGlobalDocumentQueryOptions>) => {
  return useQuery(getGlobalDocumentQueryOptions(...params));
};

export { useGlobalDocument };
