import { useConfig } from "./use-config";
import { useMe } from "./use-me";

/** Whether the signed-in role may run the unused-asset cleanup. Admins always may. */
const useCanCleanUpAssets = () => {
  const config = useConfig();
  const { data: user } = useMe();
  const role = config.roles.find((candidate) => candidate.name === user?.role);
  return !!role && (role.isAdmin || !!role.assets?.cleanup);
};

export { useCanCleanUpAssets };
