import type { PermissionRule } from "@cms/config";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { getMeQueryOptions } from "@/lib/queries/me";
import { useConfig } from "./use-config";

function getExcluded(rule: PermissionRule | undefined): string[] {
  if (!rule || typeof rule === "boolean") return [];
  return rule.fields?.exclude ?? [];
}

const useFieldPermissions = (
  entityName: string,
  op: "create" | "update",
): { hiddenFields: Set<string>; readOnlyFields: Set<string> } => {
  const config = useConfig();
  const { data: user } = useQuery(getMeQueryOptions());

  return useMemo(() => {
    const empty = { hiddenFields: new Set<string>(), readOnlyFields: new Set<string>() };
    if (!user) return empty;

    const role = config.roles.find((r) => r.name === user.role);
    if (!role || role.isAdmin) return empty;

    const entityPerms = role.permissions[entityName];
    if (!entityPerms) return empty;

    const hiddenFields = new Set(getExcluded(entityPerms.read));
    const opExcluded = getExcluded(entityPerms[op]);
    const readOnlyFields = new Set(opExcluded.filter((field) => !hiddenFields.has(field)));

    return { hiddenFields, readOnlyFields };
  }, [config.roles, user, entityName, op]);
};

export { useFieldPermissions };
