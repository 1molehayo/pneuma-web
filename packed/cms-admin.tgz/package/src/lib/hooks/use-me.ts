import { useQuery } from "@tanstack/react-query";
import { getMeQueryOptions } from "@/lib/queries/me";

const useMe = () => {
  return useQuery(getMeQueryOptions());
};

export { useMe };
