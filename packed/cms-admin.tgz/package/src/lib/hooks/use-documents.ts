import { useQuery } from "@tanstack/react-query";
import { getDocumentsQueryOptions } from "@/lib/queries/document-queries";

const useDocuments = (...params: Parameters<typeof getDocumentsQueryOptions>) => {
  return useQuery(getDocumentsQueryOptions(...params));
};

export { useDocuments };
