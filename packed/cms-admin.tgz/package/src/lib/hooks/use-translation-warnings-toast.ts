import { toast } from "@cms/ui";
import { useEffect, useRef } from "react";

/**
 * Toast, once, the relations a prepared translation couldn't point at a counterpart in its
 * locale: they still point at the source locale's documents.
 */
export function useTranslationWarningsToast(warnings: string[]) {
  const shown = useRef(false);
  useEffect(() => {
    if (shown.current || warnings.length === 0) return;
    shown.current = true;
    const title =
      warnings.length === 1
        ? "1 relation could not be translated"
        : `${warnings.length} relations could not be translated`;
    toast({ title, description: warnings.join("\n") });
  }, [warnings]);
}
