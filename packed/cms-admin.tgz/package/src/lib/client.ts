import { ClientError, createClient } from "@cms/client";
import type { Asset } from "./schemas";

export const API_BASE_URL = "/api";

/**
 * Marks every admin GET with `_admin=1`, which the engine ignores. A CDN keys its cache on the URL
 * alone, so an admin read could otherwise be answered from a copy it cached for a site's
 * anonymous read of the same URL: the published view, up to the cache window old.
 */
export function markAdminReads(fetchFn: typeof fetch): typeof fetch {
  return (input, init) => {
    if ((init?.method ?? "GET").toUpperCase() !== "GET" || input instanceof Request) {
      return fetchFn(input, init);
    }
    const url = new URL(String(input), globalThis.location?.origin);
    url.searchParams.set("_admin", "1");
    return fetchFn(url, init);
  };
}

export const client = createClient({
  url: "",
  credentials: "include",
  fetch: markAdminReads((input, init) => fetch(input, init)),
});

export const uploadAsset = async (file: File): Promise<Asset> => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${API_BASE_URL}/assets/upload`, {
    method: "POST",
    body: formData,
    credentials: "include",
  });

  if (!response.ok) {
    // Same error shape as every other API call, so the status (413 vs 500) and the request id
    // reach the UI and error reporting.
    const body = (await response.json().catch(() => null)) as {
      error?: ConstructorParameters<typeof ClientError>[1];
    } | null;
    throw new ClientError(
      response.status,
      body?.error ?? { code: "INTERNAL_ERROR", message: `Upload failed: ${response.statusText}` },
      response.headers.get("x-request-id") ?? undefined,
    );
  }

  const json = (await response.json()) as { data: Asset };
  return json.data;
};
