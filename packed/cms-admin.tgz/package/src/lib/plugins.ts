import CMS_CONFIG from "virtual:cms-config";
import { PLUGIN_DATA_WINDOW_KEY } from "@cms/client";
import { createPluginReporting } from "./error-reporting";

/** What the engine's plugins handed over in `/admin/runtime-env.js`, keyed by instance name. */
const data = (typeof window === "undefined" ? undefined : window[PLUGIN_DATA_WINDOW_KEY]) ?? {};

export const { reportError, setReportedUser } = createPluginReporting(CMS_CONFIG.plugins, data);
