/** A path into version data: object keys and array positions (0-based). */
export type DiffPath = ReadonlyArray<string | number>;

/**
 * One difference between two versions' data. Array items are compared by position, so an item
 * that only shifted because another was added or removed before it is not reported.
 */
export type VersionChange =
  /** A value edited in place. Either side may be `undefined` (a field set for the first time, or cleared). */
  | { kind: "edited"; path: DiffPath; before: unknown; after: unknown }
  /** An array item that is new. `path` ends on its position in the newer version. */
  | { kind: "added"; path: DiffPath; value: unknown }
  /** An array item that is gone. `path` ends on its position in the older version. */
  | { kind: "removed"; path: DiffPath; value: unknown }
  /** An unchanged array item at another position. `path` is the array's. */
  | { kind: "moved"; path: DiffPath; from: number; to: number; value: unknown }
  /** A block whose `_type` changed: a different block, not an edit of the same one. */
  | {
      kind: "replaced";
      path: DiffPath;
      before: unknown;
      after: unknown;
      beforeType: string;
      afterType: string;
    };

export type DiffOptions = {
  /** Paths compared as a whole, without descending (e.g. one rich-text block). */
  isAtomic?: (path: DiffPath) => boolean;
};

type PlainObject = Record<string, unknown>;

const isPlainObject = (value: unknown): value is PlainObject =>
  typeof value === "object" && value !== null && !Array.isArray(value);

/** `null`, `undefined` and `""` all read as "no value". */
const isEmpty = (value: unknown) => value === null || value === undefined || value === "";

const deepEqual = (left: unknown, right: unknown): boolean => {
  if (left === right) return true;
  if (isEmpty(left) && isEmpty(right)) return true;
  if (Array.isArray(left) && Array.isArray(right)) {
    return (
      left.length === right.length && left.every((item, index) => deepEqual(item, right[index]))
    );
  }
  if (isPlainObject(left) && isPlainObject(right)) {
    const keys = new Set([...Object.keys(left), ...Object.keys(right)]);
    return [...keys].every((key) => deepEqual(left[key], right[key]));
  }
  return false;
};

const blockType = (value: unknown): string | null =>
  isPlainObject(value) && typeof value._type === "string" ? value._type : null;

/** Index pairs `[before, after]` of the longest run of equal items kept in order. */
const longestCommonItems = (before: unknown[], after: unknown[]): Array<[number, number]> => {
  // `lengths` is a flat (before + 1) × (after + 1) table: the common run from each pair onwards.
  const width = after.length + 1;
  const lengths = new Array<number>((before.length + 1) * width).fill(0);
  const lengthAt = (beforeIndex: number, afterIndex: number) =>
    lengths[beforeIndex * width + afterIndex] ?? 0;
  for (let beforeIndex = before.length - 1; beforeIndex >= 0; beforeIndex--) {
    for (let afterIndex = after.length - 1; afterIndex >= 0; afterIndex--) {
      lengths[beforeIndex * width + afterIndex] = deepEqual(before[beforeIndex], after[afterIndex])
        ? lengthAt(beforeIndex + 1, afterIndex + 1) + 1
        : Math.max(lengthAt(beforeIndex + 1, afterIndex), lengthAt(beforeIndex, afterIndex + 1));
    }
  }
  const pairs: Array<[number, number]> = [];
  let beforeIndex = 0;
  let afterIndex = 0;
  while (beforeIndex < before.length && afterIndex < after.length) {
    if (deepEqual(before[beforeIndex], after[afterIndex])) {
      pairs.push([beforeIndex, afterIndex]);
      beforeIndex++;
      afterIndex++;
    } else if (lengthAt(beforeIndex + 1, afterIndex) >= lengthAt(beforeIndex, afterIndex + 1)) {
      beforeIndex++;
    } else {
      afterIndex++;
    }
  }
  return pairs;
};

/** Above this many item comparisons, an array's changed range is compared by position instead. */
const MAX_ARRAY_COMPARISONS = 250_000;

const diffArray = (
  before: unknown[],
  after: unknown[],
  path: DiffPath,
  options: DiffOptions,
): VersionChange[] => {
  // Equal items at either end are unchanged; only the range between them needs matching.
  let start = 0;
  while (start < before.length && start < after.length && deepEqual(before[start], after[start])) {
    start++;
  }
  let beforeEnd = before.length;
  let afterEnd = after.length;
  while (
    beforeEnd > start &&
    afterEnd > start &&
    deepEqual(before[beforeEnd - 1], after[afterEnd - 1])
  ) {
    beforeEnd--;
    afterEnd--;
  }

  const changes: VersionChange[] = [];
  const pairUp = (beforeIndexes: number[], afterIndexes: number[]) => {
    const paired = Math.min(beforeIndexes.length, afterIndexes.length);
    beforeIndexes.slice(0, paired).forEach((beforeIndex, offset) => {
      const afterIndex = afterIndexes[offset] ?? beforeIndex;
      changes.push(
        ...diffValue(before[beforeIndex], after[afterIndex], [...path, afterIndex], options),
      );
    });
    for (const beforeIndex of beforeIndexes.slice(paired)) {
      changes.push({ kind: "removed", path: [...path, beforeIndex], value: before[beforeIndex] });
    }
    for (const afterIndex of afterIndexes.slice(paired)) {
      changes.push({ kind: "added", path: [...path, afterIndex], value: after[afterIndex] });
    }
  };
  const range = (from: number, to: number) =>
    Array.from({ length: to - from }, (_, offset) => from + offset);

  // Too large to match item by item (and to look for moves) without stalling the page.
  if ((beforeEnd - start) * (afterEnd - start) > MAX_ARRAY_COMPARISONS) {
    pairUp(range(start, beforeEnd), range(start, afterEnd));
    return changes;
  }

  const kept = longestCommonItems(before.slice(start, beforeEnd), after.slice(start, afterEnd)).map(
    ([beforeIndex, afterIndex]): [number, number] => [beforeIndex + start, afterIndex + start],
  );
  const unmatchedBefore = new Set(range(start, beforeEnd));
  const unmatchedAfter = new Set(range(start, afterEnd));
  for (const [beforeIndex, afterIndex] of kept) {
    unmatchedBefore.delete(beforeIndex);
    unmatchedAfter.delete(afterIndex);
  }

  // An item out of order but otherwise unchanged moved.
  for (const afterIndex of [...unmatchedAfter]) {
    const beforeIndex = [...unmatchedBefore].find((candidate) =>
      deepEqual(before[candidate], after[afterIndex]),
    );
    if (beforeIndex === undefined) continue;
    unmatchedBefore.delete(beforeIndex);
    unmatchedAfter.delete(afterIndex);
    changes.push({
      kind: "moved",
      path,
      from: beforeIndex,
      to: afterIndex,
      value: after[afterIndex],
    });
  }

  // Between two kept items, the leftovers pair up in order (an edit); the surplus was added or removed.
  const anchors: Array<[number, number]> = [...kept, [beforeEnd, afterEnd]];
  let previousBefore = start - 1;
  let previousAfter = start - 1;
  for (const [anchorBefore, anchorAfter] of anchors) {
    pairUp(
      [...unmatchedBefore].filter((index) => index > previousBefore && index < anchorBefore),
      [...unmatchedAfter].filter((index) => index > previousAfter && index < anchorAfter),
    );
    previousBefore = anchorBefore;
    previousAfter = anchorAfter;
  }
  return changes;
};

/**
 * Keys a migration renamed: one only `before` has and one only `after` has, holding the same
 * value. Migrations reshape the live row and its pending draft but leave older versions as they
 * were stored, so without this a renamed key reads as one field cleared and another set.
 */
const renamedKeys = (before: PlainObject, after: PlainObject): Set<string> => {
  const onlyAfter = Object.keys(after).filter((key) => !(key in before) && !isEmpty(after[key]));
  const renamed = new Set<string>();
  for (const key of Object.keys(before)) {
    if (key in after || isEmpty(before[key])) continue;
    const match = onlyAfter.find(
      (candidate) => !renamed.has(candidate) && deepEqual(before[key], after[candidate]),
    );
    if (match === undefined) continue;
    renamed.add(key);
    renamed.add(match);
  }
  return renamed;
};

const diffValue = (
  before: unknown,
  after: unknown,
  path: DiffPath,
  options: DiffOptions,
): VersionChange[] => {
  if (deepEqual(before, after)) return [];
  if (options.isAtomic?.(path)) return [{ kind: "edited", path, before, after }];

  const beforeType = blockType(before);
  const afterType = blockType(after);
  if (beforeType && afterType && beforeType !== afterType) {
    return [{ kind: "replaced", path, before, after, beforeType, afterType }];
  }

  const beforeIsArray = Array.isArray(before) || isEmpty(before);
  const afterIsArray = Array.isArray(after) || isEmpty(after);
  if ((Array.isArray(before) || Array.isArray(after)) && beforeIsArray && afterIsArray) {
    return diffArray(
      Array.isArray(before) ? before : [],
      Array.isArray(after) ? after : [],
      path,
      options,
    );
  }

  if (isPlainObject(before) && isPlainObject(after)) {
    const renamed = renamedKeys(before, after);
    const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
    return [...keys]
      .filter((key) => !renamed.has(key))
      .flatMap((key) => diffValue(before[key], after[key], [...path, key], options));
  }

  return [{ kind: "edited", path, before, after }];
};

/**
 * What changed between two versions' data, field by field. Arrays (blocks, rich text, multi
 * relations) report added, removed and moved items; everything else, edited leaf values.
 */
export const diffVersionData = (
  before: Record<string, unknown>,
  after: Record<string, unknown>,
  options: DiffOptions = {},
): VersionChange[] => diffValue(before, after, [], options);

const MAX_VALUE_LENGTH = 120;

const truncate = (text: string) =>
  text.length > MAX_VALUE_LENGTH ? `${text.slice(0, MAX_VALUE_LENGTH - 1)}…` : text;

/** The text of a rich-text block: its spans joined. */
const blockText = (value: PlainObject): string | null => {
  if (!Array.isArray(value.children)) return null;
  return value.children
    .map((child) => (isPlainObject(child) && typeof child.text === "string" ? child.text : ""))
    .join("");
};

/** A readable form of a version value, whole. */
const readableValue = (value: unknown): string => {
  if (isEmpty(value)) return "—";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) {
    if (value.length === 0) return "—";
    return value.map(readableValue).join(", ");
  }
  if (isPlainObject(value)) {
    // A multi-relation ref: `{ id, _entity }`.
    if (typeof value.id === "string" && typeof value._entity === "string") return value.id;
    const text = blockText(value);
    if (text !== null) return text || "—";
    const type = blockType(value);
    if (type) return type;
  }
  return JSON.stringify(value);
};

/** A short, readable form of a version value for a diff line. */
export const formatDiffValue = (value: unknown): string => truncate(readableValue(value));

const EXCERPT_CONTEXT = 40;

/** Both texts cut to where they differ, with up to `EXCERPT_CONTEXT` characters either side. */
const excerptAroundChange = (before: string, after: string) => {
  if (before.length <= MAX_VALUE_LENGTH && after.length <= MAX_VALUE_LENGTH) {
    return { before, after };
  }
  let prefix = 0;
  while (prefix < before.length && before[prefix] === after[prefix]) prefix++;
  let suffix = 0;
  while (
    suffix < before.length - prefix &&
    suffix < after.length - prefix &&
    before[before.length - 1 - suffix] === after[after.length - 1 - suffix]
  ) {
    suffix++;
  }
  const excerpt = (text: string) => {
    const start = Math.max(0, prefix - EXCERPT_CONTEXT);
    const end = Math.min(text.length, text.length - suffix + EXCERPT_CONTEXT);
    return truncate(
      `${start > 0 ? "…" : ""}${text.slice(start, end)}${end < text.length ? "…" : ""}`,
    );
  };
  return { before: excerpt(before), after: excerpt(after) };
};

/**
 * The two sides of an edited value, cut to the part that changed. When their readable forms match
 * (a rich-text link or mark, a block's other fields), the stored JSON shows what did.
 */
export const formatEdit = (before: unknown, after: unknown) => {
  const readableBefore = readableValue(before);
  const readableAfter = readableValue(after);
  return readableBefore === readableAfter
    ? excerptAroundChange(JSON.stringify(before ?? null), JSON.stringify(after ?? null))
    : excerptAroundChange(readableBefore, readableAfter);
};
