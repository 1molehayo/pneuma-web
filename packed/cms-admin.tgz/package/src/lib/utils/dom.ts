// prevents click on element when clicking on interactive elements inside it
export const withClickGuard = <T extends React.MouseEvent>(handler: (e: T) => void) => {
  const CLICKABLE_ELEMENTS = ["a", "button", "input", "select", "textarea", "[popover]"];

  return (e: T) => {
    const target = e.target as HTMLElement;

    if (target.querySelector("[popover]")) {
      return;
    }

    if (CLICKABLE_ELEMENTS.some((tag) => target.closest(tag))) {
      return;
    }

    handler(e);
  };
};
