import CMS_CONFIG from "virtual:cms-config";
import type { Entity, EntityTitle } from "@cms/config";

export const isInternalEntity = (entity: Entity): boolean => {
  return entity.name.startsWith("_");
};

export const isGlobalEntity = (entity: Entity): boolean => {
  return !!entity.global;
};

export const getEntitySummaryFields = (entity: Entity): string[] => {
  return [...(entity.admin?.summary?.fields || [])];
};

const resolveTitle = (
  title: EntityTitle | undefined,
  fallback: string,
  plural?: boolean,
): string => {
  if (!title) return fallback;
  if (typeof title === "string") return title;
  return plural ? title.plural : title.singular;
};

export const getEntityTitle = (entity: Entity, opts?: { plural?: boolean }): string =>
  resolveTitle(entity.title, entity.name, opts?.plural);

export const resolveEntityTitle = (entityName: string, opts?: { plural?: boolean }): string => {
  const entity = CMS_CONFIG.entities.find((e) => e.name === entityName);
  return resolveTitle(entity?.title, entityName, opts?.plural);
};
