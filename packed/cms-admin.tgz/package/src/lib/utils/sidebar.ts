import type {
  AdminRouteDef,
  CmsConfig,
  DashboardWidgetDef,
  DocumentBannerDef,
  RoleDef,
  SidebarElement,
  SidebarItem,
} from "@cms/config";

// Kept free of `virtual:cms-config` so it can be unit-tested: callers pass the config in.

type PageLocation = { plugin?: string; path: string };

/** The project's page at `path`, or the named plugin's. */
export const findAdminPage = (
  config: CmsConfig,
  { plugin, path }: PageLocation,
): AdminRouteDef | undefined => {
  const pages = plugin
    ? config.plugins.find((candidate) => candidate.name === plugin)?.admin?.routes
    : config.admin?.routes;
  return pages?.find((page) => page.path === path);
};

/**
 * Same rule as server routes: admins always, other roles only when listed. Also decides who sees
 * a document banner or a dashboard widget.
 */
export const canOpenPage = (
  page: AdminRouteDef | DocumentBannerDef | DashboardWidgetDef,
  role: RoleDef,
): boolean => role.isAdmin || (page.roles ?? []).includes(role.name);

export const adminPagePath = ({ plugin, path }: PageLocation): string =>
  plugin ? `/plugins/${plugin}/${path}` : `/custom/${path}`;

const BUILTINS = new Set(["_dashboard", "_assets"]);

const isItemVisible = (item: SidebarItem, role: RoleDef): boolean => {
  if (BUILTINS.has(item.name)) return true;
  const readRule = role.permissions[item.name]?.read;
  return readRule !== false && readRule !== undefined;
};

/** Drops what `role` can't open, then the groups left empty and any stray dividers. */
export const filterSidebar = (
  elements: readonly SidebarElement[],
  role: RoleDef,
  config: CmsConfig,
): SidebarElement[] => {
  const filtered = elements.flatMap((element): SidebarElement[] => {
    if (element.type === "divider") return [element];
    if (element.type === "item") return isItemVisible(element, role) ? [element] : [];
    if (element.type === "page") {
      const page = findAdminPage(config, element);
      return page && canOpenPage(page, role) ? [element] : [];
    }
    const children = filterSidebar(element.children, role, config);
    if (children.length === 0) return [];
    return [{ ...element, children }];
  });

  // Remove leading, trailing, and consecutive dividers
  const result: SidebarElement[] = [];
  for (const element of filtered) {
    if (element.type === "divider") {
      const last = result[result.length - 1];
      if (!last || last.type === "divider") continue;
      result.push(element);
    } else {
      result.push(element);
    }
  }
  const last = result[result.length - 1];
  if (last?.type === "divider") result.pop();
  return result;
};
