import { type AnyField, flattenFields, type LayoutDirective } from "@cms/config";
import type { DiffPath, VersionChange } from "./version-diff";

type FieldList = ReadonlyArray<AnyField | LayoutDirective>;

/** A changed-field path: as stored in the audit log (`content.2.title`), or as segments. */
type FieldPath = string | DiffPath;

/** One segment of a changed-field path, read against the entity's fields. */
type FieldPathStep =
  | { kind: "field"; label: string; field: AnyField }
  /** An array item or rich-text block, by its 0-based position. */
  | { kind: "index"; label: string; index: number; parent: AnyField }
  /** A segment the fields don't describe (a removed field, rich-text internals): shown as stored. */
  | { kind: "raw"; label: string };

const fieldLabel = (field: AnyField) => field.title ?? field.name;

const parseIndex = (segment: string | number): number | null => {
  if (typeof segment === "number") return segment;
  return /^\d+$/.test(segment) ? Number(segment) : null;
};

/** The fields an item of this field addresses by name, or null when it has none (a leaf). */
const childFields = (field: AnyField): FieldList | null => {
  if (field.type === "object") return field.fields;
  // A union's path goes straight to the variant's field: `_type` lives in the data, not the path.
  if (field.type === "union") return field.of.flatMap((variant) => variant.fields);
  return null;
};

const raw = (segments: DiffPath): FieldPathStep[] =>
  segments.map((segment) => ({ kind: "raw", label: String(segment) }));

/**
 * An array item's label: its 1-based position, led by its block type (`Hero (3)`) when the item is
 * a union's and the next segment names a field only one variant has.
 */
const itemLabel = (item: AnyField, index: number, next: string | number | undefined) => {
  const position = String(index + 1);
  if (item.type !== "union" || next === undefined) return position;
  const variants = item.of.filter((variant) =>
    flattenFields(variant.fields).some((child) => child.name === String(next)),
  );
  const [variant] = variants;
  return variants.length === 1 && variant ? `${fieldLabel(variant)} (${position})` : position;
};

/** Walk the segments below `field`: an array or rich text takes an index, an object or union a name. */
const walkInto = (field: AnyField, segments: DiffPath): FieldPathStep[] => {
  const [head, ...rest] = segments;
  if (head === undefined) return [];

  if (field.type === "array" || field.type === "richText") {
    const index = parseIndex(head);
    if (index === null) return raw(segments);
    // Inside a rich-text block the path is the editor's own structure: shown as stored.
    if (field.type === "richText") {
      return [{ kind: "index", label: String(index + 1), index, parent: field }, ...raw(rest)];
    }
    const step: FieldPathStep = {
      kind: "index",
      label: itemLabel(field.of, index, rest[0]),
      index,
      parent: field,
    };
    // An array item doesn't carry its `of` field's name: descend into it in place.
    return [step, ...walkInto(field.of, rest)];
  }

  const fields = childFields(field);
  if (!fields) return raw(segments);
  return walkFields(fields, segments);
};

const walkFields = (fields: FieldList, segments: DiffPath) => {
  const [head, ...rest] = segments;
  if (head === undefined) return [];
  const field = flattenFields(fields).find((candidate) => candidate.name === String(head));
  if (!field) return raw(segments);
  return [{ kind: "field", label: fieldLabel(field), field } as const, ...walkInto(field, rest)];
};

/** Splits a stored dot path (`content.2.title`) into segments; an array path passes through. */
const toSegments = (path: FieldPath) => (typeof path === "string" ? path.split(".") : path);

/**
 * Reads a changed-field path against the entity's fields: each name becomes the field's title,
 * each array or rich-text index its 1-based position. What the fields don't describe stays raw.
 */
const walkFieldPath = (fields: FieldList, path: FieldPath): FieldPathStep[] =>
  walkFields(fields, toSegments(path));

/** `content.2.heading` → `Content › Hero (3) › Heading`. */
export const formatFieldPath = (fields: FieldList, path: FieldPath): string =>
  walkFieldPath(fields, path)
    .map((step) => step.label)
    .join(" › ");

type VisibilityUser = Parameters<NonNullable<NonNullable<AnyField["admin"]>["visible"]>>[0]["user"];

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null;

/**
 * Whether a field on the path is hidden by its `admin.visible` in `data`, asked level by level
 * with the object holding it, as the form asks it.
 */
const isHiddenFieldPath = (
  fields: FieldList,
  path: FieldPath,
  data: Record<string, unknown>,
  user: VisibilityUser,
): boolean => {
  const segments = toSegments(path);
  let value: unknown = data;
  // Each step reads one segment, so a step's index is its segment's.
  return walkFieldPath(fields, segments).some((step, index) => {
    const parent = value;
    value = isRecord(parent) ? parent[String(segments[index])] : undefined;
    if (step.kind !== "field" || !isRecord(parent) || Array.isArray(parent)) return false;
    return step.field.admin?.visible?.({ value, data: parent, user }) === false;
  });
};

/**
 * The changes the form would show: one to a field hidden in both versions (a value the server
 * maintains, like a synced block pointer's `group`) is left out. The versions still store it.
 */
export const visibleChanges = (
  fields: FieldList,
  changes: VersionChange[],
  versions: { before: Record<string, unknown>; after: Record<string, unknown> },
  user: VisibilityUser,
): VersionChange[] =>
  changes.filter(
    (change) =>
      !isHiddenFieldPath(fields, change.path, versions.before, user) ||
      !isHiddenFieldPath(fields, change.path, versions.after, user),
  );

/** Whether the path ends on one rich-text block (`body.4`): a diff shows it whole, as text. */
export const isRichTextBlockPath = (fields: FieldList, path: FieldPath): boolean => {
  const steps = walkFieldPath(fields, path);
  const last = steps.at(-1);
  return last?.kind === "index" && last.parent.type === "richText";
};
