import CMS_CONFIG from "virtual:cms-config";
import { getSearchFieldPaths } from "@cms/config";
import type { Document, TranslatableDocument } from "@/lib/schemas";
import { getDocumentMeta } from "./document-meta";

export { AUTO_TITLE_FIELDS, getAutoTitleFields } from "./document-meta";

/**
 * A list filter matching `query` against the entity's search fields
 * (`getSearchFieldPaths`; nested ones as dotted keys), or `undefined` when the
 * query is blank or the entity has none. Shared by the entity list and
 * relation pickers.
 */
export const buildSearchFilter = (
  entity: (typeof CMS_CONFIG.entities)[number],
  query: string | undefined,
) => {
  const term = query?.trim();
  if (!term) return undefined;
  const paths = getSearchFieldPaths(entity.fields);
  if (paths.length === 0) return undefined;
  return { $or: paths.map((path) => ({ [path.join(".")]: { $contains: term } })) };
};

export const isDocumentTranslatable = (document: Document): document is TranslatableDocument => {
  return "locale" in document && "_translations" in document;
};

const resolveDocumentMeta = (entityName: string, document: Record<string, unknown>) => {
  const entityDef = CMS_CONFIG.entities.find((entity) => entity.name === entityName);

  if (!entityDef) {
    throw new Error(`Entity ${entityName} not found in CMS config`);
  }

  return getDocumentMeta(entityDef, document);
};

export { resolveDocumentMeta };
