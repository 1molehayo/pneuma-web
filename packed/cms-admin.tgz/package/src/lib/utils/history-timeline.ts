type TimelineAuditEntry = { id: string; createdAt: string; versionId: string | null };
type TimelineVersion = { id: string; createdAt: string };

export type HistoryRow<TEntry extends TimelineAuditEntry, TVersion extends TimelineVersion> =
  /** An audit entry, with the version its write created when that version still exists. */
  | { kind: "audit"; id: string; createdAt: string; entry: TEntry; version: TVersion | null }
  /** A version no audit entry points at: older than the audit retention, or saved before it. */
  | { kind: "version"; id: string; createdAt: string; version: TVersion };

/**
 * One document's history, newest first: audit entries are the rows, and each picks up the version
 * its write created; versions no entry links to get a row of their own.
 */
export const buildHistoryTimeline = <
  TEntry extends TimelineAuditEntry,
  TVersion extends TimelineVersion,
>(
  entries: ReadonlyArray<TEntry>,
  versions: ReadonlyArray<TVersion>,
): Array<HistoryRow<TEntry, TVersion>> => {
  const versionsById = new Map(versions.map((version) => [version.id, version]));
  const linkedVersionIds = new Set(entries.map((entry) => entry.versionId));

  const rows: Array<HistoryRow<TEntry, TVersion>> = [
    ...entries.map((entry) => ({
      kind: "audit" as const,
      id: `audit:${entry.id}`,
      createdAt: entry.createdAt,
      entry,
      version: (entry.versionId && versionsById.get(entry.versionId)) || null,
    })),
    ...versions
      .filter((version) => !linkedVersionIds.has(version.id))
      .map((version) => ({
        kind: "version" as const,
        id: `version:${version.id}`,
        createdAt: version.createdAt,
        version,
      })),
  ];
  return rows.sort(
    (left, right) => new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime(),
  );
};

/**
 * The version a version is diffed against: the next older one. `versions` is newest first, as the
 * versions endpoint returns it. `null` for the oldest: it is the initial version.
 */
export const previousVersion = <TVersion extends TimelineVersion>(
  versions: ReadonlyArray<TVersion>,
  versionId: string,
): TVersion | null => {
  const index = versions.findIndex((version) => version.id === versionId);
  if (index === -1) return null;
  return versions[index + 1] ?? null;
};
