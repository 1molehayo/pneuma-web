import CMS_CONFIG from "virtual:cms-config";
import type { AnyField, LayoutDirective } from "@cms/config";
import { flattenFields } from "@cms/config";

const locales = CMS_CONFIG.i18n.locales || [];

export const getLocaleLabel = (locale: string) => {
  return locales.find((l) => l.value === locale)?.label || locale;
};

const localeListFormat = new Intl.ListFormat("en", { type: "conjunction" });

/** Locale labels in config order, as prose: "English, French, and Portuguese". */
export const formatLocaleList = (localeValues: readonly string[]) => {
  const order = locales.map((locale) => locale.value);
  const sorted = [...localeValues].sort((a, b) => order.indexOf(a) - order.indexOf(b));
  return localeListFormat.format(sorted.map(getLocaleLabel));
};

/**
 * A translation's form data without the shared fields the role can't read. The form never shows
 * them but seeds their defaults, which would overwrite the source's value in every locale; left
 * out, the engine fills them from the source.
 */
export const withoutHiddenSharedFields = (
  formData: Record<string, unknown>,
  fields: ReadonlyArray<AnyField | LayoutDirective>,
  hiddenFields: ReadonlySet<string>,
) => {
  const next = { ...formData };
  for (const field of flattenFields(fields)) {
    if (field.shared && hiddenFields.has(field.name)) delete next[field.name];
  }
  return next;
};
