export function getNestedErrors(
  errors: Record<string, string>,
  prefix: string,
): Record<string, string> {
  const result: Record<string, string> = {};
  const p = `${prefix}.`;
  for (const key in errors) {
    if (key.startsWith(p) && errors[key]) {
      result[key.slice(p.length)] = errors[key];
    }
  }
  return result;
}
