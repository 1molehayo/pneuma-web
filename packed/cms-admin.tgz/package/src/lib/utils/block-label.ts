import {
  type AnyField,
  flattenFields,
  type LayoutDirective,
  type ObjectAdminOptions,
} from "@cms/config";
import type { ReactNode } from "react";

type FieldList = ReadonlyArray<AnyField | LayoutDirective>;

type PreviewableBlock = {
  name: string;
  title?: string;
  previewField?: string;
  fields?: FieldList;
  admin?: ObjectAdminOptions<readonly AnyField[]>;
};

/** A relation's stored value: the target document's id and entity. */
type RelationRef = { id: string; _entity: string };

/** Follows a dotted `previewField` path (`product.title`) into the row's data, one segment at a time. */
const readPath = (data: unknown, path: string): unknown =>
  path.split(".").reduce<unknown>((value, segment) => {
    if (typeof value !== "object" || value === null) return undefined;
    return (value as Record<string, unknown>)[segment];
  }, data);

/** The field a path names, descending through object fields; null when a segment names none. */
const findField = (fields: FieldList, segments: string[]): AnyField | null => {
  const [head, ...rest] = segments;
  const field = flattenFields(fields).find((candidate) => candidate.name === head);
  if (!field || rest.length === 0) return field ?? null;
  return field.type === "object" ? findField(field.fields, rest) : null;
};

const isRelationRef = (value: unknown): value is RelationRef =>
  typeof value === "object" &&
  value !== null &&
  typeof (value as RelationRef).id === "string" &&
  typeof (value as RelationRef)._entity === "string";

/** The field path whose value names the row: a string `admin.summary.title`, else the deprecated `previewField`. */
const getTitlePath = (block: PreviewableBlock): string | undefined => {
  const title = block.admin?.summary?.title;
  if (typeof title === "function") return undefined;
  return title ?? block.previewField;
};

/** The single relation the title path points at, whose target document names the row; null otherwise. */
export function getPreviewRelation(block: PreviewableBlock, data: unknown): RelationRef | null {
  const path = getTitlePath(block);
  if (!path || !block.fields) return null;
  const field = findField(block.fields, path.split("."));
  if (field?.type !== "relation" || field.multiple) return null;
  const value = readPath(data, path);
  return isRelationRef(value) ? value : null;
}

/** The title path's value as text (a select's option label in place of its stored value); null while empty. */
export function getPreviewValue(block: PreviewableBlock, data: unknown): string | null {
  const path = getTitlePath(block);
  if (!path) return null;
  const value = readPath(data, path);
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (typeof value !== "string" || value.trim() === "") return null;

  const field = block.fields ? findField(block.fields, path.split(".")) : null;
  if (field?.type !== "select") return value;
  const option = field.options.find(
    (candidate) => (typeof candidate === "string" ? candidate : candidate.value) === value,
  );
  return typeof option === "object" ? option.label : value;
}

/** Resolves a block/object's disclosure label as text: the title path's value (if set and non-empty) → `title` → `name`. */
export function getBlockLabel(block: PreviewableBlock, data: unknown): string {
  return getPreviewValue(block, data) ?? block.title ?? block.name;
}

/**
 * Renders a function `admin.summary` slot against the row's data; null when the slot isn't a
 * function, renders nothing, or throws (logged, so one bad slot doesn't take the form down).
 */
export function renderSummarySlot(
  block: PreviewableBlock,
  slot: "title" | "media",
  data: unknown,
): ReactNode {
  const render = block.admin?.summary?.[slot];
  if (typeof render !== "function") return null;
  try {
    const record =
      typeof data === "object" && data !== null ? (data as Record<string, unknown>) : {};
    const node = render({ data: record });
    // What React renders as nothing falls back; a `0` is a value.
    if (node == null || typeof node === "boolean" || node === "") return null;
    return node;
  } catch (error) {
    console.error(error);
    return null;
  }
}
