const FORMAT_DATE_RECIPES = {
  default: {
    year: "numeric",
    month: "long",
    day: "numeric",
  },
  dateTime: {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  },
} as const;

export const formatDate = (date: string, format: keyof typeof FORMAT_DATE_RECIPES = "default") => {
  return new Date(date).toLocaleDateString(undefined, FORMAT_DATE_RECIPES[format]);
};
