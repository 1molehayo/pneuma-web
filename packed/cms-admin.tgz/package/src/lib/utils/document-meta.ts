import type { Entity } from "@cms/config";
import { flattenFields } from "@cms/config";
import { Badge } from "@cms/ui";
import { FileTextIcon } from "@phosphor-icons/react";
import { createElement, isValidElement, type ReactNode } from "react";

// Kept free of `virtual:cms-config` and `@/` imports: `@cms/admin/page` exports it, and a
// package type-checks that subpath on its own.

/** Field types eligible to back an auto-detected document title. */
const AUTO_TITLE_FIELD_TYPES = new Set(["text", "slug"]);

/**
 * Field names treated as candidates for an automatic document title when an
 * entity doesn't define `admin.summary.title`. Order is preference order.
 * Exported so the mini-documents query can include these in its fetched
 * columns and lists/pickers see meaningful labels by default.
 */
export const AUTO_TITLE_FIELDS = ["title", "name", "label", "heading"] as const;

/**
 * Restrict `AUTO_TITLE_FIELDS` to names that exist on the entity as a `text`
 * or `slug` field — avoids surfacing a UUID when an entity happens to have a
 * relation called `name`.
 */
export const getAutoTitleFields = (entity: Entity): string[] => {
  const byName = new Map(flattenFields(entity.fields).map((f) => [f.name, f.type]));
  return AUTO_TITLE_FIELDS.filter((name) => {
    const type = byName.get(name);
    return type !== undefined && AUTO_TITLE_FIELD_TYPES.has(type);
  });
};

const autoTitle = (entity: Entity, data: Record<string, unknown>): string | null => {
  for (const key of getAutoTitleFields(entity)) {
    const value = data[key];
    if (typeof value === "string" && value.trim()) return value;
  }
  return null;
};

export type DocumentMeta = {
  title: ReactNode;
  description: ReactNode;
  media: ReactNode;
  badge: ReactNode;
};

/** How the admin shows a document: its entity's `admin.summary`, or an auto-detected title. */
export const getDocumentMeta = (
  entity: Entity,
  document: Record<string, unknown>,
): DocumentMeta => {
  const resolve = (field: "title" | "description" | "media" | "badge"): ReactNode => {
    try {
      const value = entity.admin?.summary?.[field];

      if (value == null) return null;

      // Already a React element (e.g. <Icon />)
      if (isValidElement(value)) return value;

      // String
      if (typeof value === "string") return value;

      // Function — could be a render function OR a function component.
      // If it returns a primitive/element, JSX will render it either way.
      if (typeof value === "function") {
        const result = (value as (props: { data: typeof document }) => ReactNode)({
          data: document,
        });
        return result;
      }

      // ForwardRefExoticComponent — e.g. <Icon />
      if (
        typeof value === "object" &&
        (value as Record<string, unknown>).$$typeof?.toString() === "Symbol(react.forward_ref)"
      ) {
        return createElement(value, { document });
      }

      return null;
    } catch (error) {
      console.error(error);
      return createElement(Badge, { variant: "error" }, "Error resolving document meta");
    }
  };

  return {
    title: resolve("title") || autoTitle(entity, document) || "Untitled",
    description: resolve("description") || "—",
    media: resolve("media") || createElement(FileTextIcon),
    badge: resolve("badge"),
  };
};
