export const AUDIT_ACTIONS = [
  "create",
  "update",
  "delete",
  "publish",
  "unpublish",
  "restore",
  "draftSave",
  "discardDraft",
  "translate",
] as const;

export type AuditAction = (typeof AUDIT_ACTIONS)[number];

export const AUDIT_ACTION_LABELS: Record<AuditAction, string> = {
  create: "Created",
  update: "Updated",
  delete: "Deleted",
  publish: "Published",
  unpublish: "Unpublished",
  restore: "Restored a version",
  draftSave: "Saved a draft",
  discardDraft: "Discarded the draft",
  translate: "Added a translation",
};

const isAuditAction = (value: string): value is AuditAction =>
  AUDIT_ACTIONS.some((action) => action === value);

/** The label for an action the engine logged; an unknown one shows as stored. */
export const auditActionLabel = (action: string): string =>
  isAuditAction(action) ? AUDIT_ACTION_LABELS[action] : action;

/**
 * Who wrote: name, else email. A user id with neither is a deleted user. Without one, the role
 * tells the caller: `_system` is the engine's own writes, `_anonymous` or another public role a
 * request without credentials (or an API key given that role, which the entry can't tell apart),
 * any other role an API key.
 */
export const auditActorLabel = (
  actor: { id: string | null; role: string; email: string | null; name: string | null },
  roles: ReadonlyArray<{ name: string; public?: boolean }>,
): string => {
  const person = actor.name || actor.email;
  if (person) return person;
  if (actor.id) return "Deleted user";
  if (actor.role === "_system") return "System";
  if (actor.role === "_anonymous") return "Anonymous";
  const role = roles.find((candidate) => candidate.name === actor.role);
  return role?.public ? `${actor.role} (public role)` : `API key (${actor.role})`;
};
