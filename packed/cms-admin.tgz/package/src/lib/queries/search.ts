import { queryOptions } from "@tanstack/react-query";
import { client } from "../client";
import { keys } from "./keys";

export type { SearchDocument, SearchResponse, SearchResult } from "@cms/client";

export const getSearchQueryOptions = (q: string, locale?: string) =>
  queryOptions({
    queryKey: keys.search(q, locale),
    queryFn: ({ signal }) => client.search({ q, limit: 5, locale, signal }),
    enabled: q.trim().length > 0,
    staleTime: 10_000,
  });

/** The documents of `entities` matching `q`, for a package's document picker. */
export const getEntitySearchQueryOptions = (
  entities: string[],
  q: string,
  locale: string | undefined,
) =>
  queryOptions({
    queryKey: keys.entitySearch(entities, q, locale),
    queryFn: ({ signal }) => client.search({ q, entities, limit: 5, locale, signal }),
    enabled: q.length > 0,
    staleTime: 10_000,
  });
