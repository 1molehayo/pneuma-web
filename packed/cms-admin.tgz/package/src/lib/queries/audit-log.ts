import { queryOptions } from "@tanstack/react-query";
import z from "zod";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";
import type { AuditAction } from "@/lib/utils/audit-log";

export const AUDIT_LOG_PAGE_SIZE = 50;

const auditLogSchema = z.object({
  data: z.array(
    z.object({
      id: z.string(),
      createdAt: z.string(),
      action: z.string(),
      entity: z.string(),
      documentId: z.string(),
      locale: z.string().nullable(),
      /** Dot paths: `title`, `seo.title`, `content.2.heading`. */
      changedFields: z.array(z.string()),
      /** The version the same write created; null when none, or when it was pruned. */
      versionId: z.string().nullable().default(null),
      actor: z.object({
        id: z.string().nullable(),
        role: z.string(),
        email: z.string().nullable(),
        name: z.string().nullable(),
      }),
    }),
  ),
  meta: z.object({ total: z.number(), limit: z.number(), offset: z.number() }),
});

export type AuditEntry = z.infer<typeof auditLogSchema>["data"][number];

export type AuditLogFilters = {
  entity?: string;
  documentId?: string;
  actorId?: string;
  action?: AuditAction;
  locale?: string;
  /** Days (`YYYY-MM-DD`), inclusive, in the viewer's timezone. */
  from?: string;
  to?: string;
  page: number;
};

const startOfDay = (day: string) => new Date(`${day}T00:00:00`).toISOString();
const endOfDay = (day: string) => new Date(`${day}T23:59:59.999`).toISOString();

/** One page of the audit log, newest first. Admins only. */
export const getAuditLogQueryOptions = ({ page, from, to, ...filters }: AuditLogFilters) =>
  queryOptions({
    queryKey: keys.auditLog({ page, from, to, ...filters }),
    queryFn: ({ signal }) =>
      client.request("/_audit-log", {
        signal,
        schema: auditLogSchema,
        params: {
          ...filters,
          from: from ? startOfDay(from) : undefined,
          to: to ? endOfDay(to) : undefined,
          limit: AUDIT_LOG_PAGE_SIZE,
          offset: (page - 1) * AUDIT_LOG_PAGE_SIZE,
        },
      }),
  });
