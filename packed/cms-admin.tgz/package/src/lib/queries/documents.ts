import CMS_CONFIG from "virtual:cms-config";
import type { DocumentMetadata, RuntimeParams } from "@cms/client";
import { queryOptions } from "@tanstack/react-query";
import z from "zod";
import { client } from "@/lib/client";
// Re-exported here so existing `@/lib/queries/documents` consumers are
// unaffected; their canonical home is the `virtual:`-free `document-queries.ts`
// (see its preamble) so the `use-documents`/`use-document` subpath stays clean.
import { getDocumentQueryOptions, getDocumentsQueryOptions } from "@/lib/queries/document-queries";
import { getSummaryFields } from "@/lib/queries/document-summaries";
import { keys, type VersionScope } from "@/lib/queries/keys";
import type { Document, GroupedDocument, ResolvedEntity } from "@/lib/schemas";
import { groupedDocumentSchema, type ListStatus } from "@/lib/schemas";

/** Group-collapse status chip, on the wire for `?view=translations`. */

export const LIST_PAGE_SIZE = 10;
export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

// Fetch a list of documents with only the fields needed for the admin summary
const getMiniDocumentsQueryOptions = <K extends string>(
  entityName: K,
  params?: RuntimeParams & {
    page?: number;
    pageSize?: number;
    limitOverride?: number;
    locale?: string;
  },
) => {
  const entity = CMS_CONFIG.entities.find((entity) => entity.name === entityName);
  if (!entity) throw new Error(`Entity ${entityName} not found`);

  // Paging and `locale` are this helper's own (`locale` is merged into the filter); the list
  // gets the rest.
  const {
    page = 1,
    pageSize = LIST_PAGE_SIZE,
    limitOverride,
    locale,
    ...listParams
  } = params ?? {};
  const limit = limitOverride ?? pageSize;

  type Result = {
    data: ResolvedEntity<K>[];
    meta: { total: number; limit: number; offset: number };
  };

  return queryOptions<Result>({
    queryKey: keys.mini(entityName, params),
    queryFn: async ({ signal }): Promise<Result> => {
      const fields = getSummaryFields(
        entity,
        Array.isArray(listParams.fields) ? listParams.fields : [],
      );

      const localeFilter = locale ? { locale: { $eq: locale } } : undefined;
      const mergedFilter =
        localeFilter && listParams.filter
          ? { $and: [listParams.filter, localeFilter] }
          : (localeFilter ?? listParams.filter);

      const { data, meta } = await client.list(entityName, {
        ...listParams,
        filter: mergedFilter,
        limit,
        offset: limitOverride ? 0 : (page - 1) * pageSize,
        fields,
        signal,
      });

      return { data: data as ResolvedEntity<K>[], meta };
    },
  });
};

// Fetch a translatable entity's list in group-collapse mode: one entry per
// `translationGroup`, scoped to `locale`. The engine owns the collapse, count,
// pagination and the four status predicates; the shape is grouped entries
// (`{ translationGroup, row, locales }`), so this can't reuse the entity Zod
// schema — it validates against `groupedDocumentSchema` instead.
const getGroupedDocumentsQueryOptions = <K extends string>(
  entityName: K,
  params: {
    page?: number;
    pageSize?: number;
    sort?: string;
    locale: string;
    status?: ListStatus;
    filter?: RuntimeParams["filter"];
    limitOverride?: number;
  },
) => {
  const entity = CMS_CONFIG.entities.find((entity) => entity.name === entityName);
  if (!entity) throw new Error(`Entity ${entityName} not found`);

  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? LIST_PAGE_SIZE;
  const limit = params.limitOverride ?? pageSize;

  type Result = {
    data: GroupedDocument[];
    meta: { total: number; limit: number; offset: number };
  };

  return queryOptions<Result>({
    queryKey: keys.grouped(entityName, params),
    queryFn: async ({ signal }): Promise<Result> => {
      // No caller-supplied extra fields: this only feeds the entity list page,
      // whose rows render the summary fields alone.
      const fields = getSummaryFields(entity);

      const { data, meta } = await client.request<{
        data: unknown[];
        meta: { total: number; limit: number; offset: number };
      }>(`/${entityName}`, {
        params: {
          view: "translations",
          locale: params.locale,
          status: params.status,
          sort: params.sort,
          filter: params.filter,
          fields,
          limit,
          offset: params.limitOverride ? 0 : (page - 1) * pageSize,
        },
        signal,
      });

      return { data: z.array(groupedDocumentSchema).parse(data), meta };
    },
  });
};

const getGlobalDocumentQueryOptions = (
  globalName: string,
  params?: RuntimeParams & { locale?: string; draft?: boolean },
) => {
  const draft = params?.draft === true;
  return queryOptions({
    queryKey: keys.globalRead(globalName, draft, params),
    queryFn: async ({ signal }) => {
      const { data } = await client.get(globalName, {
        ...params,
        ...(draft ? { draft: true } : {}),
        signal,
      });
      return data as (Document & DocumentMetadata) | null;
    },
  });
};

/** Version-history list for a document. */
export type VersionRow = {
  id: string;
  documentId: string;
  createdAt: string;
  createdBy: string | null;
  /** This row matches the canonical's `pending_draft_version_id` (or, when no
   *  pending draft, the published_version_id or latest row). The drawer hides
   *  Restore on rows where this is true. */
  isCurrent: boolean;
  /** This row matches the canonical's `published_version_id`. The drawer hides
   *  Restore on rows where this is true. */
  isPublished: boolean;
  /** The `createdBy` user's name and email, on listed versions; null for a deleted user or an API key. */
  author?: { name: string | null; email: string | null } | null;
  data?: Record<string, unknown>;
};

/** Version-history list for a document, newest first. Omits each version's data. */
const getVersionsQueryOptions = (scope: VersionScope) => {
  return queryOptions({
    queryKey: keys.versions(scope),
    queryFn: async ({ signal }) => {
      const { entityName, documentId, locale } = scope;
      const res = documentId
        ? await client.versions.list(entityName, documentId, { signal })
        : await client.versions.list(entityName, { locale, signal });
      return res.data as VersionRow[];
    },
  });
};

/** One version with its data (minus the fields `versions.read` hides from the viewer). */
const getVersionQueryOptions = (scope: VersionScope, versionId: string) => {
  return queryOptions({
    queryKey: keys.version(scope, versionId),
    queryFn: async ({ signal }) => {
      const { entityName, documentId, locale } = scope;
      const res = documentId
        ? await client.versions.get(entityName, documentId, versionId, { signal })
        : await client.versions.get(entityName, versionId, { locale, signal });
      return res.data as VersionRow;
    },
  });
};

export {
  getDocumentQueryOptions,
  getDocumentsQueryOptions,
  getGlobalDocumentQueryOptions,
  getGroupedDocumentsQueryOptions,
  getMiniDocumentsQueryOptions,
  getVersionQueryOptions,
  getVersionsQueryOptions,
};
