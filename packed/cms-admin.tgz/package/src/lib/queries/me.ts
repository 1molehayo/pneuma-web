import { ClientError } from "@cms/client";
import { queryOptions } from "@tanstack/react-query";
import z from "zod";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";
import { userSchema } from "@/lib/schemas";

const getMeQueryOptions = () => {
  return queryOptions({
    queryKey: keys.me(),
    queryFn: async ({ signal }) => {
      try {
        const { data } = await client.request("/auth/me", {
          signal,
          schema: z.object({
            data: z.object({ user: userSchema }),
          }),
        });

        return data.user;
      } catch (err) {
        // A 401 is the answer for "not logged in". Anything else — a 5xx, the network — is a
        // failure, not a logout: let it reach the error screen and error reporting.
        if (err instanceof ClientError && err.status === 401) return null;
        throw err;
      }
    },
    staleTime: 60_000,
  });
};

export { getMeQueryOptions };
