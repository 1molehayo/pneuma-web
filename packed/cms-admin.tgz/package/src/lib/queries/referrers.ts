import { queryOptions } from "@tanstack/react-query";
import z from "zod";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";

const referrersSchema = z.object({
  data: z.array(
    z.object({
      entity: z.string(),
      id: z.string(),
      locale: z.string().nullable(),
      fields: z.array(z.object({ path: z.string(), draft: z.boolean() })),
    }),
  ),
  /** `hidden`: referrers the viewer can't read, counted in `total` but not listed. */
  meta: z.object({ total: z.number(), hidden: z.number() }),
});

export type Referrer = z.infer<typeof referrersSchema>["data"][number];

/**
 * The documents pointing at one document. Keyed under the document, so invalidating the document
 * refetches it.
 */
export const getReferrersQueryOptions = (entityName: string, id: string) =>
  queryOptions({
    queryKey: keys.referrers(entityName, id),
    queryFn: ({ signal }) =>
      client.request(`/${entityName}/${id}/referrers`, { signal, schema: referrersSchema }),
  });
