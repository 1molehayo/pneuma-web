import type { DocumentMetadata, RuntimeParams } from "@cms/client";
import { queryOptions } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";
import type { ResolvedEntity } from "@/lib/schemas";

// The single-doc-by-id and list reads that need no `virtual:cms-config`, split
// out so they (and `useDocuments`/`useDocument`) can be imported via a subpath
// export without dragging the virtual module into the server-side config-load
// graph. The config-dependent factories (mini/grouped) stay in `documents.ts`.

const getDocumentQueryOptions = <K extends string>(
  entityName: K,
  id: string,
  params?: RuntimeParams & { draft?: boolean },
) => {
  const draft = params?.draft === true;
  return queryOptions({
    queryKey: keys.documentRead(entityName, id, draft, params),
    queryFn: async ({ signal }) => {
      // The SDK trusts the server (no client-side Zod parse), so the
      // engine-synthesised `_status` / `_draftCreatedAt` ride through on both
      // the draft and canonical paths unmodified.
      const { data } = await client.get(entityName, id, {
        ...params,
        ...(draft ? { draft: true } : {}),
        signal,
      });
      return data as ResolvedEntity<K> & DocumentMetadata;
    },
  });
};

const getDocumentsQueryOptions = <K extends string>(entityName: K, params?: RuntimeParams) => {
  return queryOptions({
    queryKey: keys.list(entityName, params),
    queryFn: async ({ signal }) => {
      const { data } = await client.list(entityName, {
        limit: 100,
        ...params,
        signal,
      });

      return data as ResolvedEntity<K>[];
    },
  });
};

export { getDocumentQueryOptions, getDocumentsQueryOptions };
