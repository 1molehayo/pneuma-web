import type { Entity } from "@cms/config";
import { queryOptions } from "@tanstack/react-query";
import { client } from "../client";
import { getAutoTitleFields } from "../utils/document-meta";
import { keys } from "./keys";

// A card's read of one referenced document: a relation row's label, a link's target. No
// `virtual:cms-config` import, so `@cms/admin/page` can export it to a package's field input;
// the caller passes the entity.

type Summary = Record<string, unknown>;
type Batch = { ids: Set<string>; documents: Promise<Map<string, Summary>> };

const BASE_FIELDS = ["_entity", "id", "createdAt", "updatedAt", "locale", "translationGroup"];

// The fields an admin list or picker row needs: the base columns, the entity's
// auto-included title fields (title/name/label/heading, restricted to text/slug
// types so a relation field named `name` doesn't pull a UUID), its configured
// list and summary fields, and any extra fields the caller asks for.
const getSummaryFields = (entity: Entity, extraFields: string[] = []): string[] => [
  ...new Set([
    ...BASE_FIELDS,
    ...getAutoTitleFields(entity),
    ...(entity.admin?.list?.fields || []),
    ...(entity.admin?.summary?.fields || []),
    ...extraFields,
  ]),
];

/**
 * The ids go out as an indexed `$in` array, and the engine's query parser (qs) turns an array
 * indexed past 20 into an object, which the filter builder rejects — so a larger batch goes out
 * in chunks of 20. `parser.test.ts` pins that boundary.
 */
const MAX_BATCH_SIZE = 20;

/** Per entity and field set, the ids asked for since the last flush, and the one fetch that will load them. */
const pendingBatches = new Map<string, Batch>();

const chunk = <T>(items: T[], size: number): T[][] =>
  Array.from({ length: Math.ceil(items.length / size) }, (_, index) =>
    items.slice(index * size, (index + 1) * size),
  );

/**
 * Loads one document, sharing an `id $in` list call with every other id of the same entity (and
 * fields) asked for in this tick — so a list of cards costs one request per entity.
 */
const loadInBatch = (entity: Entity, id: string, fields: string[]): Promise<Summary | null> => {
  const batchKey = JSON.stringify([entity.name, fields]);
  let batch = pendingBatches.get(batchKey);
  if (!batch) {
    const ids = new Set<string>();
    // A macrotask, not a microtask: every card's query of this render has joined by then.
    const documents = new Promise((resolve) => setTimeout(resolve, 0)).then(async () => {
      pendingBatches.delete(batchKey);
      const results = await Promise.all(
        chunk([...ids], MAX_BATCH_SIZE).map((chunkIds) =>
          client.list(entity.name, {
            filter: { id: { $in: chunkIds } },
            limit: chunkIds.length,
            fields: getSummaryFields(entity, fields),
          }),
        ),
      );
      return new Map(
        results
          .flatMap((result) => result.data as Summary[])
          .map((document) => [document.id as string, document]),
      );
    });
    batch = { ids, documents };
    pendingBatches.set(batchKey, batch);
  }

  batch.ids.add(id);
  return batch.documents.then((documents) => documents.get(id) ?? null);
};

const isRow = (id: string, document: unknown): document is Summary =>
  typeof document === "object" && document !== null && "id" in document && document.id === id;

// A global has no list, and a ref doesn't say which locale's row it is: read the global in every
// locale and keep the row with the ref's id.
const loadGlobalRow = async (entity: Entity, id: string, locales: readonly string[]) => {
  const rows = await Promise.all(
    (entity.translatable ? locales : [undefined]).map((locale) =>
      client.get(entity.name, { locale }),
    ),
  );
  return rows.map((row) => row.data).find((data) => isRow(id, data)) ?? null;
};

/**
 * One referenced document as a card shows it, or `null` once it's gone (or unreadable). A
 * collection document comes with its summary fields plus `fields`, batched; a global comes whole,
 * found among `locales`. Document and global writes refresh it (`invalidate` in `keys.ts`).
 */
const getDocumentSummaryQueryOptions = (
  entity: Entity,
  id: string,
  { fields = [], locales = [] }: { fields?: string[]; locales?: readonly string[] } = {},
) =>
  queryOptions<Summary | null>({
    queryKey: entity.global
      ? keys.globalSummary(entity.name, id)
      : keys.summary(entity.name, id, fields),
    queryFn: () =>
      entity.global ? loadGlobalRow(entity, id, locales) : loadInBatch(entity, id, fields),
  });

export { getDocumentSummaryQueryOptions, getSummaryFields };
