import type { RuntimeParams } from "@cms/client";
import { queryOptions } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";
import { apiKeySchema } from "@/lib/schemas";

const getApiKeysQueryOptions = (params?: RuntimeParams) => {
  return queryOptions({
    queryKey: keys.list("_api-keys", params),
    queryFn: async ({ signal }) => {
      const { data } = await client.list("_api-keys", {
        ...params,
        signal,
      });

      return apiKeySchema.array().parse(data);
    },
    staleTime: Number.POSITIVE_INFINITY,
    retry: false,
    refetchOnWindowFocus: false,
  });
};

export { getApiKeysQueryOptions };
