import type { RuntimeParams } from "@cms/client";
import { queryOptions } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";
import { userSchema } from "@/lib/schemas";

const getUsersQueryOptions = (params?: RuntimeParams) => {
  return queryOptions({
    queryKey: keys.list("_user", params),
    queryFn: async ({ signal }) => {
      const { data } = await client.list("_user", {
        limit: 100,
        ...params,
        signal,
      });

      return userSchema.array().parse(data);
    },
  });
};

/** The engine's page cap: a list answers at most this many rows. */
const USERS_PAGE_SIZE = 100;

/** Every user, page by page, for a picker that must offer them all. */
const getAllUsersQueryOptions = () => {
  return queryOptions({
    queryKey: keys.list("_user", "all"),
    queryFn: async ({ signal }) => {
      const users = [];
      for (let offset = 0; ; offset += USERS_PAGE_SIZE) {
        const { data, meta } = await client.list("_user", {
          limit: USERS_PAGE_SIZE,
          offset,
          signal,
        });
        users.push(...userSchema.array().parse(data));
        if (data.length < USERS_PAGE_SIZE || users.length >= meta.total) return users;
      }
    },
  });
};

export { getAllUsersQueryOptions, getUsersQueryOptions };
