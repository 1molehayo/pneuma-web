import type { Query, QueryClient, QueryFilters } from "@tanstack/react-query";

// Every admin query key, and what each write invalidates. Producers build their key here and
// writers call an intent, so "after X, Y is stale" lives in one place and `keys.test.ts` pins
// it. No `virtual:cms-config` import: the test runs under the root vitest suite.

/** A document whose versions are read: a collection document by id, or a global (by locale when translatable). */
export type VersionScope = {
  entityName: string;
  /** A collection document. Omitted for a global. */
  documentId?: string;
  /** A translatable global's locale. */
  locale?: string;
};

const variant = (draft: boolean) => (draft ? "draft" : "canonical");

const versions = ({ entityName, documentId, locale }: VersionScope) =>
  documentId
    ? ([entityName, documentId, "versions"] as const)
    : (["globals", entityName, "versions", { locale }] as const);

export const keys = {
  /** Every query of every document of one entity. */
  documents: (entity: string) => [entity] as const,
  /** Every query of one document: its reads, referrers and versions. */
  document: (entity: string, id: string) => [entity, id] as const,
  documentRead: (entity: string, id: string, draft: boolean, params: unknown) =>
    [entity, id, variant(draft), params] as const,
  referrers: (entity: string, id: string) => [entity, id, "referrers"] as const,
  /** Every query of one global, every locale: its reads and versions. */
  global: (name: string) => ["globals", name] as const,
  globalRead: (name: string, draft: boolean, params: unknown) =>
    ["globals", name, variant(draft), params] as const,
  /** A global's row, in whichever locale has this id, as a link or relation card shows it. */
  globalSummary: (name: string, id: string) => ["globals", name, "summary", id] as const,
  versions,
  version: (scope: VersionScope, versionId: string) => [...versions(scope), versionId] as const,
  /** Full documents (`getDocumentsQueryOptions`), the users and the API keys. */
  list: (entity: string, params?: unknown) => ["list", entity, params] as const,
  /** The plain list screen, relation pickers and referrer lists. */
  mini: (entity: string, params: unknown) => ["mini", entity, params] as const,
  /** The translation list (`?view=translations`). */
  grouped: (entity: string, params: unknown) => ["grouped", entity, params] as const,
  relationOptions: (entities: string[], search: string, locale: string | undefined) =>
    ["relation-options", entities, search, locale] as const,
  relationSelected: (entities: string[], ids: string[]) =>
    ["relation-selected", entities, ids] as const,
  /** One collection document's summary fields (plus `fields`), batched with its neighbours. */
  summary: (entity: string, id: string, fields: string[]) =>
    ["summary", entity, id, fields] as const,
  recentDocuments: (entity: string) => ["dashboard", "recent", entity] as const,
  search: (q: string, locale: string | undefined) => ["search", q, locale] as const,
  /** A search of some entities' documents, as a package's document picker runs it. */
  entitySearch: (entities: string[], q: string, locale: string | undefined) =>
    ["entity-search", entities, q, locale] as const,
  auditLog: (filters?: object) =>
    filters ? (["_audit-log", filters] as const) : (["_audit-log"] as const),
  me: () => ["me"] as const,
  assetCleanup: () => ["asset-cleanup"] as const,
};

const PICKER_ROOTS = new Set<unknown>(["relation-options", "relation-selected", "entity-search"]);

/** A picker's keys name every entity it reads at index 1. */
const readsEntity = (entity: string): QueryFilters => ({
  predicate: ({ queryKey: [root, entities] }: Query) =>
    PICKER_ROOTS.has(root) && Array.isArray(entities) && entities.includes(entity),
});

/** Every query that lists an entity's documents. */
const lists = (entity: string): QueryFilters[] => [
  { queryKey: ["list", entity] },
  { queryKey: ["mini", entity] },
  { queryKey: ["grouped", entity] },
  { queryKey: keys.recentDocuments(entity) },
  { queryKey: ["summary", entity] },
  readsEntity(entity),
];

const run = async (queryClient: QueryClient, filters: QueryFilters[]) => {
  await Promise.all(filters.map((filter) => queryClient.invalidateQueries(filter)));
};

type Target = { entity: string; id: string };

export const invalidate = {
  /** A create, save, publish, unpublish or discard of one document. */
  afterDocumentWrite: (queryClient: QueryClient, { entity, id }: Target) =>
    run(queryClient, [{ queryKey: keys.document(entity, id) }, ...lists(entity)]),

  /** A write to several documents of one entity: a bulk action, an upload. */
  afterListWrite: (queryClient: QueryClient, { entity, ids }: { entity: string; ids: string[] }) =>
    run(queryClient, [
      ...ids.map((id) => ({ queryKey: keys.document(entity, id) })),
      ...lists(entity),
    ]),

  /**
   * A delete. The deleted document's own queries are left alone: refetching them while its
   * screen unmounts would only 404. A replacement rewrites each referrer to point at
   * `replacementId`, so those documents and their lists go stale too.
   */
  afterDelete: (
    queryClient: QueryClient,
    {
      entity,
      replacementId,
      referrers = [],
    }: { entity: string; replacementId?: string; referrers?: Target[] },
  ) => {
    const referrerEntities = new Set(referrers.map((referrer) => referrer.entity));
    referrerEntities.delete(entity);
    return run(queryClient, [
      ...lists(entity),
      ...(replacementId ? [{ queryKey: keys.document(entity, replacementId) }] : []),
      // A referrer may be a global, keyed by name rather than id.
      ...referrers.flatMap((referrer) => [
        { queryKey: keys.document(referrer.entity, referrer.id) },
        { queryKey: keys.global(referrer.entity) },
      ]),
      ...[...referrerEntities].flatMap(lists),
    ]);
  },

  /** A save, publish, unpublish, discard or translation of a global. */
  afterGlobalWrite: (queryClient: QueryClient, { name }: { name: string }) =>
    run(queryClient, [{ queryKey: keys.global(name) }, readsEntity(name)]),

  /**
   * A version restore. It doesn't bump `updatedAt`, so nothing else would notice. Restoring a
   * translatable document's shared fields rewrites its siblings (and their versions) too, and the
   * drawer doesn't know their ids: every document of the entity goes stale.
   */
  afterRestore: (queryClient: QueryClient, scope: VersionScope) =>
    run(queryClient, [
      ...(scope.documentId
        ? [{ queryKey: keys.documents(scope.entityName) }, ...lists(scope.entityName)]
        : [{ queryKey: keys.global(scope.entityName) }, readsEntity(scope.entityName)]),
      { queryKey: keys.auditLog() },
    ]),
};
