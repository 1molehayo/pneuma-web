import { ClientError } from "@cms/client";
import type { AdminErrorSource, CmsPlugin, JsonValue, PluginAdminHooks } from "@cms/config";

/**
 * 4xx answers are expected — validation, not found, forbidden — and already shown to the
 * editor. A 5xx or anything that isn't a `ClientError` is a defect.
 */
export const isReportable = (error: unknown): boolean =>
  !(error instanceof ClientError) || error.status >= 500;

export type PluginReporting = {
  reportError: (error: unknown, source: AdminErrorSource) => void;
  setReportedUser: (user: { id: string; role: string } | null) => void;
};

/**
 * Runs every plugin's `admin.setup` with what its server half handed over, and fans errors and
 * the signed-in editor out to their `onError` / `onUser`. A plugin's hooks wait for its setup;
 * a setup that throws or rejects (its chunk failed to load mid-deploy) leaves that plugin out
 * instead of every later call rejecting unhandled. A hook that throws or rejects never reaches
 * the caller.
 */
export function createPluginReporting(
  plugins: readonly CmsPlugin[],
  data: Readonly<Record<string, JsonValue>>,
): PluginReporting {
  const started = plugins.flatMap(({ name, admin }) => {
    if (!admin) return [];
    const setUp = Promise.resolve()
      .then(() => admin.setup?.({ data: data[name] }))
      .then(
        () => true,
        () => false,
      );
    return [{ admin, setUp }];
  });

  const forEachReady = (call: (admin: PluginAdminHooks) => unknown) => {
    for (const { admin, setUp } of started) {
      // A broken reporter must not take the admin (or the other plugins) down with it, whether
      // it throws or, being async, rejects later.
      void setUp.then((ok) => (ok ? call(admin) : undefined)).catch(() => undefined);
    }
  };

  return {
    reportError: (error, source) => {
      if (!isReportable(error)) return;
      const requestId = error instanceof ClientError ? error.requestId : undefined;
      forEachReady((admin) => admin.onError?.(error, { source, requestId }));
    },
    setReportedUser: (user) => forEachReady((admin) => admin.onUser?.(user)),
  };
}
