import type { CmsConfig } from "@cms/config";
import { createContext, use } from "react";

// The project's config for code outside the admin's own bundle graph: a package's field input
// can't import `virtual:cms-config`, which only resolves in the admin's Vite build, so the app
// provides it here and `@cms/admin/page` exports the hook.
export const AdminConfigContext = createContext<CmsConfig | null>(null);

/** The project's config, inside the admin. */
export const useAdminConfig = (): CmsConfig => {
  const config = use(AdminConfigContext);
  if (!config) throw new Error("useAdminConfig must be used inside the admin");
  return config;
};
