import CMS_CONFIG from "virtual:cms-config";
import { Spinner } from "@cms/ui";
import { IconContext } from "@phosphor-icons/react";
import { MutationCache, QueryCache, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { createRouter, RouterProvider } from "@tanstack/react-router";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { RouteError } from "./components/route-error";
import { AdminConfigContext } from "./lib/admin-config";
import { reportError } from "./lib/plugins";
import { routeTree } from "./routeTree.gen";

import "./styles/global.css";

// Mutations already toast their own failures; these report the ones that are defects (not
// 4xx answers) without changing what the editor sees.
const queryClient = new QueryClient({
  queryCache: new QueryCache({ onError: (error) => reportError(error, "query") }),
  mutationCache: new MutationCache({ onError: (error) => reportError(error, "mutation") }),
});

// A deploy replaces the hashed chunks, so a tab opened before it 404s on its next lazy import, and
// "Try again" asks for the same dead file. Reload once to pick up the new build; the timestamp stops
// a loop when the chunk is missing for some other reason.
const CHUNK_RELOAD_KEY = "cms:chunk-reload-at";
window.addEventListener("vite:preloadError", (event) => {
  try {
    if (Date.now() - Number(sessionStorage.getItem(CHUNK_RELOAD_KEY)) < 10_000) return;
    sessionStorage.setItem(CHUNK_RELOAD_KEY, String(Date.now()));
  } catch {
    return;
  }
  event.preventDefault();
  window.location.reload();
});

const RoutePending = () => (
  <div className="flex min-h-screen items-center justify-center">
    <Spinner size="lg" />
  </div>
);

// Set up a Router instance
const router = createRouter({
  routeTree,
  basepath: "/admin",
  context: {
    queryClient,
  },
  defaultPreload: "intent",
  // Since we're using React Query, we don't want loader calls to ever be stale
  // This will ensure that the loader is always called when the route is preloaded or visited
  defaultPreloadStaleTime: 0,
  defaultPendingComponent: RoutePending,
  defaultErrorComponent: RouteError,
  scrollRestoration: true,
});

// Register things for typesafety
declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Missing #root element");

createRoot(rootElement).render(
  <StrictMode>
    <IconContext.Provider value={{ weight: "bold", size: "1em" }}>
      <AdminConfigContext value={CMS_CONFIG}>
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={router} />
        </QueryClientProvider>
      </AdminConfigContext>
    </IconContext.Provider>
  </StrictMode>,
);
