import { cn } from "@cms/ui";
import { createFileRoute, Outlet, redirect, useLocation } from "@tanstack/react-router";
import { useState } from "react";
import { GlobalSearch } from "@/components/global-search";
import { Header } from "@/components/header";
import { BaseLayout as Layout } from "@/components/layouts/base";
import { Sidebar } from "@/components/sidebar";
import { useKeyboardShortcut } from "@/lib/hooks/use-keyboard-shortcut";
import { setReportedUser } from "@/lib/plugins";
import { getMeQueryOptions } from "@/lib/queries/me";

export const Route = createFileRoute("/_authenticated")({
  component: RouteComponent,
  beforeLoad: async ({ context: { queryClient } }) => {
    const me = await queryClient.fetchQuery(getMeQueryOptions());

    if (!me) {
      setReportedUser(null);
      throw redirect({ to: "/login" });
    }

    setReportedUser({ id: me.id, role: me.role });
    return { me };
  },
});

function RouteComponent() {
  const [searchOpen, setSearchOpen] = useState(false);

  const pathname = useLocation({ select: (l) => l.pathname });
  const isSettings = pathname.startsWith("/settings");

  useKeyboardShortcut({ key: "k", mod: true }, () => setSearchOpen((v) => !v));

  return (
    <div className="h-full flex flex-col min-h-screen">
      <Header onSearchOpen={() => setSearchOpen(true)} />
      <Layout>
        {/* hide sidebar on settings pages on desktop */}
        <Layout.Aside className={cn(isSettings && "md:hidden")}>
          <Sidebar />
        </Layout.Aside>
        <Layout.Content>
          <Outlet />
        </Layout.Content>
      </Layout>
      <GlobalSearch open={searchOpen} onOpenChange={setSearchOpen} />
    </div>
  );
}
