import CMS_CONFIG from "virtual:cms-config";
import { createFileRoute, notFound, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/entity/$name")({
  component: Outlet,
  beforeLoad: ({ params }) => {
    const { name } = params;
    const entity = CMS_CONFIG.entities.find((e) => e.name === name);

    if (!entity) {
      throw notFound();
    }

    return { entity };
  },
});
