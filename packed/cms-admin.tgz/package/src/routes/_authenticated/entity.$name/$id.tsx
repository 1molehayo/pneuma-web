import type { Entity } from "@cms/config";
import { Badge, Breadcrumbs, Button, cn, Dialog, Dropdown, IconButton, toast } from "@cms/ui";
import {
  BracketsCurlyIcon,
  CaretDownIcon,
  ClockCounterClockwiseIcon,
  CloudArrowUpIcon,
  EyeIcon,
  EyeSlashIcon,
  EyeSlashIcon as EyeSlashOutlineIcon,
  FloppyDiskIcon,
  LinkIcon,
  TrashIcon,
  XCircleIcon,
} from "@phosphor-icons/react";
import { useMutation, useQuery, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import z from "zod";
import { DocumentBanners } from "@/components/document-banners";
import { DocumentLocaleSwitcher } from "@/components/document-locale-switcher";
import { DeleteDocumentDialog } from "@/components/forms/delete-document-dialog";
import { DOCUMENT_FORM_ID, DocumentForm, useDocumentForm } from "@/components/forms/document-form";
import { JsonPreviewPanel } from "@/components/forms/json-preview-panel";
import { HistoryDrawer } from "@/components/history-drawer";
import { PageLayout as Layout } from "@/components/layouts/page";
import { SidePanelLayout } from "@/components/layouts/side-panel";
import { PreviewComponent } from "@/components/preview-component";
import { ReferrersDrawer } from "@/components/referrers-drawer";
import { client } from "@/lib/client";
import { useCanReadAuditLog } from "@/lib/hooks/use-can-read-audit-log";
import { useDocumentFormKey } from "@/lib/hooks/use-document-form-key";
import { useKeyboardShortcut } from "@/lib/hooks/use-keyboard-shortcut";
import { getDocumentQueryOptions } from "@/lib/queries/documents";
import { invalidate } from "@/lib/queries/keys";
import { getReferrersQueryOptions } from "@/lib/queries/referrers";
import { getEntityTitle } from "@/lib/utils/config";
import { formatDate } from "@/lib/utils/dates";
import { isDocumentTranslatable, resolveDocumentMeta } from "@/lib/utils/documents";

const searchParamsSchema = z.object({
  panel: z.enum(["preview", "json"]).optional(),
});

export const Route = createFileRoute("/_authenticated/entity/$name/$id")({
  component: RouteComponent,
  validateSearch: searchParamsSchema,
  beforeLoad: ({ cause, search, params, context }) => {
    if (cause !== "enter" || search.panel) return;
    if (!context.entity.admin.preview || !context.entity.admin.previewDefaultOpen) return;
    throw redirect({
      to: "/entity/$name/$id",
      params,
      search: { ...search, panel: "preview" },
      replace: true,
    });
  },
  loader: async ({ params, context }) => {
    const cfgEntity = context.entity;
    const useDraft = cfgEntity?.versions?.drafts ?? false;
    await context.queryClient.ensureQueryData(
      getDocumentQueryOptions(params.name, params.id, useDraft ? { draft: true } : undefined),
    );
  },
});

function RouteComponent() {
  const { id } = Route.useParams();
  const navigate = Route.useNavigate();
  const { entity } = Route.useRouteContext();
  const panel = Route.useSearch({ select: (search) => search.panel });

  const isPreviewOpen = panel === "preview";
  const isJsonOpen = panel === "json";

  const queryClient = useQueryClient();

  const draftsEnabled = entity.versions?.drafts ?? false;

  // Always fetch the overlay view; engine falls back to canonical when no
  // pending draft exists.
  const { data: document } = useSuspenseQuery(
    getDocumentQueryOptions(entity.name, id, draftsEnabled ? { draft: true } : undefined),
  );

  const hasPreview = !!entity?.admin.preview;
  const isTranslatable = isDocumentTranslatable(document);

  const [deleteRequested, setDeleteRequested] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [referrersOpen, setReferrersOpen] = useState(false);
  // The count is a scan of every entity relating to this one: fetched once the menu opens.
  const [menuOpened, setMenuOpened] = useState(false);
  const { data: referrers } = useQuery({
    ...getReferrersQueryOptions(entity.name, id),
    enabled: menuOpened,
  });
  const referrerCount = referrers?.meta.total;
  // One timeline: versions for anyone who can read them, audit entries for admins.
  const canReadAuditLog = useCanReadAuditLog();
  const historyEnabled = !!entity.versions || canReadAuditLog;
  const [discardRequested, setDiscardRequested] = useState(false);

  /**
   * Each save button sets this synchronously before form submit fires; the
   * form's onSubmit reads it to pick the mutation. Per-mutation loading
   * state means only the clicked button spins.
   */
  const submitModeRef = useRef<"draft" | "publish">(draftsEnabled ? "draft" : "publish");

  const invalidateAll = () => {
    invalidate.afterDocumentWrite(queryClient, { entity: entity.name, id });
  };

  const [formKey, markOwnSave] = useDocumentFormKey(document);

  const saveDraftMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.drafts.save(entity.name, id, data);
      return res.data;
    },
    onSuccess: () => {
      markOwnSave();
      invalidateAll();
    },
  });

  const publishMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.update(entity.name, id, data);
      return res.data;
    },
    onSuccess: () => {
      markOwnSave();
      invalidateAll();
    },
  });

  const unpublishMutation = useMutation({
    mutationFn: async () => {
      const res = await client.unpublish(entity.name, id);
      return res.data;
    },
    onSuccess: () => {
      invalidateAll();
      toast({ variant: "positive", title: "Unpublished" });
    },
  });

  const discardDraftMutation = useMutation({
    mutationFn: async () => {
      await client.drafts.discard(entity.name, id);
    },
    onSuccess: () => {
      invalidateAll();
      toast({ variant: "positive", title: "Draft discarded" });
    },
  });

  const status = (document._status ?? "published") as "draft" | "published" | "modified";
  const hasPendingDraft = status === "modified";
  const isPublished = document.publishedAt != null;

  // cmd+s = save (draft if drafts on, else publish). cmd+shift+s = always
  // publish. Publishing should never ride on muscle memory.
  const triggerSubmit = (mode: "draft" | "publish") => {
    submitModeRef.current = mode;
    const form = window.document.getElementById(DOCUMENT_FORM_ID);
    if (form instanceof HTMLFormElement) form.requestSubmit();
  };
  useKeyboardShortcut({ key: "s", mod: true }, () => {
    triggerSubmit(draftsEnabled ? "draft" : "publish");
  });
  useKeyboardShortcut({ key: "s", mod: true, shift: true }, () => triggerSubmit("publish"), {
    enabled: draftsEnabled,
  });

  return (
    <>
      <Layout inert={saveDraftMutation.isPending || publishMutation.isPending} key={id}>
        <Layout.Navbar>
          <Breadcrumbs className="mr-auto -ml-2">
            <Breadcrumbs.Item asChild>
              <Link from={Route.fullPath} to="..">
                {getEntityTitle(entity, { plural: true })}
              </Link>
            </Breadcrumbs.Item>
            <Breadcrumbs.Separator />
            <Breadcrumbs.Item disabled>...</Breadcrumbs.Item>
          </Breadcrumbs>

          {isTranslatable && (
            <DocumentLocaleSwitcher
              document={document}
              getTranslationLinkProps={(translationId) => ({
                to: "/entity/$name/$id",
                params: { name: entity.name, id: translationId },
                search: { panel },
              })}
              getNewTranslationLinkProps={(locale) => ({
                to: "/entity/$name/translate/$id/$locale",
                params: { name: entity.name, id, locale },
              })}
            />
          )}
          <Button
            size="xs"
            variant="outline"
            onClick={() =>
              navigate({
                to: ".",
                search: (prev) => ({ ...prev, panel: isJsonOpen ? undefined : "json" }),
              })
            }
          >
            <BracketsCurlyIcon /> JSON
          </Button>
          {hasPreview && (
            <Button
              size="xs"
              variant="outline"
              onClick={() =>
                navigate({
                  to: ".",
                  search: (prev) => ({ ...prev, panel: isPreviewOpen ? undefined : "preview" }),
                })
              }
            >
              {isPreviewOpen ? <EyeSlashIcon /> : <EyeIcon />} Preview
            </Button>
          )}
        </Layout.Navbar>

        <DocumentForm
          key={formKey}
          initialData={document}
          fields={entity.fields}
          onSubmit={async (data) => {
            const mutation =
              submitModeRef.current === "draft" && draftsEnabled
                ? saveDraftMutation
                : publishMutation;
            await mutation.mutateAsync(data);
          }}
        >
          <DocumentForm.UnsavedChangesBlocker />
          <SidePanelLayout collapseMainOnMobile={panel !== undefined}>
            <SidePanelLayout.Main>
              <Layout.Container className={cn(panel !== undefined && "md:min-w-0")}>
                <DocumentHeader entity={entity} status={draftsEnabled ? status : undefined} />
                <DocumentBanners entity={entity} document={document} className="mb-6" />
                <DocumentForm.Fields entityName={entity.name} op="update" />
              </Layout.Container>

              <Layout.Actions>
                <div className="text-xs text-foreground-secondary">
                  Last Updated: {formatDate(document.updatedAt)}
                </div>
                <Button.Group className="ml-auto">
                  {draftsEnabled ? (
                    <>
                      <Button
                        type="submit"
                        form={DOCUMENT_FORM_ID}
                        variant="outline"
                        isLoading={saveDraftMutation.isPending}
                        onClick={() => {
                          submitModeRef.current = "draft";
                        }}
                      >
                        <FloppyDiskIcon />
                        Save draft
                      </Button>
                      <Button
                        type="submit"
                        form={DOCUMENT_FORM_ID}
                        isLoading={publishMutation.isPending}
                        onClick={() => {
                          submitModeRef.current = "publish";
                        }}
                      >
                        <CloudArrowUpIcon />
                        Publish
                      </Button>
                    </>
                  ) : (
                    <Button
                      type="submit"
                      form={DOCUMENT_FORM_ID}
                      isLoading={publishMutation.isPending}
                      onClick={() => {
                        submitModeRef.current = "publish";
                      }}
                    >
                      <FloppyDiskIcon />
                      Save
                    </Button>
                  )}
                  <Dropdown onOpenChange={(open) => open && setMenuOpened(true)}>
                    <Dropdown.Items>
                      {historyEnabled && (
                        <Dropdown.Item onSelect={() => setHistoryOpen(true)}>
                          <ClockCounterClockwiseIcon />
                          History
                        </Dropdown.Item>
                      )}
                      <Dropdown.Item onSelect={() => setReferrersOpen(true)}>
                        <LinkIcon />
                        Used in
                        {referrerCount !== undefined && (
                          <Badge size="xs" className="ml-auto">
                            {referrerCount}
                          </Badge>
                        )}
                      </Dropdown.Item>
                      {draftsEnabled && hasPendingDraft && (
                        <Dropdown.Item onSelect={() => setDiscardRequested(true)}>
                          <XCircleIcon />
                          Discard draft
                        </Dropdown.Item>
                      )}
                      {draftsEnabled && isPublished && (
                        <Dropdown.Item onSelect={() => unpublishMutation.mutate()}>
                          <EyeSlashOutlineIcon />
                          Unpublish
                        </Dropdown.Item>
                      )}
                      <Dropdown.Item
                        className="text-negative"
                        onSelect={() => setDeleteRequested(true)}
                      >
                        <TrashIcon />
                        Delete
                      </Dropdown.Item>
                    </Dropdown.Items>
                    <Dropdown.Trigger asChild>
                      <IconButton aria-label="More options">
                        <CaretDownIcon />
                      </IconButton>
                    </Dropdown.Trigger>
                  </Dropdown>
                </Button.Group>
              </Layout.Actions>
            </SidePanelLayout.Main>

            {isJsonOpen && (
              <SidePanelLayout.Side defaultSize="50%">
                <JsonPreviewPanel />
              </SidePanelLayout.Side>
            )}
            {isPreviewOpen && entity.admin.preview && (
              <SidePanelLayout.Side defaultSize="33%">
                <PreviewComponent
                  component={entity.admin.preview}
                  schema={entity.schema}
                  initialData={document}
                />
              </SidePanelLayout.Side>
            )}
          </SidePanelLayout>
        </DocumentForm>
      </Layout>

      <DeleteDocumentDialog
        document={
          deleteRequested
            ? {
                id,
                entity: entity.name,
                title: resolveDocumentMeta(entity.name, document).title,
                ...(isTranslatable && {
                  locale: document.locale,
                  otherLocales: Object.keys(document._translations),
                }),
              }
            : undefined
        }
        onSuccess={() =>
          navigate({
            from: Route.fullPath,
            to: "..",
          })
        }
        onClose={() => setDeleteRequested(false)}
      />

      <Dialog open={discardRequested} onOpenChange={setDiscardRequested}>
        <Dialog.Content>
          <Dialog.Title>Discard draft?</Dialog.Title>
          <Dialog.Description>
            This permanently removes the pending edits on top of the published version. Cannot be
            undone.
          </Dialog.Description>
          <Dialog.Actions>
            <Button variant="outline" onClick={() => setDiscardRequested(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                setDiscardRequested(false);
                discardDraftMutation.mutate();
              }}
            >
              Discard
            </Button>
          </Dialog.Actions>
        </Dialog.Content>
      </Dialog>

      <ReferrersDrawer
        open={referrersOpen}
        onOpenChange={setReferrersOpen}
        entityName={entity.name}
        documentId={id}
      />
      {historyEnabled && (
        <HistoryDrawer
          open={historyOpen}
          onOpenChange={setHistoryOpen}
          entity={entity}
          documentId={id}
        />
      )}
    </>
  );
}

type DocumentHeaderProps = {
  entity: Entity;
  status?: "draft" | "published" | "modified";
};

const DocumentHeader = ({ entity, status }: DocumentHeaderProps) => {
  const { formData } = useDocumentForm();
  const meta = useMemo(() => resolveDocumentMeta(entity.name, formData), [entity, formData]);

  // "Modified" = published with pending draft on top — the most actionable state.
  const statusLabel =
    status === "published" ? "Published" : status === "modified" ? "Modified" : "Draft";
  const statusVariant =
    status === "published" ? "success" : status === "modified" ? "warning" : "neutral";

  return (
    <Layout.Header>
      {meta.media && <Layout.Media>{meta.media}</Layout.Media>}
      <div className="flex items-center gap-2">
        <Layout.Title>{meta.title || getEntityTitle(entity)}</Layout.Title>
        {status && (
          <Badge variant={statusVariant} size="sm">
            {statusLabel}
          </Badge>
        )}
      </div>
      <Layout.Description>{meta.description || " "}</Layout.Description>
    </Layout.Header>
  );
};
