import CMS_CONFIG from "virtual:cms-config";
import type { Entity } from "@cms/config";
import { Breadcrumbs, Button, Dropdown } from "@cms/ui";
import { CaretDownIcon, CheckIcon, TranslateIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import z from "zod";
import { DOCUMENT_FORM_ID, DocumentForm, useDocumentForm } from "@/components/forms/document-form";
import { PageLayout as Layout } from "@/components/layouts/page";
import { client } from "@/lib/client";
import { useKeyboardShortcut } from "@/lib/hooks/use-keyboard-shortcut";
import { invalidate } from "@/lib/queries/keys";
import type { Document } from "@/lib/schemas";
import { getEntityTitle } from "@/lib/utils/config";
import { resolveDocumentMeta } from "@/lib/utils/documents";
import { getLocaleLabel } from "@/lib/utils/i18n";

export const Route = createFileRoute("/_authenticated/entity/$name/new")({
  component: RouteComponent,
  // The list passes its active locale so "New" is born in the locale you were
  // scoped to. Invalid/absent falls back to the default below.
  validateSearch: z.object({ locale: z.string().optional() }),
});

const localeOptions = CMS_CONFIG.i18n.locales || [];

function resolveInitialLocale(locale: string | undefined): string {
  return locale && localeOptions.some((l) => l.value === locale)
    ? locale
    : CMS_CONFIG.i18n?.defaultLocale;
}

function RouteComponent() {
  const { entity } = Route.useRouteContext();
  const { locale: localeParam } = Route.useSearch();
  const queryClient = useQueryClient();
  const navigate = Route.useNavigate();

  const [locale, setLocale] = useState(() => resolveInitialLocale(localeParam));

  useKeyboardShortcut({ key: "s", mod: true }, () => {
    const form = window.document.getElementById(DOCUMENT_FORM_ID);
    if (form instanceof HTMLFormElement) form.requestSubmit();
  });

  const createMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.request<{ data: Document }>(`/${entity.name}`, {
        method: "POST",
        body: { ...data, locale },
      });

      return res.data;
    },
    onSuccess: (newDocument) => {
      invalidate.afterDocumentWrite(queryClient, { entity: entity.name, id: newDocument.id });

      navigate({
        to: "/entity/$name/$id",
        params: {
          name: entity.name,
          id: newDocument.id,
        },
      });
    },
  });

  return (
    <Layout>
      <Layout.Navbar>
        <Breadcrumbs className="mr-auto -ml-2">
          <Breadcrumbs.Item asChild>
            <Link from={Route.fullPath} to="..">
              {getEntityTitle(entity, { plural: true })}
            </Link>
          </Breadcrumbs.Item>
          <Breadcrumbs.Separator />
          <Breadcrumbs.Item disabled>New</Breadcrumbs.Item>
        </Breadcrumbs>

        {entity.translatable && (
          <Dropdown>
            <Dropdown.Trigger asChild>
              <Button variant="outline" size="xs">
                <TranslateIcon />
                {getLocaleLabel(locale)}
                <CaretDownIcon className="ml-2" />
              </Button>
            </Dropdown.Trigger>
            <Dropdown.Items>
              {localeOptions.map((localeOption) => {
                const isActive = localeOption.value === locale;

                return (
                  <Dropdown.Item
                    key={localeOption.value}
                    onSelect={() => setLocale(localeOption.value)}
                    disabled={isActive}
                  >
                    {localeOption.label}
                    {isActive && <CheckIcon className="ml-auto" />}
                  </Dropdown.Item>
                );
              })}
            </Dropdown.Items>
          </Dropdown>
        )}
      </Layout.Navbar>
      <DocumentForm
        key={locale}
        initialData={entity.translatable ? { locale } : undefined}
        fields={entity.fields}
        onSubmit={(data) => createMutation.mutateAsync(data)}
      >
        <DocumentForm.UnsavedChangesBlocker />
        <Layout.Container>
          <DocumentHeader entity={entity} />
          <DocumentForm.Fields entityName={entity.name} op="create" />
        </Layout.Container>

        <Layout.Actions className="justify-end">
          <DocumentForm.Submit size="sm">Create</DocumentForm.Submit>
        </Layout.Actions>
      </DocumentForm>
    </Layout>
  );
}

type DocumentHeaderProps = {
  entity: Entity;
};

const DocumentHeader = ({ entity }: DocumentHeaderProps) => {
  const { formData } = useDocumentForm();
  const meta = useMemo(() => resolveDocumentMeta(entity.name, formData), [entity, formData]);

  return (
    <Layout.Header>
      {meta.media && <Layout.Media>{meta.media}</Layout.Media>}
      <Layout.Title>{meta.title || "New Document"}</Layout.Title>
      <Layout.Description>{meta.description || " "}</Layout.Description>
    </Layout.Header>
  );
};
