import CMS_CONFIG from "virtual:cms-config";
import {
  type AnyEntity,
  type EntityAdminBuiltInColumn,
  type EntityAdminListColumn,
  getSearchFieldPaths,
} from "@cms/config";
import {
  Badge,
  Breadcrumbs,
  Button,
  Checkbox,
  EmptyState,
  IconButton,
  Input,
  Pagination,
  Select,
  Skeleton,
  Table,
  useDelayedLoading,
  usePagination,
} from "@cms/ui";
import {
  FileTextIcon,
  MagnifyingGlassIcon,
  PlusIcon,
  TranslateIcon,
  TrashIcon,
  XIcon,
} from "@phosphor-icons/react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  type ColumnDef,
  getCoreRowModel,
  type SortingState,
  useReactTable,
} from "@tanstack/react-table";
import {
  isValidElement,
  type ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import z from "zod";
import { BulkActionBar } from "@/components/bulk-action-bar";
import { DeleteDocumentDialog } from "@/components/forms/delete-document-dialog";
import { PageLayout as Layout } from "@/components/layouts/page";
import { ListLocaleSwitcher } from "@/components/list-locale-switcher";
import {
  getGroupedDocumentsQueryOptions,
  getMiniDocumentsQueryOptions,
  LIST_PAGE_SIZE,
  PAGE_SIZE_OPTIONS,
} from "@/lib/queries/documents";
import {
  type GroupedDocument,
  type ListStatus,
  listStatusSchema,
  type ResolvedEntity,
} from "@/lib/schemas";
import { getEntityTitle } from "@/lib/utils/config";
import { formatDate } from "@/lib/utils/dates";
import { buildSearchFilter, resolveDocumentMeta } from "@/lib/utils/documents";
import { withClickGuard } from "@/lib/utils/dom";
import { getLocaleLabel } from "@/lib/utils/i18n";

const I18N_LOCALES = CMS_CONFIG.i18n.locales ?? [];
const DEFAULT_LOCALE = CMS_CONFIG.i18n.defaultLocale;

/** One rows-per-page choice for every list table, kept in the browser. */
const PAGE_SIZE_STORAGE_KEY = "list-page-size";

/** The last rows-per-page choice, used when the URL carries no `pageSize`. */
function getSavedPageSize(): number {
  const saved = Number(localStorage.getItem(PAGE_SIZE_STORAGE_KEY));
  return PAGE_SIZE_OPTIONS.includes(saved) ? saved : LIST_PAGE_SIZE;
}

const searchSchema = z.object({
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce
    .number()
    .int()
    .refine((size) => PAGE_SIZE_OPTIONS.includes(size))
    .optional()
    .default(getSavedPageSize)
    .catch(getSavedPageSize),
  sort: z.string().optional(),
  order: z.enum(["asc", "desc"]).optional(),
  // Publication-status chip. `untranslated` is only meaningful in
  // group-collapse mode; the bare list treats it as "no filter".
  // `drafts` is the chip's old value, still parsed so saved links keep working.
  status: z
    .enum([...listStatusSchema.options, "drafts"])
    .optional()
    .transform((status) => (status === "drafts" ? "draft" : status)),
  // Active locale for group-collapse mode (scopes the whole list).
  locale: z.string().optional(),
  // Free-text search over the entity's text, slug and select columns.
  q: z.string().optional(),
});

/** A normalised list row, unifying the bare (one-row-per-locale) and
 *  group-collapsed (one-entry-per-`translationGroup`) shapes. */
type ListItem = {
  /** Selection key: `translationGroup` when grouped, else the row id. */
  key: string;
  /** Active-locale row id, or `null` for an untranslated placeholder. */
  id: string | null;
  /** Active-locale row data for column rendering, or `null` for a placeholder. */
  data: Record<string, unknown> | null;
  /** Representative sibling row used to label a placeholder (its columns are
   *  rendered muted so you can tell which document is untranslated). */
  fallback?: Record<string, unknown> | null;
  /** Per-locale presence + status (group-collapse mode only). */
  locales?: GroupedDocument["locales"];
  isPlaceholder: boolean;
};

/**
 * Translate the chip-level `status` URL param into a bare-list filter.
 * `publishedAt IS NOT NULL` means "currently published"; `IS NULL` means
 * "draft" (never published, or unpublished since). `untranslated` has no bare-list meaning → no filter.
 */
function statusFilter(status: ListStatus | undefined) {
  if (status === "live") return { publishedAt: { $exists: true } };
  if (status === "draft") return { publishedAt: { $exists: false } };
  return undefined;
}

/** The bare list's filter: the status chip and the search, both applied. */
function bareListFilter(entity: AnyEntity, status: ListStatus | undefined, q: string | undefined) {
  const filters = [statusFilter(status), buildSearchFilter(entity, q)].filter(
    (filter) => filter !== undefined,
  );
  return filters.length > 1 ? { $and: filters } : filters[0];
}

/** Group-collapse list applies to translatable entities once a project has
 *  more than one locale. Single-locale projects behave exactly as before. */
function isGroupedEntity(entity: AnyEntity): boolean {
  return !!entity.translatable && I18N_LOCALES.length > 1;
}

/**
 * The `status` the entity's list can filter by: Live/Draft need the draft workflow, and
 * Untranslated a grouped list. Any other (from an old URL, say) is ignored rather than leaving
 * the list filtered with no chip to reset it.
 */
function supportedStatus(
  entity: AnyEntity,
  status: ListStatus | undefined,
): ListStatus | undefined {
  if (status === "untranslated") return isGroupedEntity(entity) ? status : undefined;
  return entity.versions?.drafts ? status : undefined;
}

function resolveActiveLocale(locale: string | undefined): string {
  return locale && I18N_LOCALES.some((l) => l.value === locale) ? locale : DEFAULT_LOCALE;
}

function buildSortParam(
  sort: string | undefined,
  order: "asc" | "desc" | undefined,
): string | undefined {
  if (!sort) return undefined;
  return order === "desc" ? `-${sort}` : sort;
}

/** Bare-list locale column: the row's own locale + nav badges to siblings. */
function LocaleBadges({ data, entity }: { data: Record<string, unknown>; entity: AnyEntity }) {
  const translations = (data._translations ?? {}) as Record<string, { id: string }>;
  return (
    <div className="flex items-center gap-1.5 uppercase">
      <Badge size="xs" variant="info">
        {String(data.locale ?? "")}
      </Badge>
      {Object.entries(translations).map(([locale, translation]) => (
        <Badge
          key={locale}
          size="xs"
          className="hover:bg-foreground/2 active:bg-foreground/4"
          asChild
        >
          <Link to="/entity/$name/$id" params={{ name: entity.name, id: translation.id }}>
            {locale}
          </Link>
        </Badge>
      ))}
    </div>
  );
}

/**
 * Group-collapse locale column: one nav-only pip per configured locale.
 * Present locales link to that locale's edit view and carry a live/draft
 * status pip; absent locales render muted (non-navigable).
 */
function LocaleStatusPips({
  entity,
  locales,
  activeLocale,
}: {
  entity: AnyEntity;
  locales: GroupedDocument["locales"];
  activeLocale: string;
}) {
  return (
    <div className="flex items-center gap-1.5 uppercase">
      {I18N_LOCALES.map((locale) => {
        const info = locales[locale.value];
        const isActive = locale.value === activeLocale;
        if (!info) {
          return (
            <Badge key={locale.value} size="xs" variant="neutral" className="text-foreground/30">
              {locale.value}
            </Badge>
          );
        }
        return (
          <Badge
            key={locale.value}
            size="xs"
            variant={info.status === "live" ? "success" : "warning"}
            className="transition hover:ring-2 data-[active]:ring-2"
            data-active={isActive || undefined}
            asChild
          >
            <Link to="/entity/$name/$id" params={{ name: entity.name, id: info.id }}>
              <Badge.Status />
              {locale.value}
            </Link>
          </Badge>
        );
      })}
    </div>
  );
}

function renderListColumn(
  col: EntityAdminBuiltInColumn | EntityAdminListColumn<unknown>,
  data: Record<string, unknown>,
) {
  if (col === "createdAt")
    return <span className="whitespace-nowrap">{formatDate(data.createdAt as string)}</span>;
  if (col === "updatedAt")
    return <span className="whitespace-nowrap">{formatDate(data.updatedAt as string)}</span>;
  if (col === "locales") return null; // handled at the row level (mode-aware)
  const result = col.render({ data: data as ResolvedEntity<string>, utils: { formatDate } });
  if (isValidElement(result) && result.type === "img") {
    return (
      <figure className="size-8 flex items-center justify-center bg-foreground/4 rounded-sm overflow-hidden [&_img]:size-full *:object-cover">
        {result}
      </figure>
    );
  }
  return result;
}

/** Delay between the last keystroke and the search reaching the URL. */
const SEARCH_DEBOUNCE_MS = 300;

/**
 * The list's search box. Typing is local and reaches the URL's `q` after a
 * pause; a `q` changed from elsewhere (back button, "Clear search") is
 * adopted unless it is just the trimmed form of what's typed.
 */
function ListSearch({ label }: { label: string }) {
  const navigate = Route.useNavigate();
  const { q } = Route.useSearch();
  const [draft, setDraft] = useState(q ?? "");
  const [adoptedQ, setAdoptedQ] = useState(q);

  if (q !== adoptedQ) {
    setAdoptedQ(q);
    if ((q ?? "") !== draft.trim()) setDraft(q ?? "");
  }

  const commit = useCallback(
    (next: string) => {
      const nextQ = next.trim() || undefined;
      navigate({ search: (prev) => ({ ...prev, q: nextQ, page: 1 }), replace: true });
    },
    [navigate],
  );

  // biome-ignore lint/correctness/useExhaustiveDependencies: only a typed change commits
  useEffect(() => {
    if ((draft.trim() || undefined) === q) return;
    const timer = setTimeout(() => commit(draft), SEARCH_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [draft]);

  const clear = () => {
    setDraft("");
    commit("");
  };

  return (
    <Input.Group className="w-full sm:w-64">
      <Input.Addon>
        <MagnifyingGlassIcon size={14} className="text-foreground-secondary" />
      </Input.Addon>
      <Input
        type="search"
        aria-label={`Search ${label}`}
        placeholder="Search…"
        value={draft}
        onChange={(event) => setDraft(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === "Escape" && draft) {
            event.stopPropagation();
            clear();
          }
        }}
      />
      {draft && (
        <Input.Addon asChild>
          <button
            type="button"
            aria-label="Clear search"
            className="pointer-events-auto cursor-pointer rounded-sm text-foreground-secondary transition-colors hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring"
            onClick={clear}
          >
            <XIcon size={14} />
          </button>
        </Input.Addon>
      )}
    </Input.Group>
  );
}

export const Route = createFileRoute("/_authenticated/entity/$name/")({
  component: RouteComponent,
  validateSearch: searchSchema,
  loaderDeps: ({ search }) => ({
    page: search.page,
    pageSize: search.pageSize,
    sort: search.sort,
    order: search.order,
    status: search.status,
    locale: search.locale,
    q: search.q,
  }),
  loader: async ({
    context: { entity, queryClient },
    deps: { page, pageSize, sort, order, status: requestedStatus, locale, q },
  }) => {
    const status = supportedStatus(entity, requestedStatus);
    const defaultSort = entity.admin?.list?.defaultSort;
    const effectiveSort = sort ?? defaultSort?.field;
    const effectiveOrder = sort ? order : (defaultSort?.order ?? order);
    const sortParam = buildSortParam(effectiveSort, effectiveOrder);

    if (isGroupedEntity(entity)) {
      await queryClient.ensureQueryData(
        getGroupedDocumentsQueryOptions(entity.name, {
          page,
          pageSize,
          sort: sortParam,
          locale: resolveActiveLocale(locale),
          status,
          filter: buildSearchFilter(entity, q),
        }),
      );
      return;
    }

    await queryClient.ensureQueryData(
      getMiniDocumentsQueryOptions(entity.name, {
        page,
        pageSize,
        sort: sortParam,
        filter: bareListFilter(entity, status, q),
      }),
    );
  },
});

function RouteComponent() {
  const navigate = Route.useNavigate();
  const { entity } = Route.useRouteContext();
  const { page, pageSize, sort, order, status: requestedStatus, locale, q } = Route.useSearch();
  const status = supportedStatus(entity, requestedStatus);
  const draftsEnabled = entity.versions?.drafts ?? false;
  const grouped = isGroupedEntity(entity);
  const activeLocale = resolveActiveLocale(locale);

  const defaultSort = entity.admin?.list?.defaultSort;
  const effectiveSort = sort ?? defaultSort?.field;
  const effectiveOrder = sort ? order : (defaultSort?.order ?? order);
  const sortParam = buildSortParam(effectiveSort, effectiveOrder);
  const searchable = getSearchFieldPaths(entity.fields).length > 0;
  const groupedFilter = buildSearchFilter(entity, q);
  const bareFilter = bareListFilter(entity, status, q);

  const groupedQuery = useQuery({
    ...getGroupedDocumentsQueryOptions(entity.name, {
      page,
      pageSize,
      sort: sortParam,
      locale: activeLocale,
      status,
      filter: groupedFilter,
    }),
    enabled: grouped,
  });

  const miniQuery = useQuery({
    ...getMiniDocumentsQueryOptions(entity.name, {
      page,
      pageSize,
      sort: sortParam,
      filter: bareFilter,
    }),
    enabled: !grouped,
  });

  const isFetching = grouped ? groupedQuery.isFetching : miniQuery.isFetching;
  const showFetching = useDelayedLoading(isFetching);

  const meta = grouped ? groupedQuery.data?.meta : miniQuery.data?.meta;
  const pageCount = Math.max(1, Math.ceil((meta?.total ?? 0) / pageSize));

  // Normalise both response shapes into a single item list.
  const items = useMemo<ListItem[]>(() => {
    if (grouped) {
      return (groupedQuery.data?.data ?? []).map((group) => ({
        key: group.translationGroup,
        id: group.row?.id ?? null,
        data: group.row,
        fallback: group.fallback,
        locales: group.locales,
        isPlaceholder: !group.row,
      }));
    }
    return (miniQuery.data?.data ?? []).map((row) => ({
      key: row.id,
      id: row.id,
      data: row,
      isPlaceholder: false,
    }));
  }, [grouped, groupedQuery.data, miniQuery.data]);

  const [documentToDelete, setDocumentToDelete] = useState<null | {
    id: string;
    title: ReactNode;
    locale?: string;
    otherLocales?: string[];
  }>(null);

  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());
  const [lastSelectedIndex, setLastSelectedIndex] = useState<number | null>(null);
  const [selectAllLoading, setSelectAllLoading] = useState(false);
  // True once the user has selected every selectable document across all pages
  // (via the banner). Tracked explicitly because the selected count can be < the
  // document total when untranslated placeholders are present.
  const [selectedAllPages, setSelectedAllPages] = useState(false);
  const pendingShiftRef = useRef(false);
  // Cache items across pages so cross-page selection survives pagination.
  const itemCache = useRef<Map<string, ListItem>>(new Map());
  const queryClient = useQueryClient();

  // Only non-placeholder rows are selectable.
  const selectableKeys = useMemo(
    () => items.filter((item) => !item.isPlaceholder).map((item) => item.key),
    [items],
  );
  const allSelected =
    selectableKeys.length > 0 && selectableKeys.every((key) => selectedKeys.has(key));
  const someSelected = !allSelected && selectedKeys.size > 0;

  const clearSelection = useCallback(() => {
    setSelectedKeys(new Set());
    setLastSelectedIndex(null);
    setSelectedAllPages(false);
  }, []);

  // Reset selection when the active locale changes — selection keys (and the
  // active-locale row ids they map to) are locale-scoped — or when the search
  // changes, so "all documents selected" never outlives the result set it meant.
  // biome-ignore lint/correctness/useExhaustiveDependencies: reset on locale or search switch
  useEffect(() => {
    clearSelection();
  }, [activeLocale, q, clearSelection]);

  const toggleSelectAll = () => {
    if (allSelected) {
      clearSelection();
    } else {
      setSelectedKeys(new Set(selectableKeys));
      setLastSelectedIndex(null);
      setSelectedAllPages(false);
    }
  };

  const toggleSelect = (key: string, index: number, shiftKey = false) => {
    setSelectedAllPages(false);
    if (shiftKey && lastSelectedIndex !== null) {
      const start = Math.min(lastSelectedIndex, index);
      const end = Math.max(lastSelectedIndex, index);
      const rangeKeys = items
        .slice(start, end + 1)
        .filter((item) => !item.isPlaceholder)
        .map((item) => item.key);
      const selecting = !selectedKeys.has(key);
      setSelectedKeys((prev) => {
        const next = new Set(prev);
        for (const rangeKey of rangeKeys) {
          if (selecting) next.add(rangeKey);
          else next.delete(rangeKey);
        }
        return next;
      });
    } else {
      setSelectedKeys((prev) => {
        const next = new Set(prev);
        if (next.has(key)) next.delete(key);
        else next.add(key);
        return next;
      });
      setLastSelectedIndex(index);
    }
  };

  // Escape clears selection
  useEffect(() => {
    if (selectedKeys.size === 0) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") clearSelection();
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [selectedKeys.size, clearSelection]);

  useEffect(() => {
    for (const item of items) itemCache.current.set(item.key, item);
  }, [items]);

  // The bulk bar always operates on active-locale row ids: in group-collapse
  // mode each selected group resolves to its active-locale row, so publish /
  // unpublish / delete act on the locale you're looking at (placeholders are
  // never selectable, so the selection never carries one).
  const selectedItems = Array.from(selectedKeys)
    .map((key) => itemCache.current.get(key))
    .filter((item): item is ListItem => item !== undefined && !item.isPlaceholder && !!item.id);
  const selectedActiveIds = new Set(selectedItems.map((item) => item.id as string));
  const selectedDocuments = selectedItems.map((item) => ({
    id: item.id as string,
    ...(item.data ?? {}),
  }));
  const selectedLocales = selectedItems.map((item) => Object.keys(item.locales ?? {}));
  const localeScope = grouped
    ? {
        locale: activeLocale,
        locales: [...new Set([activeLocale, ...selectedLocales.flat()])],
        translatedCount: selectedLocales.filter((locales) =>
          locales.some((locale) => locale !== activeLocale),
        ).length,
      }
    : undefined;

  // Select every selectable document across all pages. In group-collapse mode
  // untranslated placeholders are skipped (they aren't selectable), so the
  // selected count can be smaller than `meta.total` — `selectedAllPages` tracks
  // the "all selected" state instead of comparing counts.
  const selectAllDocuments = async () => {
    if (!meta) return;
    setSelectAllLoading(true);
    try {
      let allKeys: string[];
      if (grouped) {
        const result = await queryClient.fetchQuery(
          getGroupedDocumentsQueryOptions(entity.name, {
            sort: sortParam,
            locale: activeLocale,
            status,
            filter: groupedFilter,
            limitOverride: meta.total,
          }),
        );
        const groupItems: ListItem[] = result.data.map((group) => ({
          key: group.translationGroup,
          id: group.row?.id ?? null,
          data: group.row,
          fallback: group.fallback,
          locales: group.locales,
          isPlaceholder: !group.row,
        }));
        for (const item of groupItems) itemCache.current.set(item.key, item);
        allKeys = groupItems.filter((item) => !item.isPlaceholder).map((item) => item.key);
      } else {
        const result = await queryClient.fetchQuery(
          getMiniDocumentsQueryOptions(entity.name, {
            sort: sortParam,
            filter: bareFilter,
            limitOverride: meta.total,
          }),
        );
        for (const row of result.data) {
          itemCache.current.set(row.id, {
            key: row.id,
            id: row.id,
            data: row,
            isPlaceholder: false,
          });
        }
        allKeys = result.data.map((row) => row.id);
      }
      setSelectedKeys(new Set(allKeys));
      setSelectedAllPages(true);
    } finally {
      setSelectAllLoading(false);
    }
  };

  // Create the active-locale translation for an untranslated placeholder,
  // sourcing from the default locale if present, else the first sibling.
  const createTranslation = (item: ListItem) => {
    const locales = item.locales ?? {};
    const sourceId = locales[DEFAULT_LOCALE]?.id ?? Object.values(locales)[0]?.id;
    if (!sourceId) return;
    navigate({
      to: "/entity/$name/translate/$id/$locale",
      params: { name: entity.name, id: sourceId, locale: activeLocale },
    });
  };

  const listColumns = entity.admin?.list?.columns;

  const columnDefs = useMemo<ColumnDef<ListItem>[]>(() => {
    if (!listColumns) return [];
    return listColumns.map((col, index) => {
      if (col === "createdAt") return { id: "createdAt", header: "Created", enableSorting: true };
      if (col === "updatedAt") return { id: "updatedAt", header: "Updated", enableSorting: true };
      if (col === "locales") return { id: `col_${index}`, header: "Locales", enableSorting: false };
      return {
        id: col.sortKey ?? `col_${index}`,
        header: col.label,
        enableSorting: !!col.sortKey,
      };
    });
  }, [listColumns]);

  const sorting: SortingState = sort ? [{ id: sort, desc: order === "desc" }] : [];

  const table = useReactTable({
    data: items,
    columns: columnDefs,
    state: { sorting },
    onSortingChange: (updater) => {
      const next = typeof updater === "function" ? updater(sorting) : updater;
      const first = next[0];
      navigate({
        search: (prev) => ({
          ...prev,
          page: 1,
          sort: first?.id,
          order: first?.desc ? "desc" : undefined,
        }),
      });
    },
    manualSorting: true,
    manualPagination: true,
    pageCount,
    getCoreRowModel: getCoreRowModel(),
  });

  const paginationItems = usePagination({ page, count: pageCount });

  // The column cells, shared by real and placeholder rows. Placeholders render
  // from the fallback sibling row so the document stays identifiable; the
  // locales column always shows the pips (the active locale reads as absent).
  const renderCells = (item: ListItem, displayData: Record<string, unknown>) => {
    const localesCell =
      grouped && item.locales ? (
        <LocaleStatusPips entity={entity} locales={item.locales} activeLocale={activeLocale} />
      ) : (
        <LocaleBadges data={displayData} entity={entity} />
      );

    if (listColumns) {
      return listColumns.map((col, colIndex) => (
        <Table.Cell
          key={col === "createdAt" || col === "updatedAt" || col === "locales" ? col : colIndex}
        >
          {col === "locales" ? localesCell : renderListColumn(col, displayData)}
        </Table.Cell>
      ));
    }

    const docMeta = resolveDocumentMeta(entity.name, displayData);
    return (
      <>
        <Table.Cell>
          <figure className="flex items-center justify-center bg-foreground/2 rounded-sm aspect-square overflow-hidden max-w-8 w-full *:object-cover [&_img]:size-full">
            {docMeta.media}
          </figure>
        </Table.Cell>
        <Table.Cell className="max-w-48 truncate">{docMeta.title}</Table.Cell>
        <Table.Cell className="max-w-64 truncate">{docMeta.description || "—"}</Table.Cell>
        {entity.translatable && <Table.Cell>{localesCell}</Table.Cell>}
        <Table.Cell>{formatDate(displayData.createdAt as string)}</Table.Cell>
        <Table.Cell>{formatDate(displayData.updatedAt as string)}</Table.Cell>
      </>
    );
  };

  const renderRow = (item: ListItem, index: number) => {
    const isSelected = selectedKeys.has(item.key);

    if (item.isPlaceholder) {
      const displayData = item.fallback ?? {};
      return (
        <Table.Row
          key={item.key}
          tabIndex={0}
          data-placeholder
          // Muted: this is a sibling locale shown only to identify the document
          // that has no row in the active locale.
          className="cursor-pointer text-foreground/40"
          onClick={() => createTranslation(item)}
        >
          <Table.Cell>
            <Checkbox aria-label="Untranslated — not selectable" checked={false} disabled />
          </Table.Cell>
          {renderCells(item, displayData)}
          <Table.Cell className="w-6">
            <IconButton
              variant="ghost"
              size="sm"
              aria-label={`Create ${getLocaleLabel(activeLocale)} translation`}
              className="text-foreground"
              onClick={(event) => {
                event.stopPropagation();
                createTranslation(item);
              }}
            >
              <TranslateIcon />
            </IconButton>
          </Table.Cell>
        </Table.Row>
      );
    }

    const data = item.data as Record<string, unknown>;

    return (
      <Table.Row
        key={item.key}
        tabIndex={0}
        data-selected={isSelected || undefined}
        onClick={withClickGuard(() =>
          navigate({
            to: "/entity/$name/$id",
            params: { name: entity.name, id: item.id as string },
          }),
        )}
      >
        <Table.Cell>
          <Checkbox
            aria-label={`Select ${item.id}`}
            checked={isSelected}
            onMouseDown={(event) => {
              pendingShiftRef.current = event.shiftKey;
            }}
            onChange={() => {
              toggleSelect(item.key, index, pendingShiftRef.current);
              pendingShiftRef.current = false;
            }}
          />
        </Table.Cell>

        {renderCells(item, data)}

        <Table.Cell className="w-6">
          <IconButton
            variant="ghost"
            size="sm"
            aria-label="Delete"
            onClick={() => {
              // Group-collapse: the dialog offers the active locale only or the whole
              // translation group. Bare list: single-locale projects have no siblings.
              setDocumentToDelete({
                id: item.id as string,
                title: resolveDocumentMeta(entity.name, data).title,
                ...(grouped && {
                  locale: activeLocale,
                  otherLocales: Object.keys(item.locales ?? {}).filter(
                    (locale) => locale !== activeLocale,
                  ),
                }),
              });
            }}
          >
            <TrashIcon />
          </IconButton>
        </Table.Cell>
      </Table.Row>
    );
  };

  return (
    <>
      <Layout>
        <Layout.Navbar>
          <Breadcrumbs className="-ml-2">
            <Breadcrumbs.Item asChild>
              <Link to="/entity/$name" params={{ name: entity.name }}>
                {getEntityTitle(entity, { plural: true })}
              </Link>
            </Breadcrumbs.Item>
          </Breadcrumbs>
        </Layout.Navbar>
        <Layout.Container>
          <Layout.Header className="flex items-end justify-between">
            <div>
              <Layout.Title>{getEntityTitle(entity, { plural: true })}</Layout.Title>
              {entity.description && (
                <p className="mt-1 text-sm text-foreground-secondary">{entity.description}</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              {grouped && (
                <ListLocaleSwitcher
                  activeLocale={activeLocale}
                  onSelect={(next) =>
                    navigate({ search: (prev) => ({ ...prev, locale: next, page: 1 }) })
                  }
                />
              )}
              <Button asChild>
                <Link
                  from={Route.fullPath}
                  to="./new"
                  search={grouped ? { locale: activeLocale } : undefined}
                >
                  <PlusIcon />
                  Create
                </Link>
              </Button>
            </div>
          </Layout.Header>

          {(draftsEnabled || grouped || searchable) && (
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              {(draftsEnabled || grouped) && (
                <nav className="flex gap-2" aria-label="Filter by status">
                  <Button asChild variant={status === undefined ? "primary" : "outline"} size="sm">
                    <Link
                      from={Route.fullPath}
                      search={(prev) => ({ ...prev, status: undefined, page: 1 })}
                    >
                      All
                    </Link>
                  </Button>
                  {draftsEnabled && (
                    <>
                      <Button asChild variant={status === "live" ? "primary" : "outline"} size="sm">
                        <Link
                          from={Route.fullPath}
                          search={(prev) => ({ ...prev, status: "live", page: 1 })}
                        >
                          Live
                        </Link>
                      </Button>
                      <Button
                        asChild
                        variant={status === "draft" ? "primary" : "outline"}
                        size="sm"
                      >
                        <Link
                          from={Route.fullPath}
                          search={(prev) => ({ ...prev, status: "draft", page: 1 })}
                        >
                          Unpublished
                        </Link>
                      </Button>
                    </>
                  )}
                  {grouped && (
                    <Button
                      asChild
                      variant={status === "untranslated" ? "primary" : "outline"}
                      size="sm"
                    >
                      <Link
                        from={Route.fullPath}
                        search={(prev) => ({ ...prev, status: "untranslated", page: 1 })}
                      >
                        Untranslated
                      </Link>
                    </Button>
                  )}
                </nav>
              )}
              {searchable && (
                <ListSearch
                  key={entity.name}
                  label={getEntityTitle(entity, { plural: true }).toLowerCase()}
                />
              )}
            </div>
          )}

          <Table>
            <Table.Caption className="sr-only">
              {getEntityTitle(entity, { plural: true })} list
            </Table.Caption>
            <Table.Header>
              <Table.Row>
                <Table.Head className="w-8">
                  <Checkbox
                    aria-label="Select all"
                    checked={allSelected}
                    indeterminate={!allSelected && someSelected}
                    onChange={toggleSelectAll}
                  />
                </Table.Head>
                {listColumns ? (
                  table.getHeaderGroups().map((headerGroup) =>
                    headerGroup.headers.map((header) => {
                      const canSort = header.column.columnDef.enableSorting === true;
                      const sortState = header.column.getIsSorted();
                      if (canSort) {
                        return (
                          <Table.SortableHead
                            key={header.id}
                            sort={sortState === false ? false : sortState}
                            onSort={() => header.column.toggleSorting()}
                          >
                            {String(header.column.columnDef.header ?? "")}
                          </Table.SortableHead>
                        );
                      }
                      return (
                        <Table.Head key={header.id}>
                          {String(header.column.columnDef.header ?? "")}
                        </Table.Head>
                      );
                    }),
                  )
                ) : (
                  <>
                    <Table.Head>Media</Table.Head>
                    <Table.Head>Title</Table.Head>
                    <Table.Head>Description</Table.Head>
                    {entity.translatable && <Table.Head>Locales</Table.Head>}
                    <Table.Head>Created</Table.Head>
                    <Table.Head>Updated</Table.Head>
                  </>
                )}
                <Table.Head className="hidden">Delete</Table.Head>
              </Table.Row>
              {allSelected && meta && meta.total > items.length && (
                <Table.Row>
                  <Table.Head
                    colSpan={99}
                    className="bg-info/5 text-info py-2 text-xs font-normal text-center"
                  >
                    {selectedAllPages ? (
                      <>
                        All {selectedKeys.size} documents selected.{" "}
                        <button
                          type="button"
                          className="underline cursor-pointer"
                          onClick={clearSelection}
                        >
                          Clear selection
                        </button>
                      </>
                    ) : (
                      <>
                        All {selectableKeys.length} on this page selected.{" "}
                        <button
                          type="button"
                          className="underline cursor-pointer disabled:opacity-50"
                          disabled={selectAllLoading}
                          onClick={selectAllDocuments}
                        >
                          Select all {meta.total} documents
                        </button>
                      </>
                    )}
                  </Table.Head>
                </Table.Row>
              )}
            </Table.Header>
            <Table.Body>
              {showFetching ? (
                Array.from({ length: pageSize }).map((_, index) => (
                  <Table.Row key={index}>
                    <Table.Cell colSpan={99}>
                      <Skeleton className="h-4" />
                    </Table.Cell>
                  </Table.Row>
                ))
              ) : items.length === 0 && q ? (
                <Table.Row>
                  <Table.Cell colSpan={99} className="p-0">
                    <EmptyState className="border-none">
                      <EmptyState.Icon>
                        <MagnifyingGlassIcon />
                      </EmptyState.Icon>
                      <EmptyState.Title>No results for “{q}”</EmptyState.Title>
                      <EmptyState.Description>
                        Try a different search, or clear it to see every document.
                      </EmptyState.Description>
                      <EmptyState.Actions>
                        <Button asChild size="sm" variant="outline">
                          <Link
                            from={Route.fullPath}
                            search={(prev) => ({ ...prev, q: undefined, page: 1 })}
                          >
                            Clear search
                          </Link>
                        </Button>
                      </EmptyState.Actions>
                    </EmptyState>
                  </Table.Cell>
                </Table.Row>
              ) : items.length === 0 ? (
                <Table.Row>
                  <Table.Cell colSpan={99} className="p-0">
                    <EmptyState className="border-none">
                      <EmptyState.Icon>
                        <FileTextIcon />
                      </EmptyState.Icon>
                      <EmptyState.Title>
                        No {getEntityTitle(entity, { plural: true }).toLowerCase()} yet
                      </EmptyState.Title>
                      <EmptyState.Description>
                        Create the first one to see it here.
                      </EmptyState.Description>
                      <EmptyState.Actions>
                        <Button asChild size="sm">
                          <Link
                            from={Route.fullPath}
                            to="./new"
                            search={grouped ? { locale: activeLocale } : undefined}
                          >
                            <PlusIcon />
                            Create
                          </Link>
                        </Button>
                      </EmptyState.Actions>
                    </EmptyState>
                  </Table.Cell>
                </Table.Row>
              ) : (
                items.map((item, index) => renderRow(item, index))
              )}
            </Table.Body>
          </Table>

          <div className="flex items-center justify-between gap-4 mt-2">
            <div className="flex items-center gap-3">
              <p className="text-foreground-secondary text-sm">
                {selectedKeys.size > 0
                  ? `${selectedKeys.size} of ${meta?.total ?? items.length} selected`
                  : `${meta?.total ?? items.length} document${(meta?.total ?? items.length) !== 1 ? "s" : ""}`}
              </p>

              {meta && meta.total > Math.min(...PAGE_SIZE_OPTIONS) && (
                <label
                  htmlFor="page-size"
                  className="flex items-center gap-2 text-foreground-secondary text-sm"
                >
                  Rows per page
                  <Select
                    id="page-size"
                    size="xs"
                    variant="minimal"
                    className="w-auto"
                    value={pageSize}
                    onChange={(event) => {
                      localStorage.setItem(PAGE_SIZE_STORAGE_KEY, event.target.value);
                      navigate({
                        search: (prev) => ({
                          ...prev,
                          pageSize: Number(event.target.value),
                          page: 1,
                        }),
                      });
                    }}
                  >
                    {PAGE_SIZE_OPTIONS.map((size) => (
                      <option key={size} value={size}>
                        {size}
                      </option>
                    ))}
                  </Select>
                </label>
              )}
            </div>

            {meta && meta.total > pageSize && (
              <Pagination className="w-auto">
                <Pagination.List>
                  <Pagination.Item>
                    <Pagination.Previous
                      onClick={() => navigate({ search: (prev) => ({ ...prev, page: page - 1 }) })}
                      disabled={page === 1}
                    />
                  </Pagination.Item>
                  {paginationItems.map((item) =>
                    item.type === "page" ? (
                      <Pagination.Item key={item.key}>
                        <Pagination.Link
                          isActive={item.selected}
                          onClick={() =>
                            navigate({ search: (prev) => ({ ...prev, page: item.value }) })
                          }
                        >
                          {item.value}
                        </Pagination.Link>
                      </Pagination.Item>
                    ) : (
                      <Pagination.Item key={item.key}>
                        <Pagination.Ellipsis />
                      </Pagination.Item>
                    ),
                  )}
                  <Pagination.Item>
                    <Pagination.Next
                      onClick={() => navigate({ search: (prev) => ({ ...prev, page: page + 1 }) })}
                      disabled={page === pageCount}
                    />
                  </Pagination.Item>
                </Pagination.List>
              </Pagination>
            )}
          </div>
        </Layout.Container>
      </Layout>

      <BulkActionBar
        entity={entity}
        selectedIds={selectedActiveIds}
        selectedDocuments={selectedDocuments}
        clearSelection={clearSelection}
        localeScope={localeScope}
      />

      <DeleteDocumentDialog
        document={documentToDelete ? { ...documentToDelete, entity: entity.name } : undefined}
        onSuccess={() => setDocumentToDelete(null)}
        onClose={() => setDocumentToDelete(null)}
      />
    </>
  );
}
