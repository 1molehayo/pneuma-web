import { Badge, Breadcrumbs } from "@cms/ui";
import { TranslateIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { DOCUMENT_FORM_ID, DocumentForm, useDocumentForm } from "@/components/forms/document-form";
import { PageLayout as Layout } from "@/components/layouts/page";
import { client } from "@/lib/client";
import { useFieldPermissions } from "@/lib/hooks/use-field-permissions";
import { useKeyboardShortcut } from "@/lib/hooks/use-keyboard-shortcut";
import { useTranslationWarningsToast } from "@/lib/hooks/use-translation-warnings-toast";
import { invalidate } from "@/lib/queries/keys";
import type { Document } from "@/lib/schemas";
import { getEntityTitle } from "@/lib/utils/config";
import { resolveDocumentMeta } from "@/lib/utils/documents";
import { getLocaleLabel, withoutHiddenSharedFields } from "@/lib/utils/i18n";

/**
 * Translate a document: the engine prepares the copy (nothing is saved), the editor reviews it in
 * a create form with the locale fixed, and saving creates it as the source's translation.
 */
export const Route = createFileRoute("/_authenticated/entity/$name/translate/$id/$locale")({
  component: RouteComponent,
  loader: ({ params: { name, id, locale } }) =>
    client.request<{ data: Record<string, unknown>; warnings: string[] }>(
      `/${name}/${id}/translate?locale=${encodeURIComponent(locale)}`,
    ),
});

function RouteComponent() {
  const { entity } = Route.useRouteContext();
  const { id, locale } = Route.useParams();
  const { data, warnings } = Route.useLoaderData();
  const queryClient = useQueryClient();
  const navigate = Route.useNavigate();
  const { hiddenFields } = useFieldPermissions(entity.name, "create");

  useTranslationWarningsToast(warnings);

  useKeyboardShortcut({ key: "s", mod: true }, () => {
    const form = window.document.getElementById(DOCUMENT_FORM_ID);
    if (form instanceof HTMLFormElement) form.requestSubmit();
  });

  const createMutation = useMutation({
    mutationFn: async (formData: Record<string, unknown>) => {
      const response = await client.request<{ data: Document }>(`/${entity.name}`, {
        method: "POST",
        body: {
          ...withoutHiddenSharedFields(formData, entity.fields, hiddenFields),
          locale,
          translationOf: id,
        },
      });
      return response.data;
    },
    onSuccess: (translation) => {
      invalidate.afterDocumentWrite(queryClient, { entity: entity.name, id: id });
      navigate({
        to: "/entity/$name/$id",
        params: { name: entity.name, id: translation.id },
        replace: true,
        // Saved: nothing is left to lose, though the form is still dirty while `mutateAsync` settles.
        ignoreBlocker: true,
      });
    },
  });

  return (
    <Layout>
      <Layout.Navbar>
        <Breadcrumbs className="mr-auto -ml-2">
          <Breadcrumbs.Item asChild>
            <Link to="/entity/$name" params={{ name: entity.name }}>
              {getEntityTitle(entity, { plural: true })}
            </Link>
          </Breadcrumbs.Item>
          <Breadcrumbs.Separator />
          <Breadcrumbs.Item disabled>Translate</Breadcrumbs.Item>
        </Breadcrumbs>
        <Badge variant="neutral" size="sm">
          <TranslateIcon />
          {getLocaleLabel(locale)}
        </Badge>
      </Layout.Navbar>
      <DocumentForm
        initialData={data}
        fields={entity.fields}
        onSubmit={(formData) => createMutation.mutateAsync(formData)}
      >
        <DocumentForm.UnsavedChangesBlocker />
        <Layout.Container>
          <TranslationHeader />
          <DocumentForm.Fields entityName={entity.name} op="create" />
        </Layout.Container>

        <Layout.Actions className="justify-end">
          <DocumentForm.Submit size="sm">Create translation</DocumentForm.Submit>
        </Layout.Actions>
      </DocumentForm>
    </Layout>
  );
}

const TranslationHeader = () => {
  const { entity } = Route.useRouteContext();
  const { formData } = useDocumentForm();
  const meta = resolveDocumentMeta(entity.name, formData);

  return (
    <Layout.Header>
      {meta.media && <Layout.Media>{meta.media}</Layout.Media>}
      <Layout.Title>{meta.title || "New Translation"}</Layout.Title>
      <Layout.Description>{meta.description || " "}</Layout.Description>
    </Layout.Header>
  );
};
