import CMS_CONFIG from "virtual:cms-config";
import { createFileRoute, notFound } from "@tanstack/react-router";
import { AdminPage } from "@/components/admin-page";
import { canOpenPage, findAdminPage } from "@/lib/utils/sidebar";

export const Route = createFileRoute("/_authenticated/custom/$")({
  component: RouteComponent,
  beforeLoad: ({ params, context: { me } }) => {
    const page = findAdminPage(CMS_CONFIG, { path: params._splat ?? "" });
    const role = CMS_CONFIG.roles.find((r) => r.name === me.role);
    if (!page || !role || !canOpenPage(page, role)) throw notFound();
    return { page };
  },
});

function RouteComponent() {
  const { page } = Route.useRouteContext();
  return <AdminPage page={page} />;
}
