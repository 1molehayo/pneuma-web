import CMS_CONFIG from "virtual:cms-config";
import { Badge, Button, EmptyState, Table } from "@cms/ui";
import { ClockClockwiseIcon } from "@phosphor-icons/react";
import { queryOptions, useQueries } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { DashboardWidgets } from "@/components/dashboard-widgets";
import { PageLayout as Layout } from "@/components/layouts/page";
import { client } from "@/lib/client";
import { keys } from "@/lib/queries/keys";
import type { Document } from "@/lib/schemas";
import { isGlobalEntity, isInternalEntity, resolveEntityTitle } from "@/lib/utils/config";
import { formatDate } from "@/lib/utils/dates";
import { resolveDocumentMeta } from "@/lib/utils/documents";
import { withClickGuard } from "@/lib/utils/dom";

// Globals have no document list: `client.list` returns null for them, which crashed their
// "recent documents" queries on every dashboard load. Plugin entities live in their plugin's
// sidebar group, so they stay out of the project's recent activity too.
const PLUGIN_ENTITY_NAMES = new Set(
  CMS_CONFIG.plugins.flatMap((plugin) => (plugin.entities ?? []).map((e) => e.name)),
);
const USER_ENTITIES = CMS_CONFIG.entities.filter(
  (e) => !isInternalEntity(e) && !isGlobalEntity(e) && !PLUGIN_ENTITY_NAMES.has(e.name),
);
const CustomDashboard = CMS_CONFIG.admin?.dashboard;
const hasI18n = CMS_CONFIG.i18n.locales.length > 0;

const getRecentDocumentsQueryOptions = (entityName: string) => {
  return queryOptions({
    queryKey: keys.recentDocuments(entityName),
    queryFn: async ({ signal }) => {
      const { data } = await client.list(entityName, {
        limit: 5,
        sort: "-updatedAt",
        signal,
      });
      return data as Document[];
    },
  });
};

export const Route = createFileRoute("/_authenticated/")({
  component: () => {
    if (CustomDashboard) {
      return <CustomDashboard />;
    }

    return <RouteComponent />;
  },
});

function RouteComponent() {
  const navigate = useNavigate();

  const recentQueries = useQueries({
    queries: USER_ENTITIES.map((e) => getRecentDocumentsQueryOptions(e.name)),
  });

  const isLoading = recentQueries.some((q) => q.isPending);
  const recentDocuments = recentQueries
    .flatMap((q, i) =>
      (q.data ?? []).map((doc) => ({ ...doc, _entityName: USER_ENTITIES[i]?.name || "unknown" })),
    )
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 10);

  const firstCollection = USER_ENTITIES[0];

  return (
    <Layout>
      <Layout.Container>
        <Layout.Header>
          <Layout.Title>Dashboard</Layout.Title>
          <Layout.Description>Content overview</Layout.Description>
        </Layout.Header>

        <DashboardWidgets />

        {!isLoading && recentDocuments.length === 0 && (
          <section className="mt-10">
            <EmptyState>
              <EmptyState.Icon>
                <ClockClockwiseIcon />
              </EmptyState.Icon>
              <EmptyState.Title>No recent activity</EmptyState.Title>
              <EmptyState.Description>
                Content created or updated across all entities will show up here.
              </EmptyState.Description>
              {firstCollection && (
                <EmptyState.Actions>
                  <Button asChild size="sm">
                    <Link to="/entity/$name" params={{ name: firstCollection.name }}>
                      Open {resolveEntityTitle(firstCollection.name, { plural: true })}
                    </Link>
                  </Button>
                </EmptyState.Actions>
              )}
            </EmptyState>
          </section>
        )}

        {recentDocuments.length > 0 && (
          <section className="mt-10">
            <h2 className="text-lg font-semibold mb-3">Recent activity</h2>
            <Table>
              <Table.Header>
                <Table.Row>
                  <Table.Head>Media</Table.Head>
                  <Table.Head>Title</Table.Head>
                  <Table.Head>Entity</Table.Head>
                  {hasI18n && <Table.Head>Locale</Table.Head>}
                  <Table.Head>Updated</Table.Head>
                </Table.Row>
              </Table.Header>
              <Table.Body>
                {recentDocuments.map((doc) => {
                  if (!doc) return null;

                  const meta = resolveDocumentMeta(doc._entityName, doc);

                  return (
                    <Table.Row
                      key={`${doc._entityName}-${doc.id}`}
                      tabIndex={0}
                      onClick={withClickGuard(() =>
                        navigate({
                          to: "/entity/$name/$id",
                          params: { name: doc._entityName, id: doc.id },
                        }),
                      )}
                    >
                      <Table.Cell>
                        <figure className="flex items-center justify-center bg-foreground/2 rounded-sm aspect-square overflow-hidden max-w-8 w-full *:object-cover [&_img]:size-full">
                          {meta.media}
                        </figure>
                      </Table.Cell>
                      <Table.Cell className="max-w-48 truncate">{meta.title}</Table.Cell>
                      <Table.Cell>
                        <Badge>{meta.badge ?? resolveEntityTitle(doc._entityName)}</Badge>
                      </Table.Cell>
                      {hasI18n && (
                        <Table.Cell>
                          {doc.locale && (
                            <Badge size="xs" variant="info" className="uppercase">
                              {doc.locale}
                            </Badge>
                          )}
                        </Table.Cell>
                      )}
                      <Table.Cell>{formatDate(doc.updatedAt)}</Table.Cell>
                    </Table.Row>
                  );
                })}
              </Table.Body>
            </Table>
          </section>
        )}
      </Layout.Container>
    </Layout>
  );
}
