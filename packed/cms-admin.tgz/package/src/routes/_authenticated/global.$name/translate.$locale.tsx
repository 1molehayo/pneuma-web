import { Badge, Breadcrumbs } from "@cms/ui";
import { TranslateIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import z from "zod";
import { DOCUMENT_FORM_ID, DocumentForm } from "@/components/forms/document-form";
import { PageLayout as Layout } from "@/components/layouts/page";
import { client } from "@/lib/client";
import { useFieldPermissions } from "@/lib/hooks/use-field-permissions";
import { useKeyboardShortcut } from "@/lib/hooks/use-keyboard-shortcut";
import { useTranslationWarningsToast } from "@/lib/hooks/use-translation-warnings-toast";
import { invalidate } from "@/lib/queries/keys";
import { getEntityTitle } from "@/lib/utils/config";
import { getLocaleLabel, withoutHiddenSharedFields } from "@/lib/utils/i18n";

const searchParamsSchema = z.object({
  from: z.string().optional(),
});

/**
 * Translate a global into `locale`: the engine prepares the copy of the `from` locale's document
 * (nothing is saved), the editor reviews it, and saving is the locale's first write — a draft
 * with the draft workflow on — created as the source's translation.
 */
export const Route = createFileRoute("/_authenticated/global/$name/translate/$locale")({
  component: RouteComponent,
  validateSearch: searchParamsSchema,
  loaderDeps: ({ search }) => ({ from: search.from }),
  loader: ({ params: { name, locale }, deps: { from } }) => {
    const query = new URLSearchParams({ locale, ...(from ? { from } : {}) });
    return client.request<{ data: Record<string, unknown>; warnings: string[] }>(
      `/${name}/translate?${query}`,
    );
  },
});

function RouteComponent() {
  const { global } = Route.useRouteContext();
  const { locale } = Route.useParams();
  const { data, warnings } = Route.useLoaderData();
  const queryClient = useQueryClient();
  const navigate = Route.useNavigate();
  const draftsEnabled = global.versions?.drafts ?? false;
  const { hiddenFields } = useFieldPermissions(global.name, "update");

  useTranslationWarningsToast(warnings);

  useKeyboardShortcut({ key: "s", mod: true }, () => {
    const form = window.document.getElementById(DOCUMENT_FORM_ID);
    if (form instanceof HTMLFormElement) form.requestSubmit();
  });

  const createMutation = useMutation({
    mutationFn: async (formData: Record<string, unknown>) => {
      const body = {
        ...withoutHiddenSharedFields(formData, global.fields, hiddenFields),
        translationOf: data.translationOf,
      };
      const response = draftsEnabled
        ? await client.drafts.save(global.name, body, { locale })
        : await client.update(global.name, body, { locale });
      return response.data;
    },
    onSuccess: () => {
      invalidate.afterGlobalWrite(queryClient, { name: global.name });
      navigate({
        to: "/global/$name/{-$locale}",
        params: { name: global.name, locale },
        replace: true,
        // Saved: nothing is left to lose, though the form is still dirty while `mutateAsync` settles.
        ignoreBlocker: true,
      });
    },
  });

  return (
    <Layout>
      <Layout.Navbar>
        <Breadcrumbs className="mr-auto -ml-2">
          <Breadcrumbs.Item asChild>
            <Link to="/global/$name/{-$locale}" params={{ name: global.name, locale: undefined }}>
              {getEntityTitle(global)}
            </Link>
          </Breadcrumbs.Item>
          <Breadcrumbs.Separator />
          <Breadcrumbs.Item disabled>Translate</Breadcrumbs.Item>
        </Breadcrumbs>
        <Badge variant="neutral" size="sm">
          <TranslateIcon />
          {getLocaleLabel(locale)}
        </Badge>
      </Layout.Navbar>
      <DocumentForm
        initialData={data}
        fields={global.fields}
        onSubmit={(formData) => createMutation.mutateAsync(formData)}
      >
        <DocumentForm.UnsavedChangesBlocker />
        <Layout.Container>
          <Layout.Header>
            <Layout.Title>{getEntityTitle(global)}</Layout.Title>
            {global.description && <Layout.Description>{global.description}</Layout.Description>}
          </Layout.Header>
          <DocumentForm.Fields entityName={global.name} op="update" />
        </Layout.Container>

        <Layout.Actions className="justify-end">
          <DocumentForm.Submit size="sm">Create translation</DocumentForm.Submit>
        </Layout.Actions>
      </DocumentForm>
    </Layout>
  );
}
