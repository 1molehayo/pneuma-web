import CMS_CONFIG from "virtual:cms-config";
import { createFileRoute, notFound, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/global/$name")({
  component: Outlet,
  beforeLoad: ({ params }) => {
    const { name } = params;
    const global = CMS_CONFIG.entities.find((e) => e.name === name && e.global);

    if (!global) {
      throw notFound();
    }

    return { global };
  },
});
