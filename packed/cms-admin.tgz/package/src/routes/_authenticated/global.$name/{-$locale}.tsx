import CMS_CONFIG from "virtual:cms-config";
import { Badge, Breadcrumbs, Button, cn, Dialog, Dropdown, IconButton, toast } from "@cms/ui";
import {
  CaretDownIcon,
  ClockCounterClockwiseIcon,
  CloudArrowUpIcon,
  EyeIcon,
  EyeSlashIcon,
  FloppyDiskIcon,
  XCircleIcon,
} from "@phosphor-icons/react";
import { useMutation, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useRef, useState } from "react";
import z from "zod";
import { DocumentBanners } from "@/components/document-banners";
import { DocumentLocaleSwitcher } from "@/components/document-locale-switcher";
import { DOCUMENT_FORM_ID, DocumentForm } from "@/components/forms/document-form";
import { HistoryDrawer } from "@/components/history-drawer";
import { PageLayout as Layout } from "@/components/layouts/page";
import { SidePanelLayout } from "@/components/layouts/side-panel";
import { PreviewComponent } from "@/components/preview-component";
import { client } from "@/lib/client";
import { useCanReadAuditLog } from "@/lib/hooks/use-can-read-audit-log";
import { useDocumentFormKey } from "@/lib/hooks/use-document-form-key";
import { useKeyboardShortcut } from "@/lib/hooks/use-keyboard-shortcut";
import { getGlobalDocumentQueryOptions } from "@/lib/queries/documents";
import { invalidate } from "@/lib/queries/keys";
import { getEntityTitle } from "@/lib/utils/config";
import { formatDate } from "@/lib/utils/dates";
import { isDocumentTranslatable } from "@/lib/utils/documents";

const defaultLocale = CMS_CONFIG.i18n?.defaultLocale;

const searchParamsSchema = z.object({
  locale: z.string().optional(),
  preview: z.literal("true").optional(),
});

export const Route = createFileRoute("/_authenticated/global/$name/{-$locale}")({
  component: RouteComponent,
  validateSearch: searchParamsSchema,
  beforeLoad: ({ cause, search, params, context }) => {
    if (cause !== "enter" || search.preview) return;
    if (!context.global.admin?.preview || !context.global.admin.previewDefaultOpen) return;
    throw redirect({
      to: "/global/$name/{-$locale}",
      params,
      search: { ...search, preview: "true" },
      replace: true,
    });
  },
  loader: async ({ params, context: { queryClient, global } }) => {
    const useDraft = global?.versions?.drafts ?? false;
    await queryClient.ensureQueryData(
      getGlobalDocumentQueryOptions(params.name, {
        locale: params.locale,
        ...(useDraft ? { draft: true } : {}),
      }),
    );
  },
});

function RouteComponent() {
  const navigate = Route.useNavigate();
  const { global } = Route.useRouteContext();
  const { locale } = Route.useParams();
  const { preview: isPreviewOpen } = Route.useSearch({
    select: (search) => ({ preview: search.preview === "true" }),
  });
  const queryClient = useQueryClient();

  const draftsEnabled = global.versions?.drafts ?? false;

  const { data: document } = useSuspenseQuery(
    getGlobalDocumentQueryOptions(global.name, {
      locale,
      ...(draftsEnabled ? { draft: true } : {}),
    }),
  );

  const hasPreview = !!global.admin?.preview;
  const isTranslatable = document && isDocumentTranslatable(document);

  const submitModeRef = useRef<"draft" | "publish">(
    // Default to "draft" so cmd+s saves without changing publish state.
    draftsEnabled ? "draft" : "publish",
  );
  const [historyOpen, setHistoryOpen] = useState(false);
  // One timeline: versions for anyone who can read them, audit entries for admins.
  const canReadAuditLog = useCanReadAuditLog();
  const historyEnabled = !!global.versions || canReadAuditLog;
  const [discardRequested, setDiscardRequested] = useState(false);

  const invalidateAll = () => {
    invalidate.afterGlobalWrite(queryClient, { name: global.name });
  };

  const [formKey, markOwnSave] = useDocumentFormKey(document);

  const saveDraftMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.drafts.save(global.name, data, { locale });
      return res.data;
    },
    onSuccess: () => {
      markOwnSave();
      invalidateAll();
    },
  });

  const publishMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.update(global.name, data, { locale });
      return res.data;
    },
    onSuccess: () => {
      markOwnSave();
      invalidateAll();
    },
  });

  const unpublishMutation = useMutation({
    mutationFn: async () => {
      const res = await client.unpublish(global.name, { locale });
      return res.data;
    },
    onSuccess: () => {
      invalidateAll();
      toast({ variant: "positive", title: "Unpublished" });
    },
  });

  const discardDraftMutation = useMutation({
    mutationFn: async () => {
      await client.drafts.discard(global.name, { locale });
    },
    onSuccess: () => {
      invalidateAll();
      toast({ variant: "positive", title: "Draft discarded" });
    },
  });

  const status = (document?._status ?? "published") as "draft" | "published" | "modified";
  const hasPendingDraft = status === "modified";
  const isPublished = document?.publishedAt != null;

  // Keyboard shortcuts: cmd+s saves (draft when drafts are on; publish when
  // they aren't — it's the only path), cmd+shift+s is an explicit publish.
  // Publishing should never ride on muscle memory.
  const triggerSubmit = (mode: "draft" | "publish") => {
    submitModeRef.current = mode;
    const form = window.document.getElementById(DOCUMENT_FORM_ID);
    if (form instanceof HTMLFormElement) form.requestSubmit();
  };
  useKeyboardShortcut({ key: "s", mod: true }, () => {
    triggerSubmit(draftsEnabled ? "draft" : "publish");
  });
  useKeyboardShortcut({ key: "s", mod: true, shift: true }, () => triggerSubmit("publish"), {
    enabled: draftsEnabled,
  });

  return (
    <>
      <Layout key={document?.id} inert={saveDraftMutation.isPending || publishMutation.isPending}>
        <Layout.Navbar>
          <Breadcrumbs className="mr-auto -ml-2">
            <Breadcrumbs.Item asChild>
              <Link to="/global/$name/{-$locale}" params={{ name: global.name, locale: undefined }}>
                {getEntityTitle(global)}
              </Link>
            </Breadcrumbs.Item>
            {!!locale && (
              <>
                <Breadcrumbs.Separator />
                <Breadcrumbs.Item disabled className="uppercase">
                  {locale}
                </Breadcrumbs.Item>
              </>
            )}
          </Breadcrumbs>

          {isTranslatable && (
            <DocumentLocaleSwitcher
              document={document}
              getTranslationLinkProps={(translationId) => {
                const targetLocale =
                  translationId === document.id
                    ? document.locale
                    : Object.entries(document._translations).find(
                        ([, t]) => t.id === translationId,
                      )?.[0];

                return {
                  to: "/global/$name/{-$locale}",
                  params: { name: global.name, locale: targetLocale },
                  search: { preview: isPreviewOpen ? "true" : undefined },
                };
              }}
              getNewTranslationLinkProps={(targetLocale) => ({
                to: "/global/$name/translate/$locale",
                params: { name: global.name, locale: targetLocale },
                search: { from: locale ?? defaultLocale },
              })}
            />
          )}

          {hasPreview && (
            <Button
              size="xs"
              variant="outline"
              onClick={() =>
                navigate({
                  to: ".",
                  search: (prev) => ({ ...prev, preview: isPreviewOpen ? undefined : "true" }),
                })
              }
            >
              {isPreviewOpen ? <EyeSlashIcon /> : <EyeIcon />} Preview
            </Button>
          )}
        </Layout.Navbar>

        <DocumentForm
          key={formKey}
          initialData={document ?? undefined}
          fields={global.fields}
          onSubmit={async (data) => {
            const mutation =
              submitModeRef.current === "draft" && draftsEnabled
                ? saveDraftMutation
                : publishMutation;
            await mutation.mutateAsync(data);
          }}
        >
          <DocumentForm.UnsavedChangesBlocker />
          <SidePanelLayout collapseMainOnMobile={isPreviewOpen}>
            <SidePanelLayout.Main>
              <Layout.Container className={cn(isPreviewOpen && "md:min-w-0")}>
                <Layout.Header className="flex items-end justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <Layout.Title>{getEntityTitle(global)}</Layout.Title>
                      {draftsEnabled && (
                        <Badge
                          variant={
                            status === "published"
                              ? "success"
                              : status === "modified"
                                ? "warning"
                                : "neutral"
                          }
                          size="sm"
                        >
                          {status === "published"
                            ? "Published"
                            : status === "modified"
                              ? "Modified"
                              : "Draft"}
                        </Badge>
                      )}
                    </div>
                    {global.description && (
                      <p className="mt-1 text-sm text-foreground-secondary">{global.description}</p>
                    )}
                  </div>
                </Layout.Header>
                {document && (
                  <DocumentBanners entity={global} document={document} className="mb-6" />
                )}
                <DocumentForm.Fields entityName={global.name} op="update" />
              </Layout.Container>

              <Layout.Actions>
                {document && (
                  <div className="text-xs text-foreground-secondary">
                    Last Updated: {formatDate(document.updatedAt)}
                  </div>
                )}
                <Button.Group className="ml-auto">
                  {draftsEnabled ? (
                    <>
                      <Button
                        type="submit"
                        form={DOCUMENT_FORM_ID}
                        variant="outline"
                        isLoading={saveDraftMutation.isPending}
                        onClick={() => {
                          submitModeRef.current = "draft";
                        }}
                      >
                        <FloppyDiskIcon />
                        Save draft
                      </Button>
                      <Button
                        type="submit"
                        form={DOCUMENT_FORM_ID}
                        isLoading={publishMutation.isPending}
                        onClick={() => {
                          submitModeRef.current = "publish";
                        }}
                      >
                        <CloudArrowUpIcon />
                        Publish
                      </Button>
                    </>
                  ) : (
                    <Button
                      type="submit"
                      form={DOCUMENT_FORM_ID}
                      isLoading={publishMutation.isPending}
                      onClick={() => {
                        submitModeRef.current = "publish";
                      }}
                    >
                      <FloppyDiskIcon />
                      Save
                    </Button>
                  )}
                  {historyEnabled && (
                    <Dropdown>
                      <Dropdown.Items>
                        {historyEnabled && (
                          <Dropdown.Item onSelect={() => setHistoryOpen(true)}>
                            <ClockCounterClockwiseIcon />
                            History
                          </Dropdown.Item>
                        )}
                        {draftsEnabled && hasPendingDraft && (
                          <Dropdown.Item onSelect={() => setDiscardRequested(true)}>
                            <XCircleIcon />
                            Discard draft
                          </Dropdown.Item>
                        )}
                        {draftsEnabled && isPublished && (
                          <Dropdown.Item onSelect={() => unpublishMutation.mutate()}>
                            <EyeSlashIcon />
                            Unpublish
                          </Dropdown.Item>
                        )}
                      </Dropdown.Items>
                      <Dropdown.Trigger asChild>
                        <IconButton aria-label="More options">
                          <CaretDownIcon />
                        </IconButton>
                      </Dropdown.Trigger>
                    </Dropdown>
                  )}
                </Button.Group>
              </Layout.Actions>
            </SidePanelLayout.Main>

            {isPreviewOpen && global.admin?.preview && (
              <SidePanelLayout.Side defaultSize="50%">
                <PreviewComponent
                  component={global.admin.preview}
                  schema={global.schema}
                  initialData={document ?? {}}
                />
              </SidePanelLayout.Side>
            )}
          </SidePanelLayout>
        </DocumentForm>
      </Layout>

      {historyEnabled && (
        <HistoryDrawer
          open={historyOpen}
          onOpenChange={setHistoryOpen}
          entity={global}
          locale={global.translatable ? (locale ?? defaultLocale) : undefined}
        />
      )}

      <Dialog open={discardRequested} onOpenChange={setDiscardRequested}>
        <Dialog.Content>
          <Dialog.Title>Discard draft?</Dialog.Title>
          <Dialog.Description>
            This permanently removes the pending edits on top of the published version. Cannot be
            undone.
          </Dialog.Description>
          <Dialog.Actions>
            <Button variant="outline" onClick={() => setDiscardRequested(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                setDiscardRequested(false);
                discardDraftMutation.mutate();
              }}
            >
              Discard
            </Button>
          </Dialog.Actions>
        </Dialog.Content>
      </Dialog>
    </>
  );
}
