import { Breadcrumbs, Button, cn, EmptyState, Skeleton, useDelayedLoading } from "@cms/ui";
import {
  BroomIcon,
  FilesIcon,
  ImageSquareIcon,
  ImagesIcon,
  TagIcon,
  VideoIcon,
  XIcon,
} from "@phosphor-icons/react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AssetUploadInput } from "@/components/forms/asset-upload-input";
import { PageLayout as Layout } from "@/components/layouts/page";
import { useAssets } from "@/lib/hooks/use-assets";
import { useCanCleanUpAssets } from "@/lib/hooks/use-can-clean-up-assets";
import type { Asset } from "@/lib/schemas";
import { withClickGuard } from "@/lib/utils/dom";
import { AssetCard } from "./-components/asset-card";
import { AssetCleanupDialog } from "./-components/asset-cleanup-dialog";
import { AssetDeleteDialog } from "./-components/asset-delete-dialog";
import { AssetDetailsDialog } from "./-components/asset-details-dialog";

enum ASSET_GROUP {
  images = "_image",
  videos = "_video",
  files = "_file",
}

export const Route = createFileRoute("/_authenticated/assets/{-$group}")({
  component: RouteComponent,
  loader: async ({ params: { group } }) => {
    // biome-ignore lint/suspicious/noExplicitAny: intentional
    if (group && !Object.keys(ASSET_GROUP).includes(group as any)) {
      throw notFound();
    }

    return {
      group: group as keyof typeof ASSET_GROUP | undefined,
    };
  },
});

function RouteComponent() {
  const { group } = Route.useLoaderData();

  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [toDeleteAsset, setToDeleteAsset] = useState<Asset | null>(null);
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const [cleanupOpen, setCleanupOpen] = useState(false);
  const canCleanUp = useCanCleanUpAssets();

  const { data: assets, isPending } = useAssets(
    !group ? [ASSET_GROUP.images, ASSET_GROUP.videos, ASSET_GROUP.files] : [ASSET_GROUP[group]],
  );
  const showPending = useDelayedLoading(isPending);

  const allTags = useMemo(() => {
    if (!assets) return [];
    const set = new Set<string>();
    for (const asset of assets) {
      for (const tag of asset.tags ?? []) set.add(tag);
    }
    return [...set].sort();
  }, [assets]);

  const filteredAssets = useMemo(() => {
    if (!assets || activeTags.length === 0) return assets;
    return assets.filter((a) => activeTags.every((t) => a.tags?.includes(t)));
  }, [assets, activeTags]);

  const toggleTag = (tag: string) => {
    setActiveTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  return (
    <>
      <Layout>
        <Layout.Navbar>
          <Breadcrumbs className="-ml-2">
            <Breadcrumbs.Item asChild>
              <Link to="/assets/{-$group}" params={{ group: undefined }}>
                Assets
              </Link>
            </Breadcrumbs.Item>
            {!!group && (
              <>
                <Breadcrumbs.Separator />
                <Breadcrumbs.Item disabled>{group}</Breadcrumbs.Item>
              </>
            )}
          </Breadcrumbs>
        </Layout.Navbar>

        <Layout.Container>
          <Layout.Header>
            <Layout.Title>Assets</Layout.Title>
            <Layout.Description>Manage your assets here.</Layout.Description>
          </Layout.Header>

          <div className="flex items-center justify-between gap-2">
            <nav className="flex gap-2">
              <Button asChild variant={group === undefined ? "primary" : "outline"}>
                <Link to="/assets/{-$group}" params={{ group: undefined }}>
                  All
                </Link>
              </Button>
              {Object.keys(ASSET_GROUP).map((g) => (
                <Button
                  key={g}
                  asChild
                  className="capitalize"
                  variant={group === g ? "primary" : "outline"}
                >
                  <Link to="/assets/{-$group}" params={{ group: g }}>
                    {g === "images" && <ImagesIcon />}
                    {g === "videos" && <VideoIcon />}
                    {g === "files" && <FilesIcon />}
                    {g}
                  </Link>
                </Button>
              ))}
            </nav>
            {canCleanUp && (
              <Button variant="outline" onClick={() => setCleanupOpen(true)}>
                <BroomIcon />
                Clean up unused
              </Button>
            )}
          </div>

          {allTags.length > 0 && (
            <div className="mt-3 flex items-center gap-3 rounded-lg bg-background-secondary px-3 py-2">
              <TagIcon size={14} className="shrink-0 text-foreground-secondary" />
              <div className="flex flex-1 flex-wrap gap-1.5">
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={cn(
                      "cursor-pointer rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
                      activeTags.includes(tag)
                        ? "bg-foreground text-background"
                        : "bg-background text-foreground/70 hover:text-foreground",
                    )}
                  >
                    {tag}
                  </button>
                ))}
              </div>
              {activeTags.length > 0 && (
                <button
                  type="button"
                  onClick={() => setActiveTags([])}
                  className="inline-flex shrink-0 cursor-pointer items-center gap-1 text-xs text-foreground-secondary transition-colors hover:text-foreground"
                >
                  <XIcon size={12} />
                  Clear
                </button>
              )}
            </div>
          )}

          <div className="mt-8">
            <AssetUploadInput
              multiple
              types={group ? [ASSET_GROUP[group]] : ["_image", "_video", "_file"]}
            />
            <ul className="mt-8 grid grid-cols-[repeat(auto-fill,minmax(--spacing(64),1fr))] gap-4">
              {showPending ? (
                new Array(12).fill(null).map((_, i) => (
                  <li key={`skeleton-${i}`}>
                    <Skeleton className="aspect-video" />
                  </li>
                ))
              ) : (
                <>
                  {filteredAssets?.map((asset) => (
                    <li key={asset.id}>
                      <AssetCard
                        asset={asset}
                        onClick={withClickGuard(() => setSelectedAsset(asset))}
                        onView={() => setSelectedAsset(asset)}
                        onDelete={() => setToDeleteAsset(asset)}
                      />
                    </li>
                  ))}
                  {filteredAssets?.length === 0 && (
                    <li className="col-span-full">
                      <EmptyState>
                        <EmptyState.Icon>
                          <ImageSquareIcon />
                        </EmptyState.Icon>
                        <EmptyState.Title>
                          {activeTags.length > 0 ? "No assets match these tags" : "No assets yet"}
                        </EmptyState.Title>
                        <EmptyState.Description>
                          {activeTags.length > 0
                            ? "Clear the tag filter to see everything, or upload a new asset."
                            : "Upload an image, video, or file to get started."}
                        </EmptyState.Description>
                        {activeTags.length > 0 && (
                          <EmptyState.Actions>
                            <Button size="sm" variant="outline" onClick={() => setActiveTags([])}>
                              Clear filters
                            </Button>
                          </EmptyState.Actions>
                        )}
                      </EmptyState>
                    </li>
                  )}
                </>
              )}
            </ul>
          </div>
        </Layout.Container>
      </Layout>

      <AssetDetailsDialog asset={selectedAsset} onClose={() => setSelectedAsset(null)} />
      <AssetCleanupDialog open={cleanupOpen} onClose={() => setCleanupOpen(false)} />
      <AssetDeleteDialog asset={toDeleteAsset} onClose={() => setToDeleteAsset(null)} />
    </>
  );
}
