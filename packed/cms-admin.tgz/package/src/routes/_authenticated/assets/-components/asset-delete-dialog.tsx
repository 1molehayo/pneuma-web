import { Button, Dialog } from "@cms/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { client } from "@/lib/client";
import { invalidate } from "@/lib/queries/keys";
import type { Asset } from "@/lib/schemas";

type AssetDeleteDialogProps = {
  asset: Asset | null;
  onClose: () => void;
};

const AssetDeleteDialog = ({ asset, onClose }: AssetDeleteDialogProps) => {
  return (
    <Dialog open={!!asset} onOpenChange={onClose}>
      <Dialog.Content className="md:max-w-lg">
        {asset && <AssetDeleteDialogContent asset={asset} onClose={onClose} />}
      </Dialog.Content>
    </Dialog>
  );
};

type AssetDeleteDialogContentProps = {
  asset: Asset;
  onClose: () => void;
};

const AssetDeleteDialogContent = ({ asset, onClose }: AssetDeleteDialogContentProps) => {
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await client.request(`/${asset._entity}/${asset.id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      invalidate.afterDelete(queryClient, { entity: asset._entity });
      onClose();
    },
  });

  return (
    <>
      <Dialog.Title>Delete asset</Dialog.Title>
      <Dialog.Description>
        Are you sure you want to delete <strong>{asset.filename}</strong>? This action cannot be
        undone.
      </Dialog.Description>
      <Dialog.Actions>
        <Dialog.Close asChild>
          <Button variant="outline">Cancel</Button>
        </Dialog.Close>
        <Button
          autoFocus
          variant="destructive"
          isLoading={deleteMutation.isPending}
          onClick={() => deleteMutation.mutate()}
        >
          Delete
        </Button>
      </Dialog.Actions>
    </>
  );
};

export { AssetDeleteDialog };
