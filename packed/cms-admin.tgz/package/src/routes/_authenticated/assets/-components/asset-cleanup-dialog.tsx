import { Button, Dialog, Skeleton } from "@cms/ui";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import z from "zod";
import { client } from "@/lib/client";
import { invalidate, keys } from "@/lib/queries/keys";
import { formatSize } from "@/lib/utils/format-size";

const summarySchema = z.object({
  data: z.object({
    assets: z.array(
      z.object({
        id: z.string(),
        filename: z.string(),
        mimeType: z.string(),
        size: z.number(),
      }),
    ),
    count: z.number(),
    totalSize: z.number(),
  }),
});

type AssetCleanupDialogProps = {
  open: boolean;
  onClose: () => void;
};

const AssetCleanupDialog = ({ open, onClose }: AssetCleanupDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <Dialog.Content className="md:max-w-lg">
        {open && <AssetCleanupDialogContent onClose={onClose} />}
      </Dialog.Content>
    </Dialog>
  );
};

const AssetCleanupDialogContent = ({ onClose }: { onClose: () => void }) => {
  const queryClient = useQueryClient();

  const preview = useQuery({
    queryKey: keys.assetCleanup(),
    queryFn: ({ signal }) =>
      client.request("/assets/cleanup/unused", { signal, schema: summarySchema }),
    // A preview is only true at the moment it is fetched.
    gcTime: 0,
  });

  const cleanup = useMutation({
    mutationFn: (ids: string[]) =>
      client.request("/assets/cleanup", { method: "POST", body: { ids }, schema: summarySchema }),
    onSuccess: () => {
      for (const entity of ["_image", "_video", "_file"]) {
        invalidate.afterDelete(queryClient, { entity });
      }
      onClose();
    },
  });

  const summary = preview.data?.data;

  return (
    <>
      <Dialog.Title>Clean up unused assets</Dialog.Title>
      <Dialog.Description>
        Deletes assets that no entry, draft or version references, from the library and from
        storage. Assets uploaded in the last hour are kept. This action cannot be undone.
      </Dialog.Description>

      {preview.isPending && <Skeleton className="h-24" />}

      {preview.isError && (
        <p className="text-sm text-destructive">Could not look for unused assets.</p>
      )}

      {summary && summary.count === 0 && (
        <p className="text-sm text-foreground-secondary">Every asset is in use.</p>
      )}

      {summary && summary.count > 0 && (
        <>
          <p className="text-sm">
            <strong>{summary.count}</strong> unused {summary.count === 1 ? "asset" : "assets"},{" "}
            {formatSize(summary.totalSize)} in total.
          </p>
          <ul className="flex max-h-64 flex-col gap-1 overflow-y-auto rounded-lg bg-background-secondary p-3 text-sm">
            {summary.assets.map((asset) => (
              <li key={asset.id} className="flex justify-between gap-4">
                <span className="truncate">{asset.filename}</span>
                <span className="shrink-0 text-foreground/50">{formatSize(asset.size)}</span>
              </li>
            ))}
          </ul>
        </>
      )}

      {cleanup.isError && <p className="text-sm text-destructive">The cleanup failed.</p>}

      <Dialog.Actions>
        <Dialog.Close asChild>
          <Button variant="outline">Cancel</Button>
        </Dialog.Close>
        {summary && summary.count > 0 && (
          <Button
            variant="destructive"
            isLoading={cleanup.isPending}
            onClick={() => cleanup.mutate(summary.assets.map((asset) => asset.id))}
          >
            Delete {summary.count} {summary.count === 1 ? "asset" : "assets"}
          </Button>
        )}
      </Dialog.Actions>
    </>
  );
};

export { AssetCleanupDialog };
