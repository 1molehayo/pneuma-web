import { Badge, cn, Dropdown, IconButton, Tooltip } from "@cms/ui";
import {
  CheckIcon,
  CopyIcon,
  DotsThreeVertical,
  FileTextIcon,
  InfoIcon,
  LockIcon,
  TrashIcon,
} from "@phosphor-icons/react";
import { type ComponentPropsWithoutRef, useState } from "react";
import type { Asset } from "@/lib/schemas";

const MIME_TO_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/avif": "avif",
  "image/gif": "gif",
  "image/svg+xml": "svg",
  "image/tiff": "tiff",
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/ogg": "ogv",
  "video/quicktime": "mov",
  "application/pdf": "pdf",
  "text/plain": "txt",
  "text/html": "html",
  "application/zip": "zip",
  "application/json": "json",
};

function getExtension(mimeType: string): string {
  return MIME_TO_EXT[mimeType] ?? mimeType.split("/")[1] ?? "file";
}

type AssetCardProps = Omit<ComponentPropsWithoutRef<"div">, "children"> & {
  asset: Asset;
  onView?: () => void;
  onDelete?: () => void;
};

const AssetCard = ({ asset, className, onView, onDelete, ...props }: AssetCardProps) => {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = async () => {
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);

    await navigator.clipboard.writeText(asset.url);
  };

  return (
    <div
      className={cn(
        "group border border-border rounded-lg text-xs text-left overflow-hidden w-full h-full cursor-pointer",
        "ring-ring focus-visible:outline-none focus-visible:ring-4 focus-visible:border-foreground",
        "hover:bg-foreground/2 active:bg-foreground/4",
        className,
      )}
      {...props}
    >
      <figure className="relative aspect-video bg-foreground/2">
        <Badge className="absolute top-2 left-2" size="xs">
          {getExtension(asset.mimeType)}
        </Badge>
        {asset.private && (
          <Tooltip>
            <Tooltip.Trigger asChild>
              <span className="absolute bottom-2 right-2 flex items-center justify-center size-5 rounded-full bg-background/80 backdrop-blur-sm text-foreground shadow-xs">
                <LockIcon size={10} weight="bold" />
              </span>
            </Tooltip.Trigger>
            <Tooltip.Content>Private</Tooltip.Content>
          </Tooltip>
        )}
        <Dropdown>
          <Dropdown.Trigger asChild>
            <IconButton
              className="absolute top-2 right-2 bg-background!"
              size="xs"
              variant="outline"
              aria-label="More options"
            >
              <DotsThreeVertical />
            </IconButton>
          </Dropdown.Trigger>
          <Dropdown.Items>
            <Dropdown.Item onSelect={onView}>
              <InfoIcon />
              View Asset
            </Dropdown.Item>
            <Dropdown.Item
              onSelect={(e) => {
                e.preventDefault();
                handleCopy();
              }}
            >
              {isCopied ? <CheckIcon /> : <CopyIcon />}
              Copy URL
            </Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item onSelect={onDelete} className="text-negative">
              <TrashIcon />
              Delete
            </Dropdown.Item>
          </Dropdown.Items>
        </Dropdown>

        {asset._entity === "_image" && (
          <img src={asset.url} alt={asset.filename} className="object-cover size-full" />
        )}
        {asset._entity === "_video" && (
          <video src={asset.url} className="object-cover size-full" muted preload="metadata" />
        )}
        {asset._entity === "_file" && (
          <div className="flex items-center justify-center size-full text-foreground-secondary">
            <FileTextIcon className="size-8" />
          </div>
        )}
      </figure>

      <div className="p-3">
        <p>{asset.filename}</p>
        <ul className="text-foreground-secondary">
          {(asset._entity === "_image" || asset._entity === "_video") && (
            <li>
              {asset.width}x{asset.height}
            </li>
          )}
          {asset._entity === "_file" && <li>{asset.size} bytes</li>}
        </ul>
        {asset.tags && asset.tags.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            {asset.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} size="xs" variant="neutral">
                {tag}
              </Badge>
            ))}
            {asset.tags.length > 3 && (
              <Badge size="xs" variant="neutral">
                +{asset.tags.length - 3}
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export { AssetCard };
