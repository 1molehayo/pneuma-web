import { Badge, Button, Checkbox, Dialog, Divider, Field, Input, Label } from "@cms/ui";
import { FileTextIcon, XIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useRef, useState } from "react";
import { CopyButton } from "@/components/copy-button";
import { client } from "@/lib/client";
import { invalidate } from "@/lib/queries/keys";
import type { Asset } from "@/lib/schemas";
import { formatSize } from "@/lib/utils/format-size";

type AssetDetailsDialogProps = {
  asset: Asset | null;
  onClose: () => void;
};

const AssetDetailsDialog = ({ asset, onClose }: AssetDetailsDialogProps) => {
  return (
    <Dialog open={!!asset} onOpenChange={onClose}>
      <Dialog.Content className="md:max-w-lg">
        {asset && <AssetDetailsDialogContent asset={asset} onClose={onClose} />}
      </Dialog.Content>
    </Dialog>
  );
};

type AssetDetailsDialogContentProps = {
  asset: Asset;
  onClose: () => void;
};

type TagInputProps = {
  value: string[];
  onChange: (tags: string[]) => void;
};

const TagInput = ({ value, onChange }: TagInputProps) => {
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const addTag = (raw: string) => {
    const tag = raw.trim().toLowerCase();
    if (tag && !value.includes(tag)) {
      onChange([...value, tag]);
    }
    setInput("");
  };

  const removeTag = (tag: string) => {
    onChange(value.filter((t) => t !== tag));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(input);
    } else if (e.key === "Backspace" && input === "" && value.length > 0) {
      onChange(value.slice(0, -1));
    }
  };

  return (
    // biome-ignore lint/a11y/noStaticElementInteractions: click-forward wrapper to enlarge input focus target
    <div
      className="flex flex-wrap items-center gap-1.5 min-h-8 w-full rounded-lg border border-border shadow-xs px-3 py-1 text-sm transition hover:border-[color-mix(in_oklab,var(--color-border),var(--color-foreground)_8%)] focus-within:ring-4 focus-within:ring-ring focus-within:border-accent cursor-text"
      onClick={() => inputRef.current?.focus()}
      onKeyDown={(e) => {
        if (e.key === "Enter") inputRef.current?.focus();
      }}
    >
      {value.map((tag) => (
        <Badge key={tag} size="xs" variant="neutral">
          {tag}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              removeTag(tag);
            }}
            className="text-foreground-secondary hover:text-foreground"
          >
            <XIcon size={10} />
          </button>
        </Badge>
      ))}
      <input
        id="asset-tags"
        ref={inputRef}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => {
          if (input) addTag(input);
        }}
        placeholder={value.length === 0 ? "Add tags…" : ""}
        className="min-w-20 flex-1 bg-transparent text-sm outline-none placeholder:text-foreground-secondary"
      />
    </div>
  );
};

const AssetDetailsDialogContent = ({ asset, onClose }: AssetDetailsDialogContentProps) => {
  const queryClient = useQueryClient();
  const [filename, setFilename] = useState(asset.filename);
  const [altText, setAltText] = useState(asset._entity === "_image" ? (asset.alt ?? "") : "");
  const [tags, setTags] = useState<string[]>(asset.tags ?? []);
  const [isPrivate, setIsPrivate] = useState(asset.private ?? false);

  const fullAssetUrl = useMemo(() => {
    return new URL(asset.url, window.location.origin).toString();
  }, [asset]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const body =
        asset._entity === "_image"
          ? { filename, alt: altText, tags, private: isPrivate }
          : { filename, tags, private: isPrivate };
      await client.request(`/${asset._entity}/${asset.id}`, {
        method: "PUT",
        body,
      });
    },
    onSuccess: () => {
      invalidate.afterDocumentWrite(queryClient, { entity: asset._entity, id: asset.id });
      onClose();
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        saveMutation.mutate();
      }}
    >
      <Dialog.Title asChild>
        <input
          value={filename}
          onChange={(e) => setFilename(e.target.value)}
          className="w-full bg-transparent outline-none rounded focus-visible:ring-2 focus-visible:ring-ring px-0.5 -mx-0.5 truncate"
        />
      </Dialog.Title>

      <figure className="mt-3 flex items-center h-64 justify-center overflow-hidden rounded-lg border border-border bg-background-secondary">
        {asset._entity === "_image" && (
          <img
            src={asset.url}
            alt={asset.alt ?? asset.filename}
            className="max-h-64 w-full object-contain"
          />
        )}
        {asset._entity === "_video" && (
          <video src={asset.url} className="max-h-64 w-full" controls muted />
        )}
        {asset._entity === "_file" && <FileTextIcon className="size-10" />}
      </figure>

      {/* Metadata */}
      <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-6 gap-y-1.5 text-sm">
        <dt className="text-foreground-secondary">Type</dt>
        <dd>{asset.mimeType}</dd>

        <dt className="text-foreground-secondary">Size</dt>
        <dd>{formatSize(asset.size)}</dd>

        {(asset._entity === "_image" || asset._entity === "_video") &&
          asset.width != null &&
          asset.height != null && (
            <>
              <dt className="text-foreground-secondary">Dimensions</dt>
              <dd>
                {asset.width} × {asset.height}
              </dd>
            </>
          )}
      </dl>

      {/* URL */}
      <div className="mt-4 flex flex-col gap-2">
        <span className="text-sm font-medium">URL</span>
        <div className="flex items-center gap-1.5">
          <code className="flex-1 truncate rounded bg-background-secondary px-2 py-1 text-xs">
            {fullAssetUrl ?? asset.url}
          </code>
          <CopyButton text={fullAssetUrl || asset.url} size="sm" variant="ghost" />
        </div>
      </div>

      <Divider className="mt-6" />

      {/* Alt text — images only */}
      {asset._entity === "_image" && (
        <Field className="mt-4">
          <Label htmlFor="asset-alt">Alt text</Label>
          <Input
            id="asset-alt"
            value={altText}
            onChange={(e) => setAltText(e.target.value)}
            placeholder="Describe this image…"
          />
        </Field>
      )}

      {/* Tags — all asset types */}
      <Field className="mt-4">
        <Label htmlFor="asset-tags">Tags</Label>
        <TagInput value={tags} onChange={setTags} />
      </Field>

      {/* Private — all asset types */}
      <label htmlFor="asset-private" className="mt-4 flex cursor-pointer items-center gap-2.5">
        <Checkbox
          id="asset-private"
          checked={isPrivate}
          onChange={(e) => setIsPrivate(e.target.checked)}
        />
        <span className="text-sm font-medium">Private</span>
        <span className="text-sm text-foreground-secondary">Require authentication to access</span>
      </label>

      <Dialog.Actions className="sm:justify-between mt-6">
        <Dialog.Close asChild>
          <Button variant="outline" size="sm">
            Close
          </Button>
        </Dialog.Close>
        <Button type="submit" size="sm" isLoading={saveMutation.isPending}>
          Save
        </Button>
      </Dialog.Actions>
    </form>
  );
};

export { AssetDetailsDialog };
