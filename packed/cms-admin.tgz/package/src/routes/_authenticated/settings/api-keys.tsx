import CMS_CONFIG from "virtual:cms-config";
import {
  Badge,
  Button,
  cn,
  Dialog,
  Field,
  IconButton,
  Input,
  Label,
  Listbox,
  Table,
  toast,
} from "@cms/ui";
import { PlusIcon, TrashIcon } from "@phosphor-icons/react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CopyButton } from "@/components/copy-button";
import { PageLayout as Layout } from "@/components/layouts/page";
import { client } from "@/lib/client";
import { getApiKeysQueryOptions } from "@/lib/queries/api-keys";
import { invalidate } from "@/lib/queries/keys";
import type { ApiKey } from "@/lib/schemas";

export const Route = createFileRoute("/_authenticated/settings/api-keys")({
  component: RouteComponent,
  loader: async ({ context }) => {
    await context.queryClient.ensureQueryData(getApiKeysQueryOptions());
  },
});

function RouteComponent() {
  const { data } = useQuery(getApiKeysQueryOptions());

  return (
    <Layout>
      <Layout.Container>
        <Layout.Header className="flex items-end justify-between">
          <div>
            <Layout.Title>API Keys</Layout.Title>
            <Layout.Description>Manage your API keys.</Layout.Description>
          </div>
          <CreateApiKeyFormDialog>
            <Button>
              <PlusIcon />
              Create
            </Button>
          </CreateApiKeyFormDialog>
        </Layout.Header>

        <Table>
          <Table.Header>
            <Table.Row>
              <Table.Head>Name</Table.Head>
              <Table.Head>Prefix</Table.Head>
              <Table.Head>Role</Table.Head>
              <Table.Head>Status</Table.Head>
              <Table.Head className="hidden">Revoke</Table.Head>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {data?.map((row) => {
              const isRevoked = row.revokedAt !== null;

              return (
                <Table.Row
                  key={row.id}
                  className={cn(isRevoked && "opacity-40 pointer-events-none")}
                >
                  <Table.Cell>{row.name}</Table.Cell>
                  <Table.Cell>
                    <code className="text-xs bg-foreground/2 p-1 text-foreground/64">
                      {row.keyPrefix}...
                    </code>
                  </Table.Cell>
                  <Table.Cell>
                    <Badge className="capitalize">{row.role}</Badge>
                  </Table.Cell>
                  <Table.Cell>
                    {isRevoked ? (
                      <Badge variant="error">Revoked</Badge>
                    ) : (
                      <Badge variant="success">Active</Badge>
                    )}
                  </Table.Cell>
                  <Table.Cell className="w-6">
                    <RevokeFormDialog id={row.id}>
                      <IconButton
                        variant="ghost"
                        size="sm"
                        aria-label="Revoke"
                        disabled={isRevoked}
                      >
                        <TrashIcon />
                      </IconButton>
                    </RevokeFormDialog>
                  </Table.Cell>
                </Table.Row>
              );
            })}
          </Table.Body>
        </Table>
      </Layout.Container>
    </Layout>
  );
}

type CreateApiKeyFormDialogProps = {
  children: React.ReactNode;
};

const CreateApiKeyFormDialog = ({ children }: CreateApiKeyFormDialogProps) => {
  const FORM_ID = "create-api-key";

  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [key, setKey] = useState<null | string>(null);

  const [name, setName] = useState("");
  const [role, setRole] = useState("");

  const createMutation = useMutation({
    mutationFn: async () => {
      if (!name || !role) {
        throw new Error();
      }

      const { data } = await client.request<{ data: ApiKey & { key: string } }>("/_api-keys", {
        method: "POST",
        body: {
          name,
          role,
        },
      });

      return data;
    },
    onSuccess: (data) => {
      setKey(data.key);
      invalidate.afterDocumentWrite(queryClient, { entity: "_api-keys", id: data.id });
      toast({ title: "API key created", variant: "positive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate();
  };

  const isSubmitted = createMutation.failureCount > 0;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <Dialog.Trigger asChild>{children}</Dialog.Trigger>
      <Dialog.Content>
        {!key && (
          <>
            <Dialog.Title>Create API key</Dialog.Title>
            <Dialog.Description>Create a new API key to access the API.</Dialog.Description>

            <form id={FORM_ID} className="mb-2 mt-4" onSubmit={handleSubmit}>
              <Field>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  placeholder="My API key"
                  value={name}
                  invalid={isSubmitted && !name}
                  onChange={(e) => setName(e.target.value)}
                />
                {isSubmitted && !name && <Field.Error>Name is required</Field.Error>}
              </Field>
              <Field>
                <Label htmlFor="role">Role</Label>
                <Listbox value={role} onChange={setRole} invalid={isSubmitted && !role}>
                  <Listbox.Trigger id="role" placeholder="Select a role" className="capitalize">
                    {role || null}
                  </Listbox.Trigger>
                  <Listbox.Options>
                    {CMS_CONFIG.roles.map((role) => (
                      <Listbox.Option key={role.name} value={role.name} className="capitalize">
                        {role.name}
                      </Listbox.Option>
                    ))}
                  </Listbox.Options>
                </Listbox>
                {isSubmitted && !role && <Field.Error>Role is required</Field.Error>}
              </Field>
            </form>

            {createMutation.error && (
              <p className="text-negative my-2 text-xs">{createMutation.error.message}</p>
            )}

            <Dialog.Actions>
              <Dialog.Close asChild>
                <Button variant="outline">Cancel</Button>
              </Dialog.Close>
              <Button type="submit" form={FORM_ID} isLoading={createMutation.isPending}>
                Create
              </Button>
            </Dialog.Actions>
          </>
        )}

        {key && (
          <>
            <Dialog.Title>Your API key</Dialog.Title>
            <Dialog.Description>
              Copy your API key and store it in a safe place. You will not be able to see it again.
            </Dialog.Description>
            <div className="mt-4 mb-2 relative w-full flex gap-1.5 items-center bg-foreground/4 rounded-xl overflow-hidden">
              <div className="overflow-x-auto py-2 pl-3">
                <code className="text-xs text-foreground/72 whitespace-nowrap">{key}</code>
              </div>
              <CopyButton size="sm" variant="ghost" text={key} className="mr-1 ml-auto" />
            </div>

            <Dialog.Close asChild>
              <Button
                className="mt-4"
                onClick={() => {
                  setIsOpen(false);
                  setKey(null);
                }}
              >
                Done
              </Button>
            </Dialog.Close>
          </>
        )}
      </Dialog.Content>
    </Dialog>
  );
};

type RevokeFormDialogProps = {
  id: string;
  children: React.ReactNode;
};

const RevokeFormDialog = ({ id, children }: RevokeFormDialogProps) => {
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);

  const revokeMutation = useMutation({
    mutationFn: async () => {
      await client.request(`/_api-keys/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      invalidate.afterDelete(queryClient, { entity: "_api-keys" });
      toast({ title: "API key revoked", variant: "positive" });
      setIsOpen(false);
    },
    onError: () => {
      toast({ title: "Failed to revoke API key", variant: "negative" });
    },
  });

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <Dialog.Trigger asChild>{children}</Dialog.Trigger>
      <Dialog.Content inert={revokeMutation.isPending}>
        <Dialog.Title>Revoke API Key</Dialog.Title>
        <Dialog.Description>
          Are you sure you want to revoke this API key?
          <br />
          This action cannot be undone.
        </Dialog.Description>
        <Dialog.Actions>
          <Dialog.Close asChild>
            <Button variant="outline">Cancel</Button>
          </Dialog.Close>
          <Button
            autoFocus
            variant="destructive"
            onClick={() => revokeMutation.mutate()}
            isLoading={revokeMutation.isPending}
          >
            Revoke
          </Button>
        </Dialog.Actions>
      </Dialog.Content>
    </Dialog>
  );
};
