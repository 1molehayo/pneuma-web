import CMS_CONFIG from "virtual:cms-config";
import {
  Badge,
  Button,
  cn,
  DatePicker,
  EmptyState,
  IconButton,
  inputStyle,
  Listbox,
  Pagination,
  Popover,
  Skeleton,
  Table,
  useDelayedLoading,
  usePagination,
} from "@cms/ui";
import {
  ArrowSquareOutIcon,
  CaretUpDownIcon,
  ListBulletsIcon,
  WarningCircleIcon,
  XIcon,
} from "@phosphor-icons/react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useState } from "react";
import z from "zod";
import { CopyButton } from "@/components/copy-button";
import { PageLayout as Layout } from "@/components/layouts/page";
import {
  AUDIT_LOG_PAGE_SIZE,
  type AuditEntry,
  getAuditLogQueryOptions,
} from "@/lib/queries/audit-log";
import { getAllUsersQueryOptions } from "@/lib/queries/users";
import {
  AUDIT_ACTION_LABELS,
  AUDIT_ACTIONS,
  auditActionLabel,
  auditActorLabel,
} from "@/lib/utils/audit-log";
import { getEntityTitle, resolveEntityTitle } from "@/lib/utils/config";
import { formatDate } from "@/lib/utils/dates";
import { formatFieldPath } from "@/lib/utils/field-path";

const LOCALES = CMS_CONFIG.i18n.locales ?? [];
const DEFAULT_LOCALE = CMS_CONFIG.i18n.defaultLocale;

/** API key writes are logged under this entity name; it has no config entry or page. */
const API_KEY_ENTITY = "_api_key";

const searchSchema = z.object({
  entity: z.string().optional(),
  documentId: z.uuid().optional().catch(undefined),
  actorId: z.uuid().optional().catch(undefined),
  action: z.enum(AUDIT_ACTIONS).optional().catch(undefined),
  locale: z.string().optional(),
  from: z.iso.date().optional().catch(undefined),
  to: z.iso.date().optional().catch(undefined),
  page: z.coerce.number().int().min(1).optional().default(1).catch(1),
});

type ActivitySearch = z.infer<typeof searchSchema>;

export const Route = createFileRoute("/_authenticated/settings/activity")({
  component: RouteComponent,
  validateSearch: searchSchema,
  beforeLoad: ({ context }) => {
    const role = CMS_CONFIG.roles.find((candidate) => candidate.name === context.me.role);
    if (!role?.isAdmin) throw redirect({ to: "/" });
  },
  loaderDeps: ({ search }) => search,
  loader: async ({ context, deps }) => {
    await Promise.all([
      context.queryClient.ensureQueryData(getAuditLogQueryOptions(deps)),
      context.queryClient.ensureQueryData(getAllUsersQueryOptions()),
    ]);
  },
});

function RouteComponent() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const { data, isError, isFetching, isPlaceholderData } = useQuery({
    ...getAuditLogQueryOptions(search),
    placeholderData: keepPreviousData,
  });
  const { data: users = [] } = useQuery(getAllUsersQueryOptions());
  const showFetching = useDelayedLoading(isFetching && isPlaceholderData);

  const total = data?.meta.total ?? 0;
  const pageCount = Math.max(1, Math.ceil(total / AUDIT_LOG_PAGE_SIZE));
  const paginationItems = usePagination({ page: search.page, count: pageCount });

  const setFilter = (next: Partial<Omit<ActivitySearch, "page">>) =>
    navigate({ search: (prev) => ({ ...prev, ...next, page: 1 }) });
  const hasFilters = Object.entries(search).some(
    ([key, value]) => key !== "page" && value !== undefined,
  );
  const dateRange = toDateRange(search.from, search.to);
  const dateLabel = dateRange ? formatDayRange(dateRange) : "All";
  const entities = CMS_CONFIG.entities.toSorted((a, b) =>
    getEntityTitle(a).localeCompare(getEntityTitle(b)),
  );

  return (
    <Layout>
      <Layout.Container className="max-w-380">
        <Layout.Header>
          <Layout.Title>Activity</Layout.Title>
          <Layout.Description>
            Every write to your content and API keys, newest first. Entries are kept for{" "}
            {CMS_CONFIG.auditLog.retentionDays} days.
          </Layout.Description>
        </Layout.Header>

        <search className="mb-4 flex flex-wrap items-center gap-2" aria-label="Filter activity">
          <FilterSelect
            label="Entity"
            value={search.entity}
            options={[
              ...entities.map((entity) => ({ value: entity.name, label: getEntityTitle(entity) })),
              { value: API_KEY_ENTITY, label: "API keys" },
            ]}
            onValueChange={(entity) => setFilter({ entity, documentId: undefined })}
          />
          <FilterSelect
            label="Action"
            value={search.action}
            options={AUDIT_ACTIONS.map((action) => ({
              value: action,
              label: AUDIT_ACTION_LABELS[action],
            }))}
            onValueChange={(value) =>
              setFilter({ action: AUDIT_ACTIONS.find((action) => action === value) })
            }
          />
          <FilterSelect
            label="User"
            value={search.actorId}
            options={users.map((user) => ({ value: user.id, label: user.name || user.email }))}
            onValueChange={(actorId) => setFilter({ actorId })}
          />
          {LOCALES.length > 1 && (
            <FilterSelect
              label="Locale"
              value={search.locale}
              options={LOCALES}
              onValueChange={(locale) => setFilter({ locale })}
            />
          )}
          <FilterBox isActive={!!dateRange} className={cn(dateRange && "pr-1")}>
            <FilterValue label="Date" value={dateLabel} />
            <DatePicker>
              {/* Invisible over the whole box, so a click anywhere opens the calendar. */}
              <Popover.Trigger
                aria-label={`Date: ${dateLabel}`}
                className="absolute inset-0 cursor-pointer rounded-[inherit] outline-none"
              />
              <DatePicker.Panel>
                <DatePicker.Calendar
                  mode="range"
                  value={dateRange}
                  getIsDisabled={(day) => day > new Date()}
                  onDateChange={([start, end]) =>
                    setFilter({ from: toDayValue(start), to: toDayValue(end) })
                  }
                />
              </DatePicker.Panel>
            </DatePicker>
            {dateRange && (
              <IconButton
                variant="ghost"
                size="xs"
                className="relative"
                aria-label="Remove the date filter"
                onClick={() => setFilter({ from: undefined, to: undefined })}
              >
                <XIcon />
              </IconButton>
            )}
          </FilterBox>
          {search.documentId && (
            <FilterBox isActive className="cursor-default pr-1">
              <span className="text-foreground-secondary">Document</span>
              <span className="font-mono" title={search.documentId}>
                {search.documentId.slice(0, 8)}
              </span>
              <IconButton
                variant="ghost"
                size="xs"
                aria-label={`Remove the document filter (${search.documentId})`}
                onClick={() => setFilter({ documentId: undefined })}
              >
                <XIcon />
              </IconButton>
            </FilterBox>
          )}
          {hasFilters && (
            <Button variant="ghost" size="sm" asChild>
              <Link to="/settings/activity">
                <XIcon />
                Clear filters
              </Link>
            </Button>
          )}
        </search>

        <Table>
          <Table.Caption className="sr-only">Activity</Table.Caption>
          <Table.Header>
            <Table.Row>
              <Table.Head>When</Table.Head>
              <Table.Head>Who</Table.Head>
              <Table.Head>Action</Table.Head>
              <Table.Head>Document</Table.Head>
              <Table.Head>Changed fields</Table.Head>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {isError ? (
              <Table.Row>
                <Table.Cell colSpan={99} className="p-0">
                  <EmptyState className="border-none">
                    <EmptyState.Icon>
                      <WarningCircleIcon />
                    </EmptyState.Icon>
                    <EmptyState.Title>Couldn't load the activity</EmptyState.Title>
                    <EmptyState.Description>
                      If this persists, check that the audit log migration is applied.
                    </EmptyState.Description>
                  </EmptyState>
                </Table.Cell>
              </Table.Row>
            ) : showFetching || !data ? (
              Array.from({ length: 8 }).map((_, index) => (
                <Table.Row key={index}>
                  <Table.Cell colSpan={99}>
                    <Skeleton className="h-4" />
                  </Table.Cell>
                </Table.Row>
              ))
            ) : data.data.length === 0 ? (
              <Table.Row>
                <Table.Cell colSpan={99} className="p-0">
                  <EmptyState className="border-none">
                    <EmptyState.Icon>
                      <ListBulletsIcon />
                    </EmptyState.Icon>
                    <EmptyState.Title>
                      {hasFilters ? "No activity matches these filters" : "No activity yet"}
                    </EmptyState.Title>
                    <EmptyState.Description>
                      {hasFilters
                        ? "Widen the date range or clear a filter."
                        : "Writes show up here as soon as someone saves."}
                    </EmptyState.Description>
                    {hasFilters && (
                      <EmptyState.Actions>
                        <Button asChild size="sm" variant="outline">
                          <Link to="/settings/activity">Clear filters</Link>
                        </Button>
                      </EmptyState.Actions>
                    )}
                  </EmptyState>
                </Table.Cell>
              </Table.Row>
            ) : (
              data.data.map((entry) => <ActivityRow key={entry.id} entry={entry} />)
            )}
          </Table.Body>
        </Table>

        <div className="mt-2 flex items-center justify-between gap-4">
          <p className="text-sm text-foreground-secondary">
            {total} entr{total === 1 ? "y" : "ies"}
          </p>
          {total > AUDIT_LOG_PAGE_SIZE && (
            <Pagination className="w-auto">
              <Pagination.List>
                <Pagination.Item>
                  <Pagination.Previous
                    onClick={() =>
                      navigate({ search: (prev) => ({ ...prev, page: search.page - 1 }) })
                    }
                    disabled={search.page === 1}
                  />
                </Pagination.Item>
                {paginationItems.map((item) =>
                  item.type === "page" ? (
                    <Pagination.Item key={item.key}>
                      <Pagination.Link
                        isActive={item.selected}
                        onClick={() =>
                          navigate({ search: (prev) => ({ ...prev, page: item.value }) })
                        }
                      >
                        {item.value}
                      </Pagination.Link>
                    </Pagination.Item>
                  ) : (
                    <Pagination.Item key={item.key}>
                      <Pagination.Ellipsis />
                    </Pagination.Item>
                  ),
                )}
                <Pagination.Item>
                  <Pagination.Next
                    onClick={() =>
                      navigate({ search: (prev) => ({ ...prev, page: search.page + 1 }) })
                    }
                    disabled={search.page === pageCount}
                  />
                </Pagination.Item>
              </Pagination.List>
            </Pagination>
          )}
        </div>
      </Layout.Container>
    </Layout>
  );
}

/** `YYYY-MM-DD` days from the URL as the calendar's range; one bound alone is a single day. */
const toDateRange = (from?: string, to?: string): [Date, Date] | null => {
  const start = from ?? to;
  const end = to ?? from;
  if (!start || !end) return null;
  return [new Date(`${start}T00:00:00`), new Date(`${end}T00:00:00`)];
};

/** The local day of `date` as `YYYY-MM-DD`, the format the URL keeps. */
const toDayValue = (date: Date) =>
  [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("-");

/** "Oct 10 – Oct 15", one day as "Oct 10"; the year only when it isn't this year. */
const formatDayRange = ([start, end]: [Date, Date]) => {
  const thisYear = new Date().getFullYear();
  const format = (date: Date) =>
    date.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: date.getFullYear() === thisYear ? undefined : "numeric",
    });
  return start.getTime() === end.getTime() ? format(start) : `${format(start)} – ${format(end)}`;
};

/** A set filter reads as filled, so the bar shows at a glance what narrows the list. */
const filterActiveClass = "data-active:border-foreground/24 data-active:bg-foreground/4";

type FilterBoxProps = React.ComponentPropsWithRef<"div"> & { isActive: boolean };

/** The shell every filter shares: input-styled, sized to its content, filled once set. */
const FilterBox = ({ isActive, className, ...props }: FilterBoxProps) => (
  <div
    data-active={isActive || undefined}
    className={cn(
      inputStyle(),
      "relative w-auto cursor-pointer gap-2 whitespace-nowrap",
      filterActiveClass,
      className,
    )}
    {...props}
  />
);

/** What a filter shows: its label, muted, then the current value and a caret. */
const FilterValue = ({ label, value }: { label: string; value: string }) => (
  <>
    <span className="text-foreground-secondary">{label}</span>
    <span>{value}</span>
    <CaretUpDownIcon weight="bold" className="shrink-0 text-foreground/80" />
  </>
);

type FilterSelectProps = {
  label: string;
  value: string | undefined;
  options: ReadonlyArray<{ value: string; label: string }>;
  /** `undefined` for "All". */
  onValueChange: (value: string | undefined) => void;
};

/** Lists longer than this get a search input. */
const SEARCHABLE_FROM = 8;

/** A listbox whose trigger reads "<label>  <value>", searchable once its list is long. */
const FilterSelect = ({ label, value, options, onValueChange }: FilterSelectProps) => {
  const [query, setQuery] = useState("");
  const normalizedQuery = query.trim().toLowerCase();
  const visibleOptions = options.filter((option) =>
    option.label.toLowerCase().includes(normalizedQuery),
  );
  const valueLabel = options.find((option) => option.value === value)?.label ?? "All";

  return (
    <Listbox
      value={value ?? ""}
      onChange={(next) => {
        onValueChange(next || undefined);
        setQuery("");
      }}
      placement="bottom-start"
      matchReferenceWidth={false}
    >
      <Listbox.Trigger
        aria-label={`${label}: ${valueLabel}`}
        data-active={!!value || undefined}
        className={cn("w-auto whitespace-nowrap", filterActiveClass)}
      >
        <span className="text-foreground-secondary">{label}</span>
        <span>{valueLabel}</span>
      </Listbox.Trigger>
      <Listbox.Options className="w-64">
        {options.length > SEARCHABLE_FROM && (
          <Listbox.SearchInput
            placeholder={`Search ${label.toLowerCase()}`}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        )}
        {!normalizedQuery && <Listbox.Option value="">All</Listbox.Option>}
        {visibleOptions.map((option) => (
          <Listbox.Option key={option.value} value={option.value}>
            {option.label}
          </Listbox.Option>
        ))}
        {visibleOptions.length === 0 && <Listbox.Empty>No results</Listbox.Empty>}
      </Listbox.Options>
    </Listbox>
  );
};

const filterLinkClass =
  "rounded-sm hover:underline focus-visible:outline-2 focus-visible:outline-offset-2";

const ActivityRow = ({ entry }: { entry: AuditEntry }) => {
  const { actor } = entry;
  const entityDef = CMS_CONFIG.entities.find((candidate) => candidate.name === entry.entity);
  const isGlobal = !!entityDef?.global;
  const entityLabel =
    entry.entity === API_KEY_ENTITY ? "API key" : resolveEntityTitle(entry.entity);
  const actorLabel = auditActorLabel(actor, CMS_CONFIG.roles);

  return (
    <Table.Row>
      <Table.Cell className="whitespace-nowrap">
        <time dateTime={entry.createdAt} title={entry.createdAt}>
          {formatDate(entry.createdAt, "dateTime")}
        </time>
      </Table.Cell>
      <Table.Cell>
        <div className="flex flex-col">
          {actor.id ? (
            <Link
              to="/settings/activity"
              search={(prev) => ({ ...prev, actorId: actor.id ?? undefined, page: 1 })}
              className={filterLinkClass}
            >
              {actorLabel}
            </Link>
          ) : (
            <span>{actorLabel}</span>
          )}
          <span className="text-xs text-foreground-secondary">
            {actor.name && actor.email ? `${actor.email} · ${actor.role}` : actor.role}
          </span>
          {actor.id && !actor.email && (
            <span className="font-mono text-xs text-foreground-secondary">{actor.id}</span>
          )}
        </div>
      </Table.Cell>
      <Table.Cell className="whitespace-nowrap">{auditActionLabel(entry.action)}</Table.Cell>
      <Table.Cell>
        <div className="flex items-center gap-1.5 whitespace-nowrap">
          <Link
            to="/settings/activity"
            search={(prev) => ({ ...prev, entity: entry.entity, documentId: undefined, page: 1 })}
            className={cn("font-medium capitalize", filterLinkClass)}
            aria-label={`Show only ${entityLabel} activity`}
          >
            {entityLabel}
          </Link>
          {/* A global is one document per locale: its id adds nothing to the entity name. */}
          {!isGlobal && (
            <Link
              to="/settings/activity"
              search={(prev) => ({
                ...prev,
                entity: entry.entity,
                documentId: entry.documentId,
                page: 1,
              })}
              className={cn("font-mono text-xs text-foreground-secondary", filterLinkClass)}
              title={entry.documentId}
              aria-label={`Show only this document's activity (${entry.documentId})`}
            >
              {entry.documentId.slice(0, 8)}
            </Link>
          )}
          {entry.locale && (
            <Badge size="xs" variant="neutral" className="uppercase">
              {entry.locale}
            </Badge>
          )}
          {!isGlobal && (
            <CopyButton
              text={entry.documentId}
              variant="ghost"
              size="xs"
              className="text-foreground-secondary hover:text-foreground"
              aria-label="Copy document id"
            />
          )}
          <OpenDocumentLink entry={entry} />
        </div>
      </Table.Cell>
      <Table.Cell>
        {entry.changedFields.length > 0 ? (
          <div className="flex flex-wrap gap-1">
            {entry.changedFields.map((path) => (
              <Badge key={path} variant="neutral" size="sm" title={path}>
                {entityDef ? formatFieldPath(entityDef.fields, path) : path}
              </Badge>
            ))}
          </div>
        ) : (
          <span className="text-foreground-secondary">—</span>
        )}
      </Table.Cell>
    </Table.Row>
  );
};

/** Opens the document the entry is about. Internal entities and API keys have no page. */
const OpenDocumentLink = ({ entry }: { entry: AuditEntry }) => {
  const entity = CMS_CONFIG.entities.find((candidate) => candidate.name === entry.entity);
  if (!entity || entity.name.startsWith("_")) return null;

  return (
    <IconButton
      variant="ghost"
      size="xs"
      className="text-foreground-secondary hover:text-foreground"
      aria-label={entity.global ? `Open ${getEntityTitle(entity)}` : "Open document"}
      asChild
    >
      {entity.global ? (
        <Link
          to="/global/$name/{-$locale}"
          params={{
            name: entity.name,
            locale: entry.locale && entry.locale !== DEFAULT_LOCALE ? entry.locale : undefined,
          }}
        >
          <ArrowSquareOutIcon />
        </Link>
      ) : (
        <Link to="/entity/$name/$id" params={{ name: entity.name, id: entry.documentId }}>
          <ArrowSquareOutIcon />
        </Link>
      )}
    </IconButton>
  );
};
