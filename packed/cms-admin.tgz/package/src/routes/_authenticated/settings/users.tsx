import { Badge, Button, cn, Dialog, IconButton, Table } from "@cms/ui";
import { PlusIcon, TrashIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { UsersForm } from "@/components/forms/users-form";
import { PageLayout as Layout } from "@/components/layouts/page";
import { client } from "@/lib/client";
import { invalidate } from "@/lib/queries/keys";
import { getUsersQueryOptions } from "@/lib/queries/users";
import type { User } from "@/lib/schemas";
import { formatDate } from "@/lib/utils/dates";
import { withClickGuard } from "@/lib/utils/dom";

export const Route = createFileRoute("/_authenticated/settings/users")({
  component: RouteComponent,
  loader: async ({ context }) => {
    await context.queryClient.ensureQueryData(getUsersQueryOptions());
  },
});

function RouteComponent() {
  const { me } = Route.useRouteContext();
  const { data } = useSuspenseQuery(getUsersQueryOptions());

  const [formState, setFormState] = useState<
    { type: "create" } | { type: "update"; initialData: User } | null
  >(null);
  const [userToDeleteId, setUserToDeleteId] = useState<string | null>(null);

  return (
    <>
      <Layout>
        <Layout.Container>
          <Layout.Header className="flex items-end justify-between gap-4">
            <div>
              <Layout.Title>Users</Layout.Title>
              <Layout.Description>
                Manage your team members and their permissions here.
              </Layout.Description>
            </div>
            {/* TODO: */}
            <Button onClick={() => setFormState({ type: "create" })}>
              <PlusIcon />
              Create
            </Button>
          </Layout.Header>

          <Table>
            <Table.Header>
              <Table.Row>
                <Table.Head>Name</Table.Head>
                <Table.Head>Email</Table.Head>
                <Table.Head>Role</Table.Head>
                <Table.Head>Created At</Table.Head>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {data?.map((row) => {
                const isMyself = row.id === me.id;

                return (
                  <Table.Row
                    key={row.id}
                    tabIndex={0}
                    className={cn(isMyself && "opacity-64")}
                    inert={isMyself}
                    onClick={withClickGuard(() => {
                      setFormState({
                        type: "update",
                        initialData: row,
                      });
                    })}
                  >
                    <Table.Cell>
                      {row.name}
                      {isMyself && (
                        <Badge className="ml-2" variant="info">
                          You
                        </Badge>
                      )}
                    </Table.Cell>
                    <Table.Cell>{row.email}</Table.Cell>
                    <Table.Cell>
                      <Badge className="capitalize">{row.role}</Badge>
                    </Table.Cell>
                    <Table.Cell>{row.createdAt ? formatDate(row.createdAt) : "—"}</Table.Cell>
                    <Table.Cell className="w-6">
                      <IconButton
                        variant="ghost"
                        size="sm"
                        aria-label="Revoke"
                        disabled={isMyself}
                        onClick={() => setUserToDeleteId(row.id)}
                      >
                        <TrashIcon />
                      </IconButton>
                    </Table.Cell>
                  </Table.Row>
                );
              })}
            </Table.Body>
          </Table>
        </Layout.Container>
      </Layout>

      <Dialog open={!!formState} onOpenChange={() => setFormState(null)}>
        <Dialog.Content>
          {formState && (
            <UserFormDialogContent
              initialData={(formState.type === "update" && formState.initialData) || undefined}
              onSuccess={() => setFormState(null)}
            />
          )}
        </Dialog.Content>
      </Dialog>

      <Dialog open={!!userToDeleteId} onOpenChange={() => setUserToDeleteId(null)}>
        <Dialog.Content>
          {userToDeleteId && (
            <DeleteUserDialogContent
              userId={userToDeleteId}
              onSuccess={() => setUserToDeleteId(null)}
            />
          )}
        </Dialog.Content>
      </Dialog>
    </>
  );
}

type UserFormDialogContentProps = {
  initialData?: User;
  onSuccess?: () => void;
};

const UserFormDialogContent = ({ initialData, onSuccess }: UserFormDialogContentProps) => {
  const queryClient = useQueryClient();

  const type = initialData ? "edit" : "create";

  const createMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.request<{ data: User }>("/_user", {
        method: "POST",
        body: data,
      });

      return res.data;
    },
    onSuccess: (user) => {
      invalidate.afterDocumentWrite(queryClient, { entity: "_user", id: user.id });
      onSuccess?.();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const res = await client.request<{ data: User }>(`/_user/${initialData?.id}`, {
        method: "PUT",
        body: data,
      });

      return res.data;
    },
    onSuccess: (user) => {
      invalidate.afterDocumentWrite(queryClient, { entity: "_user", id: user.id });
      onSuccess?.();
    },
  });

  return (
    <UsersForm
      initialData={initialData}
      onSubmit={(data) =>
        type === "create" ? createMutation.mutateAsync(data) : updateMutation.mutateAsync(data)
      }
    >
      <Dialog.Title>{type === "create" ? "Create a new user" : "Update user"}</Dialog.Title>
      <Dialog.Description>
        {type === "create"
          ? "Create a new user by filling out the form below."
          : "Update the user by filling out the form below."}
      </Dialog.Description>
      <UsersForm.Fields />

      <Dialog.Actions>
        <Dialog.Close asChild>
          <Button variant="ghost">Cancel</Button>
        </Dialog.Close>
        <UsersForm.Submit>{type === "create" ? "Create" : "Update"}</UsersForm.Submit>
      </Dialog.Actions>
    </UsersForm>
  );
};

type DeleteUserDialogContentProps = {
  userId: string;
  onSuccess?: () => void;
};

const DeleteUserDialogContent = ({ userId, onSuccess }: DeleteUserDialogContentProps) => {
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const res = await client.request<{ data: Document }>(`/_user/${userId}`, {
        method: "DELETE",
      });

      return res.data;
    },
    onSuccess: () => {
      invalidate.afterDelete(queryClient, { entity: "_user" });
      onSuccess?.();
    },
  });

  return (
    <>
      <Dialog.Title>Delete User</Dialog.Title>
      <Dialog.Description>
        Are you sure you want to delete this User? <br />
        This action cannot be undone.
      </Dialog.Description>
      <Dialog.Actions>
        <Dialog.Close asChild>
          <Button variant="outline">Cancel</Button>
        </Dialog.Close>
        <Button
          autoFocus
          variant="destructive"
          onClick={() => deleteMutation.mutate()}
          isLoading={deleteMutation.isPending}
        >
          Delete
        </Button>
      </Dialog.Actions>
    </>
  );
};
