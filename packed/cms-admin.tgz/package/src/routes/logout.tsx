import { createFileRoute, redirect } from "@tanstack/react-router";
import { client } from "@/lib/client";
import { setReportedUser } from "@/lib/plugins";
import { getMeQueryOptions } from "@/lib/queries/me";

export const Route = createFileRoute("/logout")({
  component: () => null,
  loader: async ({ context: { queryClient } }) => {
    await client.request("/auth/logout", { method: "POST" });
    queryClient.setQueryData(getMeQueryOptions().queryKey, null);
    setReportedUser(null);

    return redirect({ to: "/login" });
  },
});
