import { Button, Field, Input, Label, OTPInput } from "@cms/ui";
import { ArrowLeftIcon, SignInIcon, WarningOctagonIcon } from "@phosphor-icons/react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, redirect } from "@tanstack/react-router";
import { Fragment, useState } from "react";
import { client } from "@/lib/client";
import { setReportedUser } from "@/lib/plugins";
import { getMeQueryOptions } from "@/lib/queries/me";
import type { User } from "@/lib/schemas";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  loader: async ({ context: { queryClient } }) => {
    const me = await queryClient.fetchQuery(getMeQueryOptions());

    if (me) {
      return redirect({ to: "/" });
    }
    // No session: stop attributing errors to whoever used this browser last.
    setReportedUser(null);
  },
});

type Step = { type: "email" } | { type: "code"; authRequestId: string; email: string };

const MAX_CODE_ATTEMPTS = 5;

function LoginPage() {
  const navigate = Route.useNavigate();
  const queryClient = useQueryClient();

  const [step, setStep] = useState<Step>({ type: "email" });
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [wrongAttempts, setWrongAttempts] = useState(0);

  const requestMutation = useMutation({
    mutationFn: async (emailArg: string) => {
      const res = await client.request<{ data: { authRequestId: string } }>("/auth/request", {
        method: "POST",
        body: { email: emailArg },
      });
      return res.data;
    },
    onSuccess: (data, emailArg) => {
      setStep({ type: "code", authRequestId: data.authRequestId, email: emailArg });
      setCode("");
      setWrongAttempts(0);
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async ({
      authRequestId,
      code: codeArg,
    }: {
      authRequestId: string;
      code: string;
    }) => {
      const res = await client.request<{ data: { user: User; expiresAt: string } }>(
        "/auth/create",
        {
          method: "POST",
          body: { authRequestId, code: codeArg },
        },
      );
      return res.data;
    },
    onSuccess: (data) => {
      queryClient.setQueryData(getMeQueryOptions().queryKey, data.user);
      navigate({ to: "/" });
    },
    onError: () => {
      setWrongAttempts((n) => n + 1);
    },
  });

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    requestMutation.mutate(email);
  };

  const handleCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step.type !== "code") return;
    verifyMutation.mutate({ authRequestId: step.authRequestId, code });
  };

  const handleResend = () => {
    if (step.type !== "code") return;
    requestMutation.mutate(step.email);
  };

  const remaining = MAX_CODE_ATTEMPTS - wrongAttempts;

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-xs">
        <div className="mb-6">
          <SignInIcon className="text-2xl mb-2" />
          <h1 className="text-2xl font-semibold">Sign in</h1>
          <p className="mt-1 text-base text-foreground-secondary">
            {step.type === "email"
              ? "Enter your email to receive a login code."
              : `Enter the code sent to ${step.email}.`}
          </p>
        </div>

        {step.type === "email" ? (
          <form onSubmit={handleEmailSubmit}>
            <Field>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoFocus
              />
            </Field>
            <Button type="submit" className="w-full" isLoading={requestMutation.isPending}>
              Send code
            </Button>
            <div className="h-8 pt-4">
              {requestMutation.error && (
                <Field.Error className="flex items-center gap-1 text-negative text-sm leading-none">
                  <WarningOctagonIcon />
                  <p>{requestMutation.error.message}</p>
                </Field.Error>
              )}
            </div>
          </form>
        ) : (
          <form onSubmit={handleCodeSubmit}>
            <Field>
              <Label htmlFor="code">Login code</Label>
              <OTPInput
                id="code"
                value={code}
                onChange={setCode}
                onFill={(filled) => {
                  if (step.type !== "code") return;
                  verifyMutation.mutate({ authRequestId: step.authRequestId, code: filled });
                }}
                invalid={!!verifyMutation.error}
              >
                {Array.from({ length: 6 }).map((_, index) => (
                  <Fragment key={index}>
                    <OTPInput.Cell key={index} />
                    {index === 2 && <OTPInput.Separator />}
                  </Fragment>
                ))}
              </OTPInput>
            </Field>
            <Button type="submit" className="w-full" isLoading={verifyMutation.isPending}>
              Sign in
            </Button>
            <div className="h-8 pt-4">
              {verifyMutation.error && (
                <Field.Error className="flex items-center gap-1 text-negative text-sm leading-none">
                  <WarningOctagonIcon />
                  <p>
                    {remaining > 0
                      ? `Invalid code. ${remaining} attempt${remaining === 1 ? "" : "s"} remaining.`
                      : "Too many attempts. Please request a new code."}
                  </p>
                </Field.Error>
              )}
            </div>
            <div className="flex items-center justify-between text-sm text-foreground-secondary">
              <button
                type="button"
                className="flex items-center gap-1 hover:text-foreground"
                onClick={() => setStep({ type: "email" })}
              >
                <ArrowLeftIcon />
                Back
              </button>
              <button
                type="button"
                className="hover:text-foreground"
                onClick={handleResend}
                disabled={requestMutation.isPending}
              >
                Resend code
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
